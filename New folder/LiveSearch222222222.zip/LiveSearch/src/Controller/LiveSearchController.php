<?php

namespace Plugin\LiveSearch\Controller;

use JTL\DB\DbInterface;
use JTL\Shop;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class LiveSearchController
{
    /** Upper bound on Merkmal phrase matches to keep JOIN depth predictable. */
    private const MAX_MERKMAL_MATCHES = 12;

    /** Prevent oversized queries (slow LIKE / greedy loop). */
    private const MAX_QUERY_LENGTH = 240;

    public function search(ServerRequestInterface $request, array $args): ResponseInterface
    {
        $queryParams = $request->getQueryParams();
        $q           = isset($queryParams['q']) ? trim((string) $queryParams['q']) : '';

        if (mb_strlen($q) < 2) {
            return $this->jsonResponse([]);
        }
        if (mb_strlen($q) > self::MAX_QUERY_LENGTH) {
            $q = mb_substr($q, 0, self::MAX_QUERY_LENGTH);
        }

        try {
            /** @var DbInterface $db */
            $db     = Shop::Container()->getDB();
            $langID = (int) Shop::getLanguageID();

            // Girdiyi kelimelere ayır
            $allWords = preg_split('/\s+/', $q);
            $allWords = array_values(array_filter($allWords, function ($t) {
                return mb_strlen($t) >= 2;
            }));

            if (empty($allWords)) {
                return $this->jsonResponse([]);
            }

            // Hangi kelimeler zaten tam Merkmal eşleşmesi?
            // Greedy: en uzun kombinasyondan kısa olana
            $confirmed = $this->findExactMerkmalValues($db, $langID, $allWords);
            $consumedIndexes = $confirmed['consumed'];
            $confirmedValues = $confirmed['values'];

            // Henüz eşleşmemiş kelimeleri bul (kullanıcının hâlâ yazdığı kısım)
            $pendingWords = [];
            for ($i = 0; $i < count($allWords); $i++) {
                if (!isset($consumedIndexes[$i])) {
                    $pendingWords[] = $allWords[$i];
                }
            }

            $pendingPhrase = implode(' ', $pendingWords);

            // Eğer pending (henüz tamamlanmamış) kelimeler varsa → autocomplete öner
            if (!empty($pendingPhrase) && mb_strlen($pendingPhrase) >= 2) {
                $suggestions = $db->getObjects(
                    "SELECT DISTINCT tmws.cWert
                       FROM tmerkmalwertsprache tmws
                      WHERE tmws.kSprache = :langID
                        AND tmws.cWert    LIKE :term
                   ORDER BY LENGTH(tmws.cWert) ASC, tmws.cWert ASC
                      LIMIT 8",
                    ['langID' => $langID, 'term' => '%' . $pendingPhrase . '%']
                );

                if (is_array($suggestions) && !empty($suggestions)) {
                    // Zaten confirmed olan değerleri öneriden çıkar
                    $confirmedNames = array_column($confirmedValues, 'cWert');
                    $filtered = [];
                    foreach ($suggestions as $s) {
                        if (!in_array($s->cWert, $confirmedNames, true)) {
                            $filtered[] = $s;
                        }
                    }

                    if (!empty($filtered)) {
                        $items = [];
                        $confirmedPrefix = !empty($confirmedNames)
                            ? implode(' ', $confirmedNames) . ' '
                            : '';

                        foreach ($filtered as $s) {
                            $items[] = [
                                'type'  => 'suggest',
                                'name'  => $s->cWert,
                                'fill'  => $confirmedPrefix . $s->cWert,
                            ];
                        }
                        return $this->jsonResponse($items);
                    }
                }
            }

            // Tüm kelimeler eşleşti → Serie sonuçlarını göster
            if (!empty($confirmedValues)) {
                if (\count($confirmedValues) > self::MAX_MERKMAL_MATCHES) {
                    $confirmedValues = \array_slice($confirmedValues, 0, self::MAX_MERKMAL_MATCHES);
                }

                return $this->jsonResponse(
                    $this->findSeriesForValues($db, $langID, $confirmedValues)
                );
            }

            return $this->jsonResponse([]);

        } catch (\Throwable $e) {
            return $this->jsonResponse([]);
        }
    }

    /**
     * Girilen kelimeleri veritabanındaki Merkmal değerleriyle exact eşleştir (greedy).
     */
    private function findExactMerkmalValues(DbInterface $db, int $langID, array $words): array
    {
        $matched  = [];
        $consumed = [];
        $count    = count($words);

        for ($len = $count; $len >= 1; $len--) {
            for ($start = 0; $start <= $count - $len; $start++) {
                $skip = false;
                for ($k = $start; $k < $start + $len; $k++) {
                    if (isset($consumed[$k])) { $skip = true; break; }
                }
                if ($skip) continue;

                $phrase = implode(' ', array_slice($words, $start, $len));

                $row = $db->getSingleObject(
                    "SELECT tmws.cWert,
                            seo.cSeo
                       FROM tmerkmalwertsprache tmws
                  LEFT JOIN tseo seo
                         ON seo.cKey     = 'kMerkmalWert'
                        AND seo.kKey     = tmws.kMerkmalWert
                        AND seo.kSprache = :langID
                      WHERE tmws.kSprache = :langID
                        AND tmws.cWert    = :phrase
                      LIMIT 1",
                    ['langID' => $langID, 'phrase' => $phrase]
                );

                if ($row) {
                    $matched[] = [
                        'cWert' => $row->cWert,
                        'cSeo'  => $row->cSeo ?? '',
                    ];
                    for ($k = $start; $k < $start + $len; $k++) {
                        $consumed[$k] = true;
                    }
                }
            }
        }

        return ['values' => $matched, 'consumed' => $consumed];
    }

    /**
     * Eşleşen Merkmal değerlerine göre Serie sonuçları + filtreli URL üret.
     */
    private function findSeriesForValues(DbInterface $db, int $langID, array $matchedValues): array
    {
        $joins  = '';
        $params = ['langID' => $langID];

        foreach ($matchedValues as $i => $mv) {
            $tamAlias  = 'tam' . $i;
            $tmwsAlias = 'tmws' . $i;
            $paramKey  = 'q' . $i;

            $joins .= " INNER JOIN tartikelmerkmal {$tamAlias}"
                    . "    ON {$tamAlias}.kArtikel = a.kArtikel"
                    . " INNER JOIN tmerkmalwertsprache {$tmwsAlias}"
                    . "    ON {$tmwsAlias}.kMerkmalWert = {$tamAlias}.kMerkmalWert"
                    . "   AND {$tmwsAlias}.kSprache     = :langID"
                    . "   AND {$tmwsAlias}.cWert         = :{$paramKey}";

            $params[$paramKey] = $mv['cWert'];
        }

        $sql = "SELECT DISTINCT serieWert.cWert AS serie,
                       serieSeo.cSeo            AS serieSeo
                  FROM tartikel a
                  {$joins}
            INNER JOIN tartikelmerkmal tamSerie
                    ON tamSerie.kArtikel = a.kArtikel
            INNER JOIN tmerkmalwert mwSerie
                    ON mwSerie.kMerkmalWert = tamSerie.kMerkmalWert
            INNER JOIN tmerkmal mSerie
                    ON mSerie.kMerkmal = mwSerie.kMerkmal
            INNER JOIN tmerkmalsprache msSerie
                    ON msSerie.kMerkmal = mSerie.kMerkmal
                   AND msSerie.kSprache = :langID
                   AND msSerie.cName    = 'Serie'
            INNER JOIN tmerkmalwertsprache serieWert
                    ON serieWert.kMerkmalWert = tamSerie.kMerkmalWert
                   AND serieWert.kSprache     = :langID
             LEFT JOIN tseo serieSeo
                    ON serieSeo.cKey     = 'kMerkmalWert'
                   AND serieSeo.kKey     = tamSerie.kMerkmalWert
                   AND serieSeo.kSprache = :langID
                 WHERE a.nIstVater = 0
              ORDER BY serieWert.cWert ASC
                 LIMIT 10";

        $rows = $db->getObjects($sql, $params);

        $filterSlugs = [];
        foreach ($matchedValues as $mv) {
            if (!empty($mv['cSeo'])) {
                $filterSlugs[] = $mv['cSeo'];
            }
        }
        $filterPath = !empty($filterSlugs) ? '__' . implode('__', $filterSlugs) : '';

        $shopURL = Shop::getURL();
        $items   = [];

        if (is_array($rows)) {
            foreach ($rows as $row) {
                $serieBase = !empty($row->serieSeo)
                    ? '/' . $row->serieSeo
                    : '/' . $row->serie . '-Serie';

                $items[] = [
                    'type'    => 'serie',
                    'name'    => $row->serie . ' Serie',
                    'filters' => implode(', ', array_column($matchedValues, 'cWert')),
                    'url'     => $shopURL . $serieBase . $filterPath,
                ];
            }
        }

        return $items;
    }

    private function jsonResponse(array $data): ResponseInterface
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $body = new \Laminas\Diactoros\Stream('php://temp', 'wb+');
        $body->write($json);
        $body->rewind();

        return new \Laminas\Diactoros\Response($body, 200, [
            'Content-Type'  => 'application/json; charset=utf-8',
            'Cache-Control' => 'public, max-age=60',
        ]);
    }
}
