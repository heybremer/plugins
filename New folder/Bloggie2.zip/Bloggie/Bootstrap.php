<?php

namespace Plugin\Bloggie;

use JTL\Events\Dispatcher;
use JTL\Plugin\Bootstrapper;
use JTL\Shop;
use JTL\Smarty\JTLSmarty;
use JTL\Router\Router;
use Psr\Http\Message\ServerRequestInterface;

class Bootstrap extends Bootstrapper
{
    private static bool $tablesEnsured = false;
    private static bool $adminMenuEnsured = false;
    private static bool $dailyAttempted = false;

    public function boot(Dispatcher $dispatcher): void
    {
        parent::boot($dispatcher);
        $this->ensureTables();
        $this->ensureAdminMenuEntry();

        $dispatcher->hookInto(\HOOK_LETZTERINCLUDE_CSS_JS, function (array &$args): void {
            if (!isset($args['cPluginCss_arr']) || !\is_array($args['cPluginCss_arr'])) {
                $args['cPluginCss_arr'] = [];
            }
            $css = 'plugins/Bloggie/templates/css/bloggie.css';
            if (!\in_array($css, $args['cPluginCss_arr'], true)) {
                $args['cPluginCss_arr'][] = $css;
            }
        });

        $dispatcher->hookInto(\HOOK_SMARTY_OUTPUTFILTER, function (array &$args): void {
            if (!isset($args['smarty'], $args['document'])) {
                return;
            }
            if (Shop::getPageType() !== \PAGE_STARTSEITE) {
                return;
            }
            $settings = $this->fetchSettings();
            if ((int)($settings['active'] ?? 1) !== 1) {
                return;
            }

            // Lazy daily run: first homepage request of day can trigger generation.
            if (!self::$dailyAttempted && (int)($settings['autoDaily'] ?? 1) === 1) {
                self::$dailyAttempted = true;
                $this->tryRunDailyGeneration();
            }

            $posts = $this->fetchLatestPosts(4);
            if ($posts === []) {
                return;
            }

            /** @var JTLSmarty $smarty */
            $smarty = $args['smarty'];
            $doc    = $args['document'];
            $tplPath = $this->getPlugin()->getPaths()->getBasePath() . 'templates/bloggie.tpl';
            if (!\is_file($tplPath)) {
                return;
            }

            $smarty->assign('bgTitle', (string)($settings['sectionTitle'] ?? 'Blog'));
            $smarty->assign('bgPosts', $posts);
            try {
                $html = $smarty->fetch('file:' . $tplPath);
            } catch (\Throwable $e) {
                return;
            }
            if ($html === '') {
                return;
            }

            $selectorRaw = trim((string)($settings['injectSelector'] ?? 'div.index-filter-konfigurator'));
            $mode = (string)($settings['injectMode'] ?? 'after');
            $mode = \in_array($mode, ['after', 'before', 'prepend', 'append'], true) ? $mode : 'after';
            $selectors = array_filter(array_map('trim', explode(',', $selectorRaw)), static fn($v) => $v !== '');
            if ($selectors === []) {
                $selectors = ['div.index-filter-konfigurator'];
            }

            $injected = false;
            foreach ($selectors as $sel) {
                $target = $doc->find($sel)->eq(0);
                if ($target->length < 1) {
                    continue;
                }
                try {
                    if ($mode === 'before') {
                        $target->before($html);
                    } elseif ($mode === 'prepend') {
                        $target->prepend($html);
                    } elseif ($mode === 'append') {
                        $target->append($html);
                    } else {
                        $target->after($html);
                    }
                    $injected = true;
                    break;
                } catch (\Throwable $e) {
                    // try next selector
                }
            }

            if (!$injected) {
                $content = $doc->find('div#content, main#main-wrapper, main')->eq(0);
                if ($content->length > 0) {
                    $content->prepend($html);
                }
            }
        });

        // Blog list page (tüm paylaşımlar)
        $dispatcher->hookInto(\HOOK_ROUTER_PRE_DISPATCH, function (array $args): void {
            if (!isset($args['router']) || !($args['router'] instanceof Router)) {
                return;
            }
            /** @var Router $router */
            $router = $args['router'];

            $router->addRoute(
                '/bloggie',
                function (ServerRequestInterface $request, array $routeArgs, JTLSmarty $smarty) {
                    $settings = $this->fetchSettings();
                    if ((int)($settings['active'] ?? 1) !== 1) {
                        return new \Laminas\Diactoros\Response\EmptyResponse();
                    }

                    $posts = $this->fetchAllPublishedPosts();
                    $bgTitle = (string)($settings['sectionTitle'] ?? 'Blog');

                    $tplPath = $this->getPlugin()->getPaths()->getBasePath() . 'templates/bloggie.tpl';
                    if (!\is_file($tplPath)) {
                        return new \Laminas\Diactoros\Response\EmptyResponse();
                    }
                    $smarty->assign('bgTitle', $bgTitle);
                    $smarty->assign('bgPosts', $posts);

                    try {
                        $inner = $smarty->fetch('file:' . $tplPath);
                    } catch (\Throwable $e) {
                        return new \Laminas\Diactoros\Response\EmptyResponse();
                    }
                    if ($inner === '') {
                        return new \Laminas\Diactoros\Response\EmptyResponse();
                    }

                    $shopUrl = \rtrim((string)Shop::getURL(), '/');
                    $cssHref = htmlspecialchars($shopUrl . '/plugins/Bloggie/templates/css/bloggie.css', ENT_QUOTES, 'UTF-8');
                    $titleEsc = htmlspecialchars($bgTitle, ENT_QUOTES, 'UTF-8');

                    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
                    $html .= '<title>' . $titleEsc . '</title>';
                    $html .= '<link rel="stylesheet" href="' . $cssHref . '">';
                    $html .= '</head><body>' . $inner . '</body></html>';

                    $body = new \Laminas\Diactoros\Stream('php://temp', 'wb+');
                    $body->write($html);
                    $body->rewind();

                    return new \Laminas\Diactoros\Response($body, 200, [
                        'Content-Type' => 'text/html; charset=utf-8',
                        'Cache-Control' => 'no-store',
                    ]);
                },
                'bloggie',
                ['GET']
            );
        });
    }

    private function ensureTables(): void
    {
        if (self::$tablesEnsured) {
            return;
        }
        try {
            $db = Shop::Container()->getDB();
            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_bloggie_settings (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    nActive TINYINT(1) NOT NULL DEFAULT 1,
                    nAutoDaily TINYINT(1) NOT NULL DEFAULT 1,
                    cApiKey TEXT NULL,
                    cModel VARCHAR(80) NOT NULL DEFAULT 'gpt-4o-mini',
                    cLanguage VARCHAR(20) NOT NULL DEFAULT 'de',
                    cSectionTitle VARCHAR(150) NOT NULL DEFAULT 'Blog',
                    cPromptPrefix TEXT NULL,
                    cInjectSelector VARCHAR(255) NOT NULL DEFAULT 'div.index-filter-konfigurator',
                    cInjectMode VARCHAR(20) NOT NULL DEFAULT 'after',
                    cCronToken VARCHAR(80) NOT NULL DEFAULT '',
                    dLastRunDate DATE NULL,
                    dUpdated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_bloggie_posts (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    kArtikel INT NOT NULL DEFAULT 0,
                    cProductName VARCHAR(255) NOT NULL DEFAULT '',
                    cProductUrl VARCHAR(500) NOT NULL DEFAULT '',
                    cSeoTitle VARCHAR(255) NOT NULL DEFAULT '',
                    cMetaDescription VARCHAR(500) NOT NULL DEFAULT '',
                    cBlogTitle VARCHAR(255) NOT NULL DEFAULT '',
                    cSlug VARCHAR(255) NOT NULL DEFAULT '',
                    cExcerpt TEXT NULL,
                    cBodyHtml LONGTEXT NULL,
                    nPublished TINYINT(1) NOT NULL DEFAULT 1,
                    dPublish DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    dCreated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    KEY idx_pub (nPublished, dPublish)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            try { $db->executeQuery("ALTER TABLE twomosi_bloggie_settings ADD COLUMN cInjectSelector VARCHAR(255) NOT NULL DEFAULT 'div.index-filter-konfigurator' AFTER cPromptPrefix"); } catch (\Throwable $e) {}
            try { $db->executeQuery("ALTER TABLE twomosi_bloggie_settings ADD COLUMN cInjectMode VARCHAR(20) NOT NULL DEFAULT 'after' AFTER cInjectSelector"); } catch (\Throwable $e) {}
            try { $db->executeQuery("ALTER TABLE twomosi_bloggie_settings ADD COLUMN cCronToken VARCHAR(80) NOT NULL DEFAULT '' AFTER cInjectMode"); } catch (\Throwable $e) {}
            try { $db->executeQuery("ALTER TABLE twomosi_bloggie_settings ADD COLUMN dLastRunDate DATE NULL AFTER cCronToken"); } catch (\Throwable $e) {}

            $exists = $db->getSingleObject("SELECT kID FROM twomosi_bloggie_settings LIMIT 1");
            if ($exists === null) {
                $row = new \stdClass();
                $row->nActive = 1;
                $row->nAutoDaily = 1;
                $row->cApiKey = '';
                $row->cModel = 'gpt-4o-mini';
                $row->cLanguage = 'de';
                $row->cSectionTitle = 'Blog';
                $row->cPromptPrefix = 'Write a high quality SEO blog post for this product page.';
                $row->cInjectSelector = 'div.index-filter-konfigurator';
                $row->cInjectMode = 'after';
                $row->cCronToken = \bin2hex(\random_bytes(16));
                $row->dLastRunDate = null;
                $row->dUpdated = date('Y-m-d H:i:s');
                $db->insert('twomosi_bloggie_settings', $row);
            }
            self::$tablesEnsured = true;
        } catch (\Throwable $e) {
            // ignore
        }
    }

    private function ensureAdminMenuEntry(): void
    {
        if (self::$adminMenuEnsured) {
            return;
        }
        try {
            $db = Shop::Container()->getDB();
            $pluginID = (int)$this->getPlugin()->getID();
            if ($pluginID <= 0) {
                return;
            }
            $exists = $db->getSingleObject(
                "SELECT kPluginAdminMenu
                   FROM tpluginadminmenu
                  WHERE kPlugin = :kPlugin
                    AND cDateiname = :cDateiname
                  LIMIT 1",
                ['kPlugin' => $pluginID, 'cDateiname' => 'dashboard.php']
            );
            if ($exists === null) {
                $menu = new \stdClass();
                $menu->kPlugin = $pluginID;
                $menu->cName = 'Bloggie Dashboard';
                $menu->cDateiname = 'dashboard.php';
                $menu->nSort = 32;
                $menu->nConf = 0;
                $db->insert('tpluginadminmenu', $menu);
            }
            self::$adminMenuEnsured = true;
        } catch (\Throwable $e) {
            // ignore
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function fetchSettings(): array
    {
        try {
            $db = Shop::Container()->getDB();
            $s = $db->getSingleObject("SELECT * FROM twomosi_bloggie_settings ORDER BY kID ASC LIMIT 1");
            if ($s === null) {
                return [];
            }
            $mode = (string)($s->cInjectMode ?? 'after');
            if (!\in_array($mode, ['after', 'before', 'prepend', 'append'], true)) {
                $mode = 'after';
            }
            return [
                'id' => (int)($s->kID ?? 0),
                'active' => (int)($s->nActive ?? 1),
                'autoDaily' => (int)($s->nAutoDaily ?? 1),
                'apiKey' => (string)($s->cApiKey ?? ''),
                'model' => (string)($s->cModel ?? 'gpt-4o-mini'),
                'language' => (string)($s->cLanguage ?? 'de'),
                'sectionTitle' => (string)($s->cSectionTitle ?? 'Blog'),
                'promptPrefix' => (string)($s->cPromptPrefix ?? ''),
                'injectSelector' => (string)($s->cInjectSelector ?? 'div.index-filter-konfigurator'),
                'injectMode' => $mode,
                'cronToken' => (string)($s->cCronToken ?? ''),
                'lastRunDate' => (string)($s->dLastRunDate ?? ''),
            ];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchLatestPosts(int $limit = 4): array
    {
        try {
            $db = Shop::Container()->getDB();
            $rows = $db->getObjects(
                "SELECT kID, cBlogTitle, cSlug, cExcerpt, cBodyHtml, cProductUrl, dPublish
                   FROM twomosi_bloggie_posts
                  WHERE nPublished = 1
                  ORDER BY dPublish DESC, kID DESC
                  LIMIT " . max(1, (int)$limit)
            );
            if (!\is_array($rows)) {
                return [];
            }
            $out = [];
            foreach ($rows as $r) {
                $out[] = [
                    'id' => (int)($r->kID ?? 0),
                    'title' => (string)($r->cBlogTitle ?? ''),
                    'slug' => (string)($r->cSlug ?? ''),
                    'excerpt' => (string)($r->cExcerpt ?? ''),
                    'body' => (string)($r->cBodyHtml ?? ''),
                    'productUrl' => (string)($r->cProductUrl ?? ''),
                    'date' => (string)($r->dPublish ?? ''),
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchAllPublishedPosts(): array
    {
        try {
            $db = Shop::Container()->getDB();
            $rows = $db->getObjects(
                "SELECT kID, cBlogTitle, cSlug, cExcerpt, cBodyHtml, cProductUrl, dPublish
                   FROM twomosi_bloggie_posts
                  WHERE nPublished = 1
                  ORDER BY dPublish DESC, kID DESC"
            );
            if (!\is_array($rows)) {
                return [];
            }
            $out = [];
            foreach ($rows as $r) {
                $out[] = [
                    'id' => (int)($r->kID ?? 0),
                    'title' => (string)($r->cBlogTitle ?? ''),
                    'slug' => (string)($r->cSlug ?? ''),
                    'excerpt' => (string)($r->cExcerpt ?? ''),
                    'body' => (string)($r->cBodyHtml ?? ''),
                    'productUrl' => (string)($r->cProductUrl ?? ''),
                    'date' => (string)($r->dPublish ?? ''),
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function tryRunDailyGeneration(): void
    {
        $settings = $this->fetchSettings();
        if ($settings === [] || (int)($settings['id'] ?? 0) <= 0) {
            return;
        }
        $today = date('Y-m-d');
        if ((string)($settings['lastRunDate'] ?? '') === $today) {
            return;
        }
        if (trim((string)($settings['apiKey'] ?? '')) === '') {
            return;
        }
        if ((int)($settings['autoDaily'] ?? 1) !== 1) {
            return;
        }
        $this->generateAndSavePost($settings, true);
    }

    /**
     * Called from api/generate.php
     */
    public function runManualGenerationByToken(string $token): array
    {
        $settings = $this->fetchSettings();
        if ($settings === [] || (int)($settings['id'] ?? 0) <= 0) {
            return ['ok' => false, 'message' => 'Settings not found'];
        }
        if (!\hash_equals((string)($settings['cronToken'] ?? ''), $token)) {
            return ['ok' => false, 'message' => 'Invalid token'];
        }
        if (trim((string)($settings['apiKey'] ?? '')) === '') {
            return ['ok' => false, 'message' => 'API key missing'];
        }
        return $this->generateAndSavePost($settings, false);
    }

    /**
     * @param array<string,mixed> $settings
     * @return array<string,mixed>
     */
    private function generateAndSavePost(array $settings, bool $daily): array
    {
        try {
            $product = $this->pickProductForToday();
            if ($product === null) {
                return ['ok' => false, 'message' => 'No product found'];
            }

            $generated = $this->generateSeoBlogWithOpenAI($settings, $product);
            if ((int)($generated['ok'] ?? 0) !== 1) {
                return ['ok' => false, 'message' => (string)($generated['message'] ?? 'Generation failed')];
            }

            $slug = $this->slugify((string)$generated['title']) . '-' . date('Ymd');
            $db = Shop::Container()->getDB();
            $db->executeQueryPrepared(
                "INSERT INTO twomosi_bloggie_posts
                    (kArtikel, cProductName, cProductUrl, cSeoTitle, cMetaDescription, cBlogTitle, cSlug, cExcerpt, cBodyHtml, nPublished, dPublish, dCreated)
                 VALUES
                    (:kArtikel, :cProductName, :cProductUrl, :cSeoTitle, :cMetaDescription, :cBlogTitle, :cSlug, :cExcerpt, :cBodyHtml, 1, NOW(), NOW())",
                [
                    'kArtikel' => (int)$product['kArtikel'],
                    'cProductName' => (string)$product['name'],
                    'cProductUrl' => (string)$product['url'],
                    'cSeoTitle' => (string)$product['seoTitle'],
                    'cMetaDescription' => (string)$product['metaDescription'],
                    'cBlogTitle' => (string)$generated['title'],
                    'cSlug' => $slug,
                    'cExcerpt' => (string)$generated['excerpt'],
                    'cBodyHtml' => (string)$generated['bodyHtml'],
                ]
            );
            if ($daily) {
                $db->executeQueryPrepared(
                    "UPDATE twomosi_bloggie_settings SET dLastRunDate = :d, dUpdated = NOW() WHERE kID = :kID",
                    ['d' => date('Y-m-d'), 'kID' => (int)$settings['id']]
                );
            }
            return ['ok' => true, 'message' => 'Blog generated', 'product' => $product['name'], 'title' => $generated['title']];
        } catch (\Throwable $e) {
            return ['ok' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * @return array<string,mixed>|null
     */
    private function pickProductForToday(): ?array
    {
        try {
            $lib = __DIR__ . '/includes/product_lib.php';
            if (\is_file($lib)) {
                require_once $lib;
            }
            if (!\function_exists('bloggieFetchArticleRows')) {
                return null;
            }
            $rows = bloggieFetchArticleRows();
            if (!\is_array($rows) || $rows === []) {
                return null;
            }
            $index = ((int)date('z')) % \count($rows);
            $p = $rows[$index];
            $kArtikel = (int)($p->kArtikel ?? 0);
            $name = trim((string)($p->cName ?? ''));
            if ($name === '') {
                $name = trim((string)($p->cArtName ?? 'Produkt'));
            }
            $seoTitle = trim((string)($p->cMetaTitle ?? ''));
            if ($seoTitle === '') {
                $seoTitle = $name;
            }
            $meta = trim((string)($p->cMetaDescription ?? ''));
            $desc = trim(strip_tags((string)($p->cKurzBeschreibung ?? '')));
            if ($desc === '') {
                $desc = trim(strip_tags((string)($p->cBeschreibung ?? '')));
            }
            if ($meta === '') {
                $meta = mb_substr($desc, 0, 250);
            }
            $base = rtrim((string)Shop::getURL(), '/');
            $url = $base . '/index.php?a=' . $kArtikel;
            return [
                'kArtikel' => $kArtikel,
                'name' => $name,
                'seoTitle' => $seoTitle,
                'metaDescription' => $meta,
                'description' => $desc,
                'url' => $url,
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * @param array<string,mixed> $settings
     * @param array<string,mixed> $product
     * @return array<string,mixed>
     */
    private function generateSeoBlogWithOpenAI(array $settings, array $product): array
    {
        $apiKey = trim((string)($settings['apiKey'] ?? ''));
        $model = trim((string)($settings['model'] ?? 'gpt-4o-mini'));
        $lang = trim((string)($settings['language'] ?? 'de'));
        $prefix = trim((string)($settings['promptPrefix'] ?? ''));

        $system = "You are an expert SEO content writer. Return strictly valid JSON with keys: title, excerpt, bodyHtml.";
        $user = $prefix . "\n\n"
            . "Language: " . $lang . "\n"
            . "Product Name: " . (string)$product['name'] . "\n"
            . "SEO Title: " . (string)$product['seoTitle'] . "\n"
            . "Meta Description: " . (string)$product['metaDescription'] . "\n"
            . "Product Description: " . (string)$product['description'] . "\n"
            . "Product URL: " . (string)$product['url'] . "\n\n"
            . "Rules:\n"
            . "- Write one publish-ready SEO blog article for this product.\n"
            . "- bodyHtml must contain h2 and p tags and one bullet list.\n"
            . "- mention product URL once in an anchor tag.\n"
            . "- title max 70 chars, excerpt max 180 chars.\n";

        $payload = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $user],
            ],
            'temperature' => 0.7,
            'response_format' => ['type' => 'json_object'],
        ];

        $ch = \curl_init('https://api.openai.com/v1/chat/completions');
        if ($ch === false) {
            return ['ok' => 0, 'message' => 'curl init failed'];
        }
        \curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 35,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);
        $resp = \curl_exec($ch);
        $err = \curl_error($ch);
        $code = (int)\curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        \curl_close($ch);

        if (!\is_string($resp) || $resp === '') {
            return ['ok' => 0, 'message' => 'Empty OpenAI response: ' . $err];
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => 0, 'message' => 'OpenAI error ' . $code . ': ' . mb_substr($resp, 0, 300)];
        }
        $decoded = json_decode($resp, true);
        $content = (string)($decoded['choices'][0]['message']['content'] ?? '');
        if ($content === '') {
            return ['ok' => 0, 'message' => 'Invalid OpenAI payload'];
        }
        $json = json_decode($content, true);
        if (!\is_array($json)) {
            return ['ok' => 0, 'message' => 'Model JSON parse failed'];
        }
        $title = trim((string)($json['title'] ?? ''));
        $excerpt = trim((string)($json['excerpt'] ?? ''));
        $bodyHtml = trim((string)($json['bodyHtml'] ?? ''));
        if ($title === '' || $bodyHtml === '') {
            return ['ok' => 0, 'message' => 'Missing title/bodyHtml'];
        }
        return ['ok' => 1, 'title' => $title, 'excerpt' => $excerpt, 'bodyHtml' => $bodyHtml];
    }

    private function slugify(string $text): string
    {
        $s = mb_strtolower(trim($text));
        $s = preg_replace('/[^a-z0-9]+/i', '-', $s) ?? '';
        $s = trim($s, '-');
        if ($s === '') {
            $s = 'blog-post';
        }
        return mb_substr($s, 0, 160);
    }
}

