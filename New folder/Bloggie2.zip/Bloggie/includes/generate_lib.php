<?php
declare(strict_types=1);

use JTL\Shop;

if (!function_exists('bloggieSlugify')) {
    function bloggieSlugify(string $text): string
    {
        $s = mb_strtolower(trim($text));
        $s = preg_replace('/[^a-z0-9]+/i', '-', $s) ?? '';
        $s = trim($s, '-');
        return $s !== '' ? mb_substr($s, 0, 160) : 'blog-post';
    }
}

if (!function_exists('bloggieGenerateOnePost')) {
    /**
     * @param string|null $cronToken If not null, must match settings (HTTP/cron). Null = internal (admin already authenticated).
     * @return array{ok:bool, message?:string, title?:string, product?:string}
     */
    function bloggieGenerateOnePost(?string $cronToken = null): array
    {
        try {
            $db = Shop::Container()->getDB();
            $s = $db->getSingleObject('SELECT * FROM twomosi_bloggie_settings ORDER BY kID ASC LIMIT 1');
            if ($s === null) {
                return ['ok' => false, 'message' => 'Settings not found'];
            }
            if ($cronToken !== null) {
                if (!hash_equals((string)($s->cCronToken ?? ''), $cronToken)) {
                    return ['ok' => false, 'message' => 'Invalid token'];
                }
            }
            $apiKey = trim((string)($s->cApiKey ?? ''));
            if ($apiKey === '') {
                return ['ok' => false, 'message' => 'API key missing'];
            }

            if (!function_exists('bloggieFetchArticleRows')) {
                require_once __DIR__ . '/product_lib.php';
            }
            $rows = bloggieFetchArticleRows();
            if (!is_array($rows) || $rows === []) {
                $n = function_exists('bloggieCountArticles') ? bloggieCountArticles() : 0;
                return ['ok' => false, 'message' => 'No product found (tartikel count=' . $n . ')'];
            }
            $index = ((int)date('z')) % count($rows);
            $p = $rows[$index];
            $kArtikel = (int)($p->kArtikel ?? 0);
            $name = trim((string)($p->cName ?? ''));
            if ($name === '') {
                $name = trim((string)($p->cArtName ?? 'Produkt'));
            }
            $seoTitle = trim((string)($p->cMetaTitle ?? ''));
            if ($seoTitle === '') {
                $seoTitle = $name;
            }
            $meta = trim((string)($p->cMetaDescription ?? ''));
            $desc = trim(strip_tags((string)($p->cKurzBeschreibung ?? '')));
            if ($desc === '') {
                $desc = trim(strip_tags((string)($p->cBeschreibung ?? '')));
            }
            if ($meta === '') {
                $meta = mb_substr($desc, 0, 250);
            }
            $productUrl = rtrim((string)Shop::getURL(), '/') . '/index.php?a=' . $kArtikel;

            $system = 'You are an expert SEO content writer. Return strictly valid JSON with keys: title, excerpt, bodyHtml.';
            $user = trim((string)($s->cPromptPrefix ?? 'Write a high quality SEO blog post for this product page.')) . "\n\n"
                . 'Language: ' . (string)($s->cLanguage ?? 'de') . "\n"
                . 'Product Name: ' . $name . "\n"
                . 'SEO Title: ' . $seoTitle . "\n"
                . 'Meta Description: ' . $meta . "\n"
                . 'Product Description: ' . $desc . "\n"
                . 'Product URL: ' . $productUrl . "\n\n"
                . "Rules:\n- bodyHtml must contain h2 and p tags and one bullet list.\n- mention product URL once in an anchor tag.\n";

            $payload = [
                'model' => (string)($s->cModel ?? 'gpt-4o-mini'),
                'messages' => [
                    ['role' => 'system', 'content' => $system],
                    ['role' => 'user', 'content' => $user],
                ],
                'temperature' => 0.7,
                'response_format' => ['type' => 'json_object'],
            ];

            $ch = curl_init('https://api.openai.com/v1/chat/completions');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $apiKey,
                ],
                CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                CURLOPT_TIMEOUT => 35,
                CURLOPT_CONNECTTIMEOUT => 10,
            ]);
            $resp = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $err = curl_error($ch);
            curl_close($ch);
            if (!is_string($resp) || $resp === '' || $code < 200 || $code >= 300) {
                return ['ok' => false, 'message' => 'OpenAI error: ' . $code . ' ' . $err];
            }
            $decoded = json_decode($resp, true);
            $content = (string)($decoded['choices'][0]['message']['content'] ?? '');
            $json = json_decode($content, true);
            if (!is_array($json)) {
                return ['ok' => false, 'message' => 'Model JSON parse failed'];
            }
            $title = trim((string)($json['title'] ?? ''));
            $excerpt = trim((string)($json['excerpt'] ?? ''));
            $bodyHtml = trim((string)($json['bodyHtml'] ?? ''));
            if ($title === '' || $bodyHtml === '') {
                return ['ok' => false, 'message' => 'Missing title/bodyHtml'];
            }

            $slug = bloggieSlugify($title) . '-' . date('Ymd');
            $db->executeQueryPrepared(
                'INSERT INTO twomosi_bloggie_posts
                    (kArtikel, cProductName, cProductUrl, cSeoTitle, cMetaDescription, cBlogTitle, cSlug, cExcerpt, cBodyHtml, nPublished, dPublish, dCreated)
                 VALUES
                    (:kArtikel, :cProductName, :cProductUrl, :cSeoTitle, :cMetaDescription, :cBlogTitle, :cSlug, :cExcerpt, :cBodyHtml, 1, NOW(), NOW())',
                [
                    'kArtikel' => $kArtikel,
                    'cProductName' => $name,
                    'cProductUrl' => $productUrl,
                    'cSeoTitle' => $seoTitle,
                    'cMetaDescription' => $meta,
                    'cBlogTitle' => $title,
                    'cSlug' => $slug,
                    'cExcerpt' => $excerpt,
                    'cBodyHtml' => $bodyHtml,
                ]
            );
            $db->executeQueryPrepared(
                'UPDATE twomosi_bloggie_settings SET dLastRunDate = :d, dUpdated = NOW() WHERE kID = :kID',
                ['d' => date('Y-m-d'), 'kID' => (int)$s->kID]
            );

            return ['ok' => true, 'message' => 'Blog generated', 'title' => $title, 'product' => $name];
        } catch (Throwable $e) {
            return ['ok' => false, 'message' => $e->getMessage()];
        }
    }
}
