<?php

namespace Plugin\FilterKonfiguratorSearch\Controller;

use JTL\DB\DbInterface;
use JTL\Helpers\Request;
use JTL\Shop;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class FilterKonfiguratorController
{
    /**
     * JSON endpoint: /fk-search
     * Beklenen query parametreleri (hepsi opsiyonel):
     * typ, hersteller, basis, modell, baujahr, sitz, serie
     */
    public function search(ServerRequestInterface $request, array $args): ResponseInterface
    {
        $params    = $request->getQueryParams();
        $mode      = trim($params['mode'] ?? '');
        $fieldForLog = trim($params['field'] ?? '');
        $qForLog     = trim($params['q'] ?? '');
        $typ       = trim($params['typ']       ?? '');
        $herst     = trim($params['hersteller']?? '');
        $basis     = trim($params['basis']     ?? '');
        $modell    = trim($params['modell']    ?? '');
        $baujahr   = trim($params['baujahr']   ?? '');
        $sitz      = trim($params['sitz']      ?? '');
        $serie     = trim($params['serie']     ?? '');

        /** @var DbInterface|null $db */
        $db = null;

        $logStart = \microtime(true);
        $logIp    = Request::getRealIP();
        $logUA    = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
        $logCtx   = [
            'mode'       => $mode,
            'field'      => $fieldForLog,
            'q'          => $qForLog,
            'typ'        => $typ,
            'hersteller' => $herst,
            'basis'      => $basis,
            'modell'     => $modell,
            'baujahr'    => $baujahr,
            'sitz'       => $sitz,
            'serie'      => $serie,
        ];

        try {
            /** @var DbInterface $db */
            $db = Shop::Container()->getDB();

            // Dropdown verileri için SADECE Merkmal tabanlı JSON endpoint
            // (twomosi_filterkonfigurator tablosunu burada hiç kullanmıyoruz)
            if ($mode === 'options') {
                $field      = trim($params['field'] ?? '');
                $term       = trim($params['q'] ?? '');
                $typParam   = trim($params['typ'] ?? '');
                $herstParam = trim($params['hersteller'] ?? '');
                $basisParam = trim($params['basis'] ?? '');
                $modellParam = trim($params['modell'] ?? '');
                $langID     = (int)Shop::getLanguageID();

                $fkOpts = \trim((string)($params['fkCustomModell'] ?? '')) === '1'
                    || \strtolower(\trim((string)($params['fkCustomModell'] ?? ''))) === 'true';
                $options = $this->loadMerkmalOptions($db, $langID, $field, $term, $typParam, $herstParam, $basisParam, $modellParam, $fkOpts);

                return new JsonResponse($options, 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }

            // Artık twomosi_filterkonfigurator veya data/records.php fallback KULLANMIYORUZ.
            // Seçilen Merkmal değerlerine göre, LiveSearch mantığına benzer şekilde
            // doğrudan veritabanından Serie URL'leri üret.

            $langID = (int)Shop::getLanguageID();

            $fkCustomModellRaw = \trim((string)($params['fkCustomModell'] ?? ''));
            $fkCustomModell      = ($fkCustomModellRaw === '1'
                || \strtolower($fkCustomModellRaw) === 'true'
                || \strtolower($fkCustomModellRaw) === 'yes');

            // „Nicht in der Liste“ + Freitext: komplette Familie-Serie-Liste (ohne Artikel-Filter)
            $fkNichtInListeRaw = \trim((string)($params['fkNichtInListe'] ?? ''));
            $fkNichtInListe    = ($fkNichtInListeRaw === '1'
                || \strtolower($fkNichtInListeRaw) === 'true'
                || \strtolower($fkNichtInListeRaw) === 'yes');
            if ($fkCustomModell && $fkNichtInListe && $modell !== '') {
                $seriesItems = $this->findAllFamilieSerieItems($db, $langID);

                return new JsonResponse($seriesItems, 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }

            // Step 4 cache: aynı seçim kombinasyonunda seri listesini tekrar DB'den hesaplama.
            // Cache sadece tablo halinde yazılan seri listesi için kullanılır.
            $step4CacheKey = '';
            $useStep4Cache = ($typ !== '' && $herst !== '' && $basis !== '' && $modell !== '' && $sitz !== '');
            if ($useStep4Cache) {
                $cacheTtlSeconds = 2 * 24 * 60 * 60; // 2 gün
                $step4CacheKey    = md5($langID . '|' . $typ . '|' . $herst . '|' . $basis . '|' . $modell . '|' . $sitz . '|' . ($fkCustomModell ? 'familie' : 'std'));

                try {
                    $row = $db->getSingleObject(
                        "SELECT cPayload, dUpdated
                           FROM twomosi_step4_cache
                          WHERE cKey = :cKey
                          LIMIT 1",
                        ['cKey' => $step4CacheKey]
                    );

                    if ($row && !empty($row->cPayload) && !empty($row->dUpdated)) {
                        $updatedTs = \strtotime((string)$row->dUpdated);
                        if ($updatedTs !== false) {
                            $age = \time() - $updatedTs;
                            if ($age >= 0 && $age <= $cacheTtlSeconds) {
                                $decoded = \json_decode((string)$row->cPayload, true);
                                if (\is_array($decoded)) {
                                    return new JsonResponse($decoded, 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                                }
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    // Cache okuma hatası olursa normal hesaplamaya devam.
                }
            }

            $selections = [];
            // Manuel Modell (nicht in der Liste): Merkmal "Fahrzeug-Modell" nicht matchen — Serie aus "Familie-Serie".
            if ($fkCustomModell && $modell !== '') {
                if ($sitz === '') {
                    return new JsonResponse([], 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                }
                if ($typ !== '') {
                    $selections[] = ['value' => $typ, 'names' => ['Wohnmobil-Aufbauart']];
                }
                if ($herst !== '') {
                    $selections[] = ['value' => $herst, 'names' => ['Fahrzeug-Marke']];
                }
                if ($basis !== '') {
                    $selections[] = ['value' => $basis, 'names' => ['Wohnmobil-Fahrgestell']];
                }
                if ($sitz !== '') {
                    $selections[] = ['value' => $sitz, 'names' => ['kompatible Sitze']];
                }
                if ($serie !== '') {
                    $selections[] = ['value' => $serie, 'names' => ['Serie']];
                }
            } else {
                if ($typ !== '') {
                    $selections[] = ['value' => $typ, 'names' => ['Wohnmobil-Aufbauart']];
                }
                if ($herst !== '') {
                    $selections[] = ['value' => $herst, 'names' => ['Fahrzeug-Marke']];
                }
                if ($modell !== '') {
                    $selections[] = ['value' => $modell, 'names' => ['Fahrzeug-Modell']];
                }
                if ($basis !== '') {
                    $selections[] = ['value' => $basis, 'names' => ['Wohnmobil-Fahrgestell']];
                }
                if ($sitz !== '') {
                    $selections[] = ['value' => $sitz, 'names' => ['kompatible Sitze']];
                }
                if ($serie !== '') {
                    $selections[] = ['value' => $serie, 'names' => ['Serie']];
                }
            }

            if (\count($selections) === 0) {
                return new JsonResponse([], 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }

            // Seçilen değerleri, ilgili Merkmal adına göre kısıtlayarak eşleştir
            $matchedValues = $this->findExactMerkmalValuesForNames($db, $langID, $selections);

            if (\count($matchedValues) === 0) {
                return new JsonResponse([], 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }

            // Bu Merkmal değerlerine göre Serie sonuçlarını üret (manuell: Familie-Serie)
            $serieMerkmalName = ($fkCustomModell && $modell !== '') ? 'Familie-Serie' : 'Serie';
            $seriesItems      = $this->findSeriesForValues($db, $langID, $matchedValues, $serieMerkmalName);

            // Cache miss -> sonucu cache'e yaz.
            if ($useStep4Cache && $step4CacheKey !== '') {
                try {
                    $payload = \json_encode($seriesItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if (is_string($payload)) {
                        $db->executeQueryPrepared(
                            "INSERT INTO twomosi_step4_cache (cKey, dUpdated, cPayload)
                             VALUES (:cKey, NOW(), :cPayload)
                             ON DUPLICATE KEY UPDATE
                                dUpdated = NOW(),
                                cPayload = VALUES(cPayload)",
                            [
                                'cKey'     => $step4CacheKey,
                                'cPayload' => $payload,
                            ]
                        );
                    }
                } catch (\Throwable $e) {
                    // Cache yazma hatası olursa normal response dön.
                }
            }

            return new JsonResponse($seriesItems, 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } catch (\Throwable $e) {
            return new JsonResponse([
                'error'   => true,
                'message' => $e->getMessage(),
            ], 500, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } finally {
            try {
                if ($db !== null) {
                    $durationMs = (int)\round((\microtime(true) - $logStart) * 1000);
                    $payload    = \json_encode($logCtx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if (!\is_string($payload) || $payload === '') {
                        $payload = '{}';
                    }
                    $db->executeQueryPrepared(
                        "INSERT INTO twomosi_fk_search_log
                            (cIP, dCreated, cMode, cField, cParams, nDurationMs, cUserAgent)
                         VALUES
                            (:ip, NOW(), :mode, :field, :params, :dur, :ua)",
                        [
                            'ip'     => $logIp,
                            'mode'   => $mode,
                            'field'  => $fieldForLog,
                            'params' => $payload,
                            'dur'    => $durationMs,
                            'ua'     => $logUA,
                        ]
                    );
                }
            } catch (\Throwable $e) {
                // Never break endpoint due to logging.
            }
        }
    }

    /**
     * Wohnmobil-Konfigurator için Merkmal altyapısından distinct dropdown değerleri yükler.
     *
     * field parametresi:
     *  - typ        => Wohnmobil-Aufbauart
     *  - hersteller => Fahrzeug-Marke
     *  - basis      => Wohnmobil-Fahrgestell
     *  - modell     => Fahrzeug-Modell
     *  - sitz       => kompatible Sitze
     *  - serie      => Serie / kompatible Serien
     *
     * Sonuç yapısı: [['value' => 'Kastenwagen'], ['value' => 'Fiat Ducato 250'], ...]
     */
    private function loadMerkmalOptions(
        DbInterface $db,
        int $langID,
        string $field,
        string $term = '',
        string $typFilter = '',
        string $herstellerFilter = '',
        string $basisFilter = '',
        string $modellFilter = '',
        bool $fkCustomModell = false
    ): array
    {
        if ($field === '') {
            return [];
        }

        // Hersteller: Seçili Fahrzeugtyp varsa, onu da filtreye dahil et (JOIN ile),
        // yoksa sadece Merkmal tablosundan distinct liste döndür.
        if ($field === 'hersteller') {
            $params = ['langID' => $langID];
            $like   = '';
            if ($term !== '') {
                $params['term'] = '%' . $term . '%';
                $like           = ' AND tmws_her.cWert LIKE :term';
            }

            // Seçili Fahrzeugtyp varsa, sadece o typ'e sahip araçların markalarını getir
            if ($typFilter !== '') {
                $params['typ'] = $typFilter;

                $sql = "SELECT DISTINCT tmws_her.cWert
                          FROM tartikel a
                    -- Fahrzeugtyp (Wohnmobil-Aufbauart)
                    INNER JOIN tartikelmerkmal am_typ
                            ON am_typ.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_typ
                            ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                    INNER JOIN tmerkmal m_typ
                            ON m_typ.kMerkmal = mw_typ.kMerkmal
                    INNER JOIN tmerkmalsprache ms_typ
                            ON ms_typ.kMerkmal = m_typ.kMerkmal
                           AND ms_typ.kSprache = :langID
                           AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                    INNER JOIN tmerkmalwertsprache tmws_typ
                            ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                           AND tmws_typ.kSprache     = :langID
                           AND tmws_typ.cWert        = :typ
                    -- Hersteller (Fahrzeug-Marke)
                    INNER JOIN tartikelmerkmal am_her
                            ON am_her.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_her
                            ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                    INNER JOIN tmerkmal m_her
                            ON m_her.kMerkmal = mw_her.kMerkmal
                    INNER JOIN tmerkmalsprache ms_her
                            ON ms_her.kMerkmal = m_her.kMerkmal
                           AND ms_her.kSprache = :langID
                           AND ms_her.cName    = 'Fahrzeug-Marke'
                    INNER JOIN tmerkmalwertsprache tmws_her
                            ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                           AND tmws_her.kSprache     = :langID
                         WHERE tmws_her.cWert <> ''
                           AND tmws_her.cWert NOT REGEXP '^[0-9]+$'"
                       . $like .
                       ' ORDER BY tmws_her.cWert ASC
                         LIMIT 200';
            } else {
                // Typ seçilmemişse, tüm markaların listesini döndür
                $sql = "SELECT DISTINCT tmws.cWert
                          FROM tmerkmal m
                    INNER JOIN tmerkmalsprache ms
                            ON ms.kMerkmal = m.kMerkmal
                           AND ms.kSprache = :langID
                    INNER JOIN tmerkmalwert mw
                            ON mw.kMerkmal = m.kMerkmal
                    INNER JOIN tmerkmalwertsprache tmws
                            ON tmws.kMerkmalWert = mw.kMerkmalWert
                           AND tmws.kSprache     = :langID
                         WHERE ms.cName = 'Fahrzeug-Marke'
                           AND tmws.cWert <> ''
                           AND tmws.cWert NOT REGEXP '^[0-9]+$'"
                       . ($term !== '' ? ' AND tmws.cWert LIKE :term' : '') .
                       ' ORDER BY tmws.cWert ASC
                         LIMIT 200';
            }

            try {
                $rows = $db->getObjects($sql, $params);
            } catch (\Throwable $e) {
                return [['value' => 'ERROR: ' . $e->getMessage()]];
            }

            $out = [];
            if (\is_array($rows)) {
                foreach ($rows as $row) {
                    if (!isset($row->cWert) || $row->cWert === '') {
                        continue;
                    }
                    $out[] = ['value' => $row->cWert];
                }
            }

            return $out;
        }

        // Basisfahrzeug: Seçili Typ + Hersteller kombinasyonuna göre Fahrgestell değerleri
        if ($field === 'basis') {
            if ($herstellerFilter === '' || $typFilter === '') {
                // Filtreler eksikse, aşağıdaki generic Merkmal listesini kullan
                $names = ['Wohnmobil-Fahrgestell'];
            } else {
                $params = [
                    'langID'     => $langID,
                    'typ'        => $typFilter,
                    'hersteller' => $herstellerFilter,
                ];
                $likeSql = '';
                if ($term !== '') {
                    $params['term'] = '%' . $term . '%';
                    $likeSql        = ' AND tmws_basis.cWert LIKE :term';
                }

                $sql = "SELECT DISTINCT tmws_basis.cWert
                          FROM tartikel a
                    -- Fahrzeugtyp (Wohnmobil-Aufbauart)
                    INNER JOIN tartikelmerkmal am_typ
                            ON am_typ.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_typ
                            ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                    INNER JOIN tmerkmal m_typ
                            ON m_typ.kMerkmal = mw_typ.kMerkmal
                    INNER JOIN tmerkmalsprache ms_typ
                            ON ms_typ.kMerkmal = m_typ.kMerkmal
                           AND ms_typ.kSprache = :langID
                           AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                    INNER JOIN tmerkmalwertsprache tmws_typ
                            ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                           AND tmws_typ.kSprache     = :langID
                           AND tmws_typ.cWert        = :typ
                    -- Hersteller (Fahrzeug-Marke)
                    INNER JOIN tartikelmerkmal am_her
                            ON am_her.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_her
                            ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                    INNER JOIN tmerkmal m_her
                            ON m_her.kMerkmal = mw_her.kMerkmal
                    INNER JOIN tmerkmalsprache ms_her
                            ON ms_her.kMerkmal = m_her.kMerkmal
                           AND ms_her.kSprache = :langID
                           AND ms_her.cName    = 'Fahrzeug-Marke'
                    INNER JOIN tmerkmalwertsprache tmws_her
                            ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                           AND tmws_her.kSprache     = :langID
                           AND tmws_her.cWert        = :hersteller
                    -- Basisfahrzeug (Wohnmobil-Fahrgestell)
                    INNER JOIN tartikelmerkmal am_basis
                            ON am_basis.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_basis
                            ON mw_basis.kMerkmalWert = am_basis.kMerkmalWert
                    INNER JOIN tmerkmal m_basis
                            ON m_basis.kMerkmal = mw_basis.kMerkmal
                    INNER JOIN tmerkmalsprache ms_basis
                            ON ms_basis.kMerkmal = m_basis.kMerkmal
                           AND ms_basis.kSprache = :langID
                           AND ms_basis.cName    = 'Wohnmobil-Fahrgestell'
                    INNER JOIN tmerkmalwertsprache tmws_basis
                            ON tmws_basis.kMerkmalWert = mw_basis.kMerkmalWert
                           AND tmws_basis.kSprache     = :langID
                         WHERE tmws_basis.cWert <> ''"
                       . $likeSql .
                       ' ORDER BY tmws_basis.cWert ASC
                         LIMIT 80';

                try {
                    $rows = $db->getObjects($sql, $params);
                } catch (\Throwable $e) {
                    // Özel sorgu hata verirse generic fallback'e düş
                    $rows = [];
                }

                if (\is_array($rows) && \count($rows) > 0) {
                    $out = [];
                    foreach ($rows as $row) {
                        if (!isset($row->cWert) || $row->cWert === '') {
                            continue;
                        }
                        $out[] = ['value' => $row->cWert];
                    }

                    return $out;
                }
                // Hiç sonuç yoksa, aşağıdaki generic Merkmal listelemesine düş
            }
        }

        // Modell: Seçili Typ + Hersteller + Basis (Wohnmobil-Fahrgestell) kombinasyonuna göre modeller
        if ($field === 'modell') {
            if ($herstellerFilter === '' || $typFilter === '' || $basisFilter === '') {
                $names = ['Fahrzeug-Modell'];
            } else {
                $params = [
                    'langID'     => $langID,
                    'typ'        => $typFilter,
                    'hersteller' => $herstellerFilter,
                    'basis'      => $basisFilter,
                ];
                $likeSql = '';
                if ($term !== '') {
                    $params['term'] = '%' . $term . '%';
                    $likeSql        = ' AND tmws_mod.cWert LIKE :term';
                }

                $sql = "SELECT DISTINCT tmws_mod.cWert
                          FROM tartikel a
                    -- Fahrzeugtyp (Wohnmobil-Aufbauart)
                    INNER JOIN tartikelmerkmal am_typ
                            ON am_typ.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_typ
                            ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                    INNER JOIN tmerkmal m_typ
                            ON m_typ.kMerkmal = mw_typ.kMerkmal
                    INNER JOIN tmerkmalsprache ms_typ
                            ON ms_typ.kMerkmal = m_typ.kMerkmal
                           AND ms_typ.kSprache = :langID
                           AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                    INNER JOIN tmerkmalwertsprache tmws_typ
                            ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                           AND tmws_typ.kSprache     = :langID
                           AND tmws_typ.cWert        = :typ
                    -- Hersteller (Fahrzeug-Marke)
                    INNER JOIN tartikelmerkmal am_her
                            ON am_her.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_her
                            ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                    INNER JOIN tmerkmal m_her
                            ON m_her.kMerkmal = mw_her.kMerkmal
                    INNER JOIN tmerkmalsprache ms_her
                            ON ms_her.kMerkmal = m_her.kMerkmal
                           AND ms_her.kSprache = :langID
                           AND ms_her.cName    = 'Fahrzeug-Marke'
                    INNER JOIN tmerkmalwertsprache tmws_her
                            ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                           AND tmws_her.kSprache     = :langID
                           AND tmws_her.cWert        = :hersteller
                    -- Basisfahrzeug (Wohnmobil-Fahrgestell)
                    INNER JOIN tartikelmerkmal am_basis
                            ON am_basis.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_basis
                            ON mw_basis.kMerkmalWert = am_basis.kMerkmalWert
                    INNER JOIN tmerkmal m_basis
                            ON m_basis.kMerkmal = mw_basis.kMerkmal
                    INNER JOIN tmerkmalsprache ms_basis
                            ON ms_basis.kMerkmal = m_basis.kMerkmal
                           AND ms_basis.kSprache = :langID
                           AND ms_basis.cName    = 'Wohnmobil-Fahrgestell'
                    INNER JOIN tmerkmalwertsprache tmws_basis
                            ON tmws_basis.kMerkmalWert = mw_basis.kMerkmalWert
                           AND tmws_basis.kSprache     = :langID
                           AND tmws_basis.cWert        = :basis
                    -- Modell (Fahrzeug-Modell)
                    INNER JOIN tartikelmerkmal am_mod
                            ON am_mod.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_mod
                            ON mw_mod.kMerkmalWert = am_mod.kMerkmalWert
                    INNER JOIN tmerkmal m_mod
                            ON m_mod.kMerkmal = mw_mod.kMerkmal
                    INNER JOIN tmerkmalsprache ms_mod
                            ON ms_mod.kMerkmal = m_mod.kMerkmal
                           AND ms_mod.kSprache = :langID
                           AND ms_mod.cName    = 'Fahrzeug-Modell'
                    INNER JOIN tmerkmalwertsprache tmws_mod
                            ON tmws_mod.kMerkmalWert = mw_mod.kMerkmalWert
                           AND tmws_mod.kSprache     = :langID
                         WHERE tmws_mod.cWert <> ''"
                       . $likeSql .
                       ' ORDER BY tmws_mod.cWert ASC
                         LIMIT 80';

                try {
                    $rows = $db->getObjects($sql, $params);
                } catch (\Throwable $e) {
                    return [['value' => 'ERROR: ' . $e->getMessage()]];
                }

                $out = [];
                if (\is_array($rows)) {
                    foreach ($rows as $row) {
                        if (!isset($row->cWert) || $row->cWert === '') {
                            continue;
                        }
                        $out[] = ['value' => $row->cWert];
                    }
                }

                return $out;
            }
        }

        // Sitz: Seçili Typ + Hersteller + Basis + Modell kombinasyonuna göre "kompatible Sitze"
        if ($field === 'sitz') {
            // Freitext-Modell: kein exakter Fahrzeug-Modell-Merkmal-Treffer — Sitze nur über Typ+Marke+Fahrgestell
            if ($fkCustomModell && $typFilter !== '' && $herstellerFilter !== '' && $basisFilter !== '') {
                $params = [
                    'langID'     => $langID,
                    'typ'        => $typFilter,
                    'hersteller' => $herstellerFilter,
                    'basis'      => $basisFilter,
                ];
                $likeSql = '';
                if ($term !== '') {
                    $params['term'] = '%' . $term . '%';
                    $likeSql        = ' AND tmws_sitz.cWert LIKE :term';
                }

                $sql = "SELECT DISTINCT tmws_sitz.cWert
                          FROM tartikel a
                    INNER JOIN tartikelmerkmal am_typ
                            ON am_typ.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_typ
                            ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                    INNER JOIN tmerkmal m_typ
                            ON m_typ.kMerkmal = mw_typ.kMerkmal
                    INNER JOIN tmerkmalsprache ms_typ
                            ON ms_typ.kMerkmal = m_typ.kMerkmal
                           AND ms_typ.kSprache = :langID
                           AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                    INNER JOIN tmerkmalwertsprache tmws_typ
                            ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                           AND tmws_typ.kSprache     = :langID
                           AND tmws_typ.cWert        = :typ
                    INNER JOIN tartikelmerkmal am_her
                            ON am_her.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_her
                            ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                    INNER JOIN tmerkmal m_her
                            ON m_her.kMerkmal = mw_her.kMerkmal
                    INNER JOIN tmerkmalsprache ms_her
                            ON ms_her.kMerkmal = m_her.kMerkmal
                           AND ms_her.kSprache = :langID
                           AND ms_her.cName    = 'Fahrzeug-Marke'
                    INNER JOIN tmerkmalwertsprache tmws_her
                            ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                           AND tmws_her.kSprache     = :langID
                           AND tmws_her.cWert        = :hersteller
                    INNER JOIN tartikelmerkmal am_basis
                            ON am_basis.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_basis
                            ON mw_basis.kMerkmalWert = am_basis.kMerkmalWert
                    INNER JOIN tmerkmal m_basis
                            ON m_basis.kMerkmal = mw_basis.kMerkmal
                    INNER JOIN tmerkmalsprache ms_basis
                            ON ms_basis.kMerkmal = m_basis.kMerkmal
                           AND ms_basis.kSprache = :langID
                           AND ms_basis.cName    = 'Wohnmobil-Fahrgestell'
                    INNER JOIN tmerkmalwertsprache tmws_basis
                            ON tmws_basis.kMerkmalWert = mw_basis.kMerkmalWert
                           AND tmws_basis.kSprache     = :langID
                           AND tmws_basis.cWert        = :basis
                    INNER JOIN tartikelmerkmal am_sitz
                            ON am_sitz.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_sitz
                            ON mw_sitz.kMerkmalWert = am_sitz.kMerkmalWert
                    INNER JOIN tmerkmal m_sitz
                            ON m_sitz.kMerkmal = mw_sitz.kMerkmal
                    INNER JOIN tmerkmalsprache ms_sitz
                            ON ms_sitz.kMerkmal = m_sitz.kMerkmal
                           AND ms_sitz.kSprache = :langID
                           AND ms_sitz.cName    = 'kompatible Sitze'
                    INNER JOIN tmerkmalwertsprache tmws_sitz
                            ON tmws_sitz.kMerkmalWert = mw_sitz.kMerkmalWert
                           AND tmws_sitz.kSprache     = :langID
                         WHERE tmws_sitz.cWert <> ''"
                       . $likeSql .
                       ' ORDER BY tmws_sitz.cWert ASC
                         LIMIT 80';

                try {
                    $rows = $db->getObjects($sql, $params);
                } catch (\Throwable $e) {
                    $rows = [];
                }

                if (\is_array($rows) && \count($rows) > 0) {
                    $out = [];
                    foreach ($rows as $row) {
                        if (!isset($row->cWert) || $row->cWert === '') {
                            continue;
                        }
                        $out[] = ['value' => $row->cWert];
                    }

                    return $out;
                }
            }

            if ($herstellerFilter === '' || $typFilter === '' || $basisFilter === '' || $modellFilter === '') {
                $names = ['kompatible Sitze'];
            } else {
                $params = [
                    'langID'     => $langID,
                    'typ'        => $typFilter,
                    'hersteller' => $herstellerFilter,
                    'basis'      => $basisFilter,
                    'modell'     => $modellFilter,
                ];
                $likeSql = '';
                if ($term !== '') {
                    $params['term'] = '%' . $term . '%';
                    $likeSql        = ' AND tmws_sitz.cWert LIKE :term';
                }

                $sql = "SELECT DISTINCT tmws_sitz.cWert
                          FROM tartikel a
                    -- Fahrzeugtyp (Wohnmobil-Aufbauart)
                    INNER JOIN tartikelmerkmal am_typ
                            ON am_typ.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_typ
                            ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                    INNER JOIN tmerkmal m_typ
                            ON m_typ.kMerkmal = mw_typ.kMerkmal
                    INNER JOIN tmerkmalsprache ms_typ
                            ON ms_typ.kMerkmal = m_typ.kMerkmal
                           AND ms_typ.kSprache = :langID
                           AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                    INNER JOIN tmerkmalwertsprache tmws_typ
                            ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                           AND tmws_typ.kSprache     = :langID
                           AND tmws_typ.cWert        = :typ
                    -- Hersteller (Fahrzeug-Marke)
                    INNER JOIN tartikelmerkmal am_her
                            ON am_her.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_her
                            ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                    INNER JOIN tmerkmal m_her
                            ON m_her.kMerkmal = mw_her.kMerkmal
                    INNER JOIN tmerkmalsprache ms_her
                            ON ms_her.kMerkmal = m_her.kMerkmal
                           AND ms_her.kSprache = :langID
                           AND ms_her.cName    = 'Fahrzeug-Marke'
                    INNER JOIN tmerkmalwertsprache tmws_her
                            ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                           AND tmws_her.kSprache     = :langID
                           AND tmws_her.cWert        = :hersteller
                    -- Basisfahrzeug (Wohnmobil-Fahrgestell)
                    INNER JOIN tartikelmerkmal am_basis
                            ON am_basis.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_basis
                            ON mw_basis.kMerkmalWert = am_basis.kMerkmalWert
                    INNER JOIN tmerkmal m_basis
                            ON m_basis.kMerkmal = mw_basis.kMerkmal
                    INNER JOIN tmerkmalsprache ms_basis
                            ON ms_basis.kMerkmal = m_basis.kMerkmal
                           AND ms_basis.kSprache = :langID
                           AND ms_basis.cName    = 'Wohnmobil-Fahrgestell'
                    INNER JOIN tmerkmalwertsprache tmws_basis
                            ON tmws_basis.kMerkmalWert = mw_basis.kMerkmalWert
                           AND tmws_basis.kSprache     = :langID
                           AND tmws_basis.cWert        = :basis
                    -- Modell (Fahrzeug-Modell)
                    INNER JOIN tartikelmerkmal am_mod
                            ON am_mod.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_mod
                            ON mw_mod.kMerkmalWert = am_mod.kMerkmalWert
                    INNER JOIN tmerkmal m_mod
                            ON m_mod.kMerkmal = mw_mod.kMerkmal
                    INNER JOIN tmerkmalsprache ms_mod
                            ON ms_mod.kMerkmal = m_mod.kMerkmal
                           AND ms_mod.kSprache = :langID
                           AND ms_mod.cName    = 'Fahrzeug-Modell'
                    INNER JOIN tmerkmalwertsprache tmws_mod
                            ON tmws_mod.kMerkmalWert = mw_mod.kMerkmalWert
                           AND tmws_mod.kSprache     = :langID
                           AND tmws_mod.cWert        = :modell
                    -- Sitz (kompatible Sitze)
                    INNER JOIN tartikelmerkmal am_sitz
                            ON am_sitz.kArtikel = a.kArtikel
                    INNER JOIN tmerkmalwert mw_sitz
                            ON mw_sitz.kMerkmalWert = am_sitz.kMerkmalWert
                    INNER JOIN tmerkmal m_sitz
                            ON m_sitz.kMerkmal = mw_sitz.kMerkmal
                    INNER JOIN tmerkmalsprache ms_sitz
                            ON ms_sitz.kMerkmal = m_sitz.kMerkmal
                           AND ms_sitz.kSprache = :langID
                           AND ms_sitz.cName    = 'kompatible Sitze'
                    INNER JOIN tmerkmalwertsprache tmws_sitz
                            ON tmws_sitz.kMerkmalWert = mw_sitz.kMerkmalWert
                           AND tmws_sitz.kSprache     = :langID
                         WHERE tmws_sitz.cWert <> ''"
                       . $likeSql .
                       ' ORDER BY tmws_sitz.cWert ASC
                         LIMIT 80';

                try {
                    $rows = $db->getObjects($sql, $params);
                } catch (\Throwable $e) {
                    // Özel sorgu hata verirse, generic merkmal fallback'ine düş
                    $rows = [];
                }

                if (\is_array($rows) && \count($rows) > 0) {
                    $out = [];
                    foreach ($rows as $row) {
                        if (!isset($row->cWert) || $row->cWert === '') {
                            continue;
                        }
                        $out[] = ['value' => $row->cWert];
                    }

                    return $out;
                }
                // Hiç sonuc yoksa, aşağıdaki generic merkmal listelemesine düş
            }
        }

        // Diğer tüm alanlar için Merkmal altyapısını kullan
        switch ($field) {
            case 'typ':
                $names = ['Wohnmobil-Aufbauart'];
                break;
            case 'sitz':
                $names = ['kompatible Sitze'];
                break;
            case 'serie':
                $names = ['Serie'];
                break;
            default:
                return [];
        }

        // 1. Tercihen Merkmal adına göre filtrele (varsa)
        $rows = [];
        try {
            $inPlaceholders = [];
            $params         = [];
            foreach ($names as $idx => $n) {
                $key              = 'name' . $idx;
                $inPlaceholders[] = ':' . $key;
                $params[$key]     = $n;
            }

            $likeSql = '';
            if ($term !== '') {
                $params['term'] = '%' . $term . '%';
                $likeSql        = ' AND tmws.cWert LIKE :term';
            }

            $sql = "SELECT DISTINCT tmws.cWert
                      FROM tmerkmal m
                INNER JOIN tmerkmalsprache ms
                        ON ms.kMerkmal = m.kMerkmal
                     WHERE ms.cName IN (" . \implode(',', $inPlaceholders) . ')
                INNER JOIN tmerkmalwert mw
                        ON mw.kMerkmal = m.kMerkmal
                INNER JOIN tmerkmalwertsprache tmws
                        ON tmws.kMerkmalWert = mw.kMerkmalWert' .
                   $likeSql .
                   ' ORDER BY tmws.cWert ASC
                     LIMIT 60';

            $rows = $db->getObjects($sql, $params);
        } catch (\Throwable $e) {
            $rows = [];
        }

        // 2. Her ihtimale karşı: üstte hiç satır dönmezse, tüm Merkmal değerlerinden al (fallback)
        if (!\is_array($rows) || \count($rows) === 0) {
            try {
                $params2 = [];
                $likeSql2 = '';
                if ($term !== '') {
                    $params2['term'] = '%' . $term . '%';
                    $likeSql2        = ' WHERE tmws.cWert LIKE :term';
                }
                $sql2 = 'SELECT DISTINCT tmws.cWert
                           FROM tmerkmalwertsprache tmws' .
                        $likeSql2 .
                        ' ORDER BY tmws.cWert ASC
                          LIMIT 100';
                $rows = $db->getObjects($sql2, $params2);
            } catch (\Throwable $e2) {
                $rows = [];
            }
        }

        $out = [];
        if (\is_array($rows)) {
            foreach ($rows as $row) {
                if (!isset($row->cWert)) {
                    continue;
                }
                $out[] = [
                    'value' => $row->cWert,
                ];
            }
        }

        return $out;
    }

    /**
     * Seçilen string değerleri, tam Merkmal değerleriyle (cWert + cSeo) eşleştir.
     * LiveSearchController::findExactMerkmalValues mantığının sadeleştirilmiş hali.
     *
     * @param DbInterface $db
     * @param int         $langID
     * @param string[]    $values
     * @return array<int,array{cWert:string,cSeo:string}>
     */
    private function findExactMerkmalValues(DbInterface $db, int $langID, array $values): array
    {
        $matched = [];
        foreach ($values as $phrase) {
            if ($phrase === '') {
                continue;
            }
            $row = $db->getSingleObject(
                "SELECT tmws.cWert,
                        seo.cSeo
                   FROM tmerkmalwertsprache tmws
              LEFT JOIN tseo seo
                     ON seo.cKey     = 'kMerkmalWert'
                    AND seo.kKey     = tmws.kMerkmalWert
                    AND seo.kSprache = :langID
                  WHERE tmws.kSprache = :langID
                    AND tmws.cWert    = :phrase
                  LIMIT 1",
                ['langID' => $langID, 'phrase' => $phrase]
            );

            if ($row) {
                $matched[] = [
                    'cWert' => $row->cWert,
                    'cSeo'  => $row->cSeo ?? '',
                ];
            }
        }

        return $matched;
    }

    /**
     * Seçilen değerleri, ilgili Merkmal adı(ları) ile kısıtlayarak eşleştir.
     * Böylece örn. "9" gibi değerler yanlışlıkla başka bir Merkmal (örn. Baujahr) ile eşleşmez.
     *
     * @param DbInterface $db
     * @param int         $langID
     * @param array<int,array{value:string,names:string[]}> $selections
     * @return array<int,array{cWert:string,cSeo:string}>
     */
    private function findExactMerkmalValuesForNames(DbInterface $db, int $langID, array $selections): array
    {
        $matched = [];

        foreach ($selections as $sel) {
            $phrase = \trim($sel['value'] ?? '');
            $names  = $sel['names'] ?? [];
            if ($phrase === '' || !\is_array($names) || \count($names) === 0) {
                continue;
            }

            $placeholders = [];
            $params = [
                'langID'  => $langID,
                'phrase'  => $phrase,
            ];
            foreach (\array_values($names) as $i => $n) {
                $k = 'n' . $i;
                $placeholders[] = ':' . $k;
                $params[$k] = $n;
            }

            $row = $db->getSingleObject(
                "SELECT tmws.cWert,
                        seo.cSeo
                   FROM tmerkmalwertsprache tmws
             INNER JOIN tmerkmalwert mw
                     ON mw.kMerkmalWert = tmws.kMerkmalWert
             INNER JOIN tmerkmal m
                     ON m.kMerkmal = mw.kMerkmal
             INNER JOIN tmerkmalsprache ms
                     ON ms.kMerkmal = m.kMerkmal
                    AND ms.kSprache = :langID
              LEFT JOIN tseo seo
                     ON seo.cKey     = 'kMerkmalWert'
                    AND seo.kKey     = tmws.kMerkmalWert
                    AND seo.kSprache = :langID
                  WHERE tmws.kSprache = :langID
                    AND tmws.cWert    = :phrase
                    AND ms.cName IN (" . \implode(',', $placeholders) . ")
                  LIMIT 1",
                $params
            );

            if ($row) {
                $matched[] = [
                    'cWert' => $row->cWert,
                    'cSeo'  => $row->cSeo ?? '',
                ];
            }
        }

        return $matched;
    }

    /**
     * Eşleşen Merkmal değerlerine göre Serie sonuçları + filtreli URL üret.
     * LiveSearchController::findSeriesForValues fonksiyonuna yakındır.
     *
     * @param DbInterface $db
     * @param int         $langID
     * @param array<int,array{cWert:string,cSeo:string}> $matchedValues
     * @param string                                      $serieMerkmalName ms.cName (z. B. Serie oder Familie-Serie)
     * @return array<int,array<string,string>>
     */
    private function findSeriesForValues(DbInterface $db, int $langID, array $matchedValues, string $serieMerkmalName = 'Serie'): array
    {
        $allowed = ['Serie', 'Familie-Serie'];
        if (!\in_array($serieMerkmalName, $allowed, true)) {
            $serieMerkmalName = 'Serie';
        }

        $joins  = '';
        $params = ['langID' => $langID, 'serieMerkmalName' => $serieMerkmalName];

        foreach ($matchedValues as $i => $mv) {
            $tamAlias  = 'tam' . $i;
            $tmwsAlias = 'tmws' . $i;
            $paramKey  = 'q' . $i;

            $joins .= " INNER JOIN tartikelmerkmal {$tamAlias}"
                    . "    ON {$tamAlias}.kArtikel = a.kArtikel"
                    . " INNER JOIN tmerkmalwertsprache {$tmwsAlias}"
                    . "    ON {$tmwsAlias}.kMerkmalWert = {$tamAlias}.kMerkmalWert"
                    . "   AND {$tmwsAlias}.kSprache     = :langID"
                    . "   AND {$tmwsAlias}.cWert         = :{$paramKey}";

            $params[$paramKey] = $mv['cWert'];
        }

        $sql = "SELECT DISTINCT serieWert.cWert AS serie,
                       serieSeo.cSeo            AS serieSeo
                  FROM tartikel a
                  {$joins}
            INNER JOIN tartikelmerkmal tamSerie
                    ON tamSerie.kArtikel = a.kArtikel
            INNER JOIN tmerkmalwert mwSerie
                    ON mwSerie.kMerkmalWert = tamSerie.kMerkmalWert
            INNER JOIN tmerkmal mSerie
                    ON mSerie.kMerkmal = mwSerie.kMerkmal
            INNER JOIN tmerkmalsprache msSerie
                    ON msSerie.kMerkmal = mSerie.kMerkmal
                   AND msSerie.kSprache = :langID
                   AND msSerie.cName    = :serieMerkmalName
            INNER JOIN tmerkmalwertsprache serieWert
                    ON serieWert.kMerkmalWert = tamSerie.kMerkmalWert
                   AND serieWert.kSprache     = :langID
             LEFT JOIN tseo serieSeo
                    ON serieSeo.cKey     = 'kMerkmalWert'
                   AND serieSeo.kKey     = tamSerie.kMerkmalWert
                   AND serieSeo.kSprache = :langID
                 WHERE a.nIstVater = 0
              ORDER BY serieWert.cWert ASC
                 LIMIT 24";

        $rows = $db->getObjects($sql, $params);

        $filterSlugs = [];
        foreach ($matchedValues as $mv) {
            if (!empty($mv['cSeo'])) {
                $filterSlugs[] = $mv['cSeo'];
            }
        }
        $filterPath = !empty($filterSlugs) ? '__' . \implode('__', $filterSlugs) : '';

        $shopURL = Shop::getURL();
        $items   = [];

        if (\is_array($rows)) {
            foreach ($rows as $row) {
                $serieBase = !empty($row->serieSeo)
                    ? '/' . $row->serieSeo
                    : '/' . $row->serie . '-Serie';

                $items[] = [
                    'serie'   => $row->serie,
                    'url'     => $shopURL . $serieBase . $filterPath,
                ];
            }
        }

        return $items;
    }

    /**
     * Alle Werte des Merkmals „Familie-Serie“ (Sprache), unabhängig von Fahrzeug-/Artikel-Filtern.
     *
     * @return array<int, array{serie: string, url: string}>
     */
    private function findAllFamilieSerieItems(DbInterface $db, int $langID): array
    {
        $params = ['langID' => $langID];
        $sql    = "SELECT DISTINCT tmws.cWert AS serie,
                          seo.cSeo AS serieSeo
                     FROM tmerkmal m
               INNER JOIN tmerkmalsprache ms
                       ON ms.kMerkmal = m.kMerkmal
                      AND ms.kSprache = :langID
                      AND ms.cName    = 'Familie-Serie'
               INNER JOIN tmerkmalwert mw
                       ON mw.kMerkmal = m.kMerkmal
               INNER JOIN tmerkmalwertsprache tmws
                       ON tmws.kMerkmalWert = mw.kMerkmalWert
                      AND tmws.kSprache     = :langID
                LEFT JOIN tseo seo
                       ON seo.cKey     = 'kMerkmalWert'
                      AND seo.kKey     = tmws.kMerkmalWert
                      AND seo.kSprache = :langID
                    WHERE TRIM(tmws.cWert) <> ''
                 ORDER BY tmws.cWert ASC
                    LIMIT 500";

        $rows = $db->getObjects($sql, $params);
        $shopURL = Shop::getURL();
        $items   = [];

        if (!\is_array($rows)) {
            return [];
        }

        foreach ($rows as $row) {
            $serie = \trim((string)($row->serie ?? ''));
            if ($serie === '') {
                continue;
            }
            $serieBase = !empty($row->serieSeo)
                ? '/' . $row->serieSeo
                : '/' . $serie . '-Serie';
            $items[] = [
                'serie' => $serie,
                'url'   => $shopURL . $serieBase,
            ];
        }

        return $items;
    }
}

