/**
 * Nur wenn „Mein Modell ist nicht in der Liste“ + Freitext:
 * - Kompakttitel an buy_form senden → Server setzt Warenkorb cName (Wawi/Bestellung)
 * - „Zuletzt in den WK“-Box (#pushed-success) gleicher Name
 */
(function () {
  'use strict';

  var FK_STATE_KEY = 'womosi_fk_state_v1';
  var FK_MODELL_CUSTOM = '__FK_MODELL_CUSTOM__';

  function compactLineFromStorage() {
    try {
      var raw = window.localStorage.getItem(FK_STATE_KEY);
      if (!raw) return '';
      var c = JSON.parse(raw);
      if (!c || typeof c !== 'object') return '';
      var parts = [];
      if (c.typLabel) parts.push(String(c.typLabel).trim());
      if (c.hersteller) parts.push(String(c.hersteller).trim());
      if (c.basis) parts.push(String(c.basis).trim());
      var m = c.modell != null ? String(c.modell).trim() : '';
      if (m === FK_MODELL_CUSTOM) {
        m = c.modellCustom ? String(c.modellCustom).trim() : '';
      } else if (!m && c.modellCustom) {
        m = String(c.modellCustom).trim();
      }
      if (m) parts.push(m);
      if (c.year) parts.push('Model ' + String(c.year).trim());
      return parts.filter(Boolean).join(' ');
    } catch (e) {
      return '';
    }
  }

  function isManualModelOnly() {
    try {
      var raw = window.localStorage.getItem(FK_STATE_KEY);
      if (!raw) return false;
      var c = JSON.parse(raw);
      if (!c || typeof c !== 'object') return false;
      var m = String(c.modell || '').trim();
      if (m === FK_MODELL_CUSTOM) return true;
      if (!m && String(c.modellCustom || '').trim() !== '') return true;
      return false;
    } catch (e) {
      return false;
    }
  }

  function removeOldHidden(form) {
    ['fk_womosi_manual', 'fk_womosi_dyn_title'].forEach(function (name) {
      var nodes = form.querySelectorAll('input[name="' + name + '"]');
      for (var i = 0; i < nodes.length; i++) nodes[i].remove();
    });
  }

  function addHidden(form, name, value) {
    var inp = document.createElement('input');
    inp.type = 'hidden';
    inp.name = name;
    inp.value = value;
    form.appendChild(inp);
  }

  function injectBuyFormFields() {
    if (!isManualModelOnly()) return;
    var line = compactLineFromStorage();
    if (!line) return;
    ['buy_form', 'buy_form-quickview'].forEach(function (id) {
      var form = document.getElementById(id);
      if (!form) return;
      removeOldHidden(form);
      addHidden(form, 'fk_womosi_manual', '1');
      addHidden(form, 'fk_womosi_dyn_title', line);
    });
  }

  function updatePushedSuccessTitle() {
    if (!isManualModelOnly()) return;
    var line = compactLineFromStorage();
    if (!line) return;
    var box = document.querySelector('#pushed-success .productbox-title.subheadline');
    if (!box) return;
    box.textContent = line;
    box.classList.add('fk-selection-h1');
  }

  function run() {
    injectBuyFormFields();
    updatePushedSuccessTitle();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  // Nach „In den WK“-Redirect erscheint #pushed-success ggf. verzögert
  var pollN = 0;
  var poll = setInterval(function () {
    pollN++;
    updatePushedSuccessTitle();
    if (document.querySelector('#pushed-success .productbox-title') || pollN > 30) {
      clearInterval(poll);
    }
  }, 200);

  document.addEventListener('submit', function (e) {
    var t = e.target;
    if (!t || !t.id) return;
    if (t.id !== 'buy_form' && t.id !== 'buy_form-quickview') return;
    injectBuyFormFields();
  }, true);
})();
