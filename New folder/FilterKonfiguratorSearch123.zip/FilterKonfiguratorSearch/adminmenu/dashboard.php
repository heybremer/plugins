<?php
declare(strict_types=1);

use JTL\Helpers\Form;
use JTL\Shop;

$db = Shop::Container()->getDB();

$message = '';
$bannerEnsureOk = true;
$bannerEnsureError = '';

// Admin sayfası bazen Bootstrap boot tetiklenmeden çalışabilir.
// Bu yüzden banner tablosunu burada da garanti altına al.
try {
    $db->executeQuery(
        "CREATE TABLE IF NOT EXISTS twomosi_fk_banner (
            kID INT AUTO_INCREMENT PRIMARY KEY,
            cHeadline VARCHAR(255) NOT NULL DEFAULT '',
            cSub1 VARCHAR(255) NOT NULL DEFAULT '',
            cSub2 VARCHAR(255) NOT NULL DEFAULT '',
            cSub3 VARCHAR(255) NOT NULL DEFAULT '',
            nSub1Active TINYINT(1) NOT NULL DEFAULT 1,
            nSub2Active TINYINT(1) NOT NULL DEFAULT 1,
            nSub3Active TINYINT(1) NOT NULL DEFAULT 1,
            cSub2ButtonLabel VARCHAR(255) NOT NULL DEFAULT 'Aktif et',
            cSub2ButtonUrl VARCHAR(500) NOT NULL DEFAULT '#',
            dUpdated DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    try { $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN nSub1Active TINYINT(1) NOT NULL DEFAULT 1 AFTER cSub3"); } catch (\Throwable $e) {}
    try { $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN nSub2Active TINYINT(1) NOT NULL DEFAULT 1 AFTER nSub1Active"); } catch (\Throwable $e) {}
    try { $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN nSub3Active TINYINT(1) NOT NULL DEFAULT 1 AFTER nSub2Active"); } catch (\Throwable $e) {}
    try { $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN cSub2ButtonLabel VARCHAR(255) NOT NULL DEFAULT 'Aktif et' AFTER nSub3Active"); } catch (\Throwable $e) {}
    try { $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN cSub2ButtonUrl VARCHAR(500) NOT NULL DEFAULT '#' AFTER cSub2ButtonLabel"); } catch (\Throwable $e) {}
} catch (\Throwable $e) {
    $bannerEnsureOk = false;
    $bannerEnsureError = $e->getMessage();
}
$banner = (object)[
    'cHeadline' => 'Besuchen Sie uns auf der HanseMesse Rostock',
    'cSub1'     => 'Boot & Angeln Camping',
    'cSub2'     => '',
    'cSub3'     => '20. bis 22. März 2026 | HanseMesse Rostock',
    'nSub1Active' => 1,
    'nSub2Active' => 1,
    'nSub3Active' => 1,
    'cSub2ButtonLabel' => 'Aktif et',
    'cSub2ButtonUrl' => '#',
];

// Ensure snapshot tables exist (same as Bootstrap, but admin can be visited standalone)
try {
    $db->executeQuery(
        "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_hersteller (
            kID INT AUTO_INCREMENT PRIMARY KEY,
            kSprache INT NOT NULL,
            cTyp VARCHAR(255) NOT NULL DEFAULT '',
            cHersteller VARCHAR(255) NOT NULL DEFAULT '',
            UNIQUE KEY uq_opt_her (kSprache, cTyp, cHersteller),
            KEY idx_opt_her (kSprache, cTyp),
            KEY idx_opt_her2 (kSprache, cHersteller)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    $db->executeQuery(
        "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_basis (
            kID INT AUTO_INCREMENT PRIMARY KEY,
            kSprache INT NOT NULL,
            cTyp VARCHAR(255) NOT NULL DEFAULT '',
            cHersteller VARCHAR(255) NOT NULL DEFAULT '',
            cBasis VARCHAR(255) NOT NULL DEFAULT '',
            UNIQUE KEY uq_opt_basis (kSprache, cTyp, cHersteller, cBasis),
            KEY idx_opt_basis (kSprache, cTyp, cHersteller),
            KEY idx_opt_basis2 (kSprache, cBasis)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    $db->executeQuery(
        "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_modell (
            kID INT AUTO_INCREMENT PRIMARY KEY,
            kSprache INT NOT NULL,
            cTyp VARCHAR(255) NOT NULL DEFAULT '',
            cHersteller VARCHAR(255) NOT NULL DEFAULT '',
            cBasis VARCHAR(255) NOT NULL DEFAULT '',
            cModell VARCHAR(255) NOT NULL DEFAULT '',
            UNIQUE KEY uq_opt_modell (kSprache, cTyp, cHersteller, cBasis, cModell),
            KEY idx_opt_modell (kSprache, cTyp, cHersteller, cBasis),
            KEY idx_opt_modell2 (kSprache, cModell)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    $db->executeQuery(
        "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_meta (
            kID INT AUTO_INCREMENT PRIMARY KEY,
            dRefreshed DATETIME NOT NULL,
            kSprache INT NOT NULL DEFAULT 0,
            cNote VARCHAR(255) NOT NULL DEFAULT ''
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
} catch (\Throwable $e) {
    // ignore
}

// Eğer POST geldiyse ama token geçersizse, kullanıcıya net göster.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !Form::validateToken()) {
    $message = 'Token hatası: Form oturumu geçersiz. Sayfayı yenileyip tekrar kaydedin.';
}

// Cache/log clear actions
if (Form::validateToken()) {
    try {
        if (!empty($_POST['fkRefreshOptionsSnapshot'])) {
            // Build snapshot for current language AND default language 1
            $langIDs = [(int)Shop::getLanguageID()];
            if (!\in_array(1, $langIDs, true)) {
                $langIDs[] = 1;
            }

            foreach ($langIDs as $lid) {
                $db->executeQueryPrepared('DELETE FROM twomosi_fk_opt_hersteller WHERE kSprache = :lid', ['lid' => $lid]);
                $db->executeQueryPrepared('DELETE FROM twomosi_fk_opt_basis WHERE kSprache = :lid', ['lid' => $lid]);
                $db->executeQueryPrepared('DELETE FROM twomosi_fk_opt_modell WHERE kSprache = :lid', ['lid' => $lid]);

                // Hersteller by Typ
                $db->executeQueryPrepared(
                    "INSERT IGNORE INTO twomosi_fk_opt_hersteller (kSprache, cTyp, cHersteller)
                     SELECT DISTINCT :lid AS kSprache, tmws_typ.cWert AS cTyp, tmws_her.cWert AS cHersteller
                       FROM tartikel a
                 INNER JOIN tartikelmerkmal am_typ ON am_typ.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                 INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
                 INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                                  AND ms_typ.kSprache = :lid
                                                  AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                 INNER JOIN tmerkmalwertsprache tmws_typ ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                                                        AND tmws_typ.kSprache     = :lid
                 INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                 INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
                 INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                                  AND ms_her.kSprache = :lid
                                                  AND ms_her.cName    = 'Fahrzeug-Marke'
                 INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                        AND tmws_her.kSprache     = :lid
                      WHERE a.nIstVater = 0
                        AND TRIM(tmws_typ.cWert) <> ''
                        AND TRIM(tmws_her.cWert) <> ''",
                    ['lid' => $lid]
                );

                // Basis by Typ+Hersteller
                $db->executeQueryPrepared(
                    "INSERT IGNORE INTO twomosi_fk_opt_basis (kSprache, cTyp, cHersteller, cBasis)
                     SELECT DISTINCT :lid AS kSprache, tmws_typ.cWert AS cTyp, tmws_her.cWert AS cHersteller, tmws_basis.cWert AS cBasis
                       FROM tartikel a
                 INNER JOIN tartikelmerkmal am_typ ON am_typ.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                 INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
                 INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                                  AND ms_typ.kSprache = :lid
                                                  AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                 INNER JOIN tmerkmalwertsprache tmws_typ ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                                                        AND tmws_typ.kSprache     = :lid
                 INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                 INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
                 INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                                  AND ms_her.kSprache = :lid
                                                  AND ms_her.cName    = 'Fahrzeug-Marke'
                 INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                        AND tmws_her.kSprache     = :lid
                 INNER JOIN tartikelmerkmal am_basis ON am_basis.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_basis    ON mw_basis.kMerkmalWert = am_basis.kMerkmalWert
                 INNER JOIN tmerkmal m_basis         ON m_basis.kMerkmal = mw_basis.kMerkmal
                 INNER JOIN tmerkmalsprache ms_basis ON ms_basis.kMerkmal = m_basis.kMerkmal
                                                    AND ms_basis.kSprache = :lid
                                                    AND ms_basis.cName    = 'Wohnmobil-Fahrgestell'
                 INNER JOIN tmerkmalwertsprache tmws_basis ON tmws_basis.kMerkmalWert = mw_basis.kMerkmalWert
                                                          AND tmws_basis.kSprache     = :lid
                      WHERE a.nIstVater = 0
                        AND TRIM(tmws_typ.cWert) <> ''
                        AND TRIM(tmws_her.cWert) <> ''
                        AND TRIM(tmws_basis.cWert) <> ''",
                    ['lid' => $lid]
                );

                // Modell by Typ+Hersteller+Basis
                $db->executeQueryPrepared(
                    "INSERT IGNORE INTO twomosi_fk_opt_modell (kSprache, cTyp, cHersteller, cBasis, cModell)
                     SELECT DISTINCT :lid AS kSprache, tmws_typ.cWert AS cTyp, tmws_her.cWert AS cHersteller, tmws_basis.cWert AS cBasis, tmws_mod.cWert AS cModell
                       FROM tartikel a
                 INNER JOIN tartikelmerkmal am_typ ON am_typ.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                 INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
                 INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                                  AND ms_typ.kSprache = :lid
                                                  AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
                 INNER JOIN tmerkmalwertsprache tmws_typ ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                                                        AND tmws_typ.kSprache     = :lid
                 INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                 INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
                 INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                                  AND ms_her.kSprache = :lid
                                                  AND ms_her.cName    = 'Fahrzeug-Marke'
                 INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                        AND tmws_her.kSprache     = :lid
                 INNER JOIN tartikelmerkmal am_basis ON am_basis.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_basis    ON mw_basis.kMerkmalWert = am_basis.kMerkmalWert
                 INNER JOIN tmerkmal m_basis         ON m_basis.kMerkmal = mw_basis.kMerkmal
                 INNER JOIN tmerkmalsprache ms_basis ON ms_basis.kMerkmal = m_basis.kMerkmal
                                                    AND ms_basis.kSprache = :lid
                                                    AND ms_basis.cName    = 'Wohnmobil-Fahrgestell'
                 INNER JOIN tmerkmalwertsprache tmws_basis ON tmws_basis.kMerkmalWert = mw_basis.kMerkmalWert
                                                          AND tmws_basis.kSprache     = :lid
                 INNER JOIN tartikelmerkmal am_mod ON am_mod.kArtikel = a.kArtikel
                 INNER JOIN tmerkmalwert mw_mod    ON mw_mod.kMerkmalWert = am_mod.kMerkmalWert
                 INNER JOIN tmerkmal m_mod         ON m_mod.kMerkmal = mw_mod.kMerkmal
                 INNER JOIN tmerkmalsprache ms_mod ON ms_mod.kMerkmal = m_mod.kMerkmal
                                                  AND ms_mod.kSprache = :lid
                                                  AND ms_mod.cName    = 'Fahrzeug-Modell'
                 INNER JOIN tmerkmalwertsprache tmws_mod ON tmws_mod.kMerkmalWert = mw_mod.kMerkmalWert
                                                        AND tmws_mod.kSprache     = :lid
                      WHERE a.nIstVater = 0
                        AND TRIM(tmws_typ.cWert) <> ''
                        AND TRIM(tmws_her.cWert) <> ''
                        AND TRIM(tmws_basis.cWert) <> ''
                        AND TRIM(tmws_mod.cWert) <> ''",
                    ['lid' => $lid]
                );

                $db->executeQueryPrepared(
                    'INSERT INTO twomosi_fk_opt_meta (dRefreshed, kSprache, cNote) VALUES (NOW(), :lid, :note)',
                    ['lid' => $lid, 'note' => 'dashboard refresh']
                );
            }

            $message = 'Options snapshot güncellendi (hersteller/basis/modell).';
        }
        if (!empty($_POST['fkClearStep4Cache'])) {
            $db->executeQuery('DELETE FROM twomosi_step4_cache');
            $message = 'Step 4 cache temizlendi.';
        }
        if (!empty($_POST['fkClearQueryLog'])) {
            $db->executeQuery('DELETE FROM twomosi_fk_search_log');
            $message = 'Query loglar temizlendi.';
        }
        if (!empty($_POST['fkSaveBanner'])) {
            if (!$bannerEnsureOk) {
                throw new \RuntimeException('Banner tablosu oluşturulamadı: ' . $bannerEnsureError);
            }
            $headline = trim((string)($_POST['fkBannerHeadline'] ?? ''));
            $sub1     = trim((string)($_POST['fkBannerSub1'] ?? ''));
            $sub3     = trim((string)($_POST['fkBannerSub3'] ?? ''));
            $nSub1    = !empty($_POST['fkSub1Active']) ? 1 : 0;
            $nSub2    = !empty($_POST['fkSub2Active']) ? 1 : 0;
            $nSub3    = !empty($_POST['fkSub3Active']) ? 1 : 0;
            $btnLabel = trim((string)($_POST['fkSub2ButtonLabel'] ?? 'Aktif et'));
            $btnUrl   = trim((string)($_POST['fkSub2ButtonUrl'] ?? '#'));
            if ($btnLabel === '') {
                $btnLabel = 'Aktif et';
            }
            if ($btnUrl === '') {
                $btnUrl = '#';
            }

            // Her zaman en güncel satırı güncelle (tabloda birden fazla satır olabilir)
            $row = $db->getSingleObject('SELECT kID FROM twomosi_fk_banner ORDER BY dUpdated DESC, kID DESC LIMIT 1');
            if ($row !== null && !empty($row->kID)) {
                $db->executeQueryPrepared(
                    "UPDATE twomosi_fk_banner
                        SET cHeadline = :h, cSub1 = :s1, cSub3 = :s3,
                            nSub1Active = :n1, nSub2Active = :n2, nSub3Active = :n3,
                            cSub2ButtonLabel = :bl, cSub2ButtonUrl = :bu,
                            dUpdated = NOW()
                      WHERE kID = :id",
                    [
                        'h'  => $headline,
                        's1' => $sub1,
                        's3' => $sub3,
                        'n1' => $nSub1,
                        'n2' => $nSub2,
                        'n3' => $nSub3,
                        'bl' => $btnLabel,
                        'bu' => $btnUrl,
                        'id' => (int)$row->kID,
                    ]
                );
            } else {
                $db->executeQueryPrepared(
                    "INSERT INTO twomosi_fk_banner (cHeadline, cSub1, cSub2, cSub3, nSub1Active, nSub2Active, nSub3Active, cSub2ButtonLabel, cSub2ButtonUrl, dUpdated)
                     VALUES (:h, :s1, '', :s3, :n1, :n2, :n3, :bl, :bu, NOW())",
                    [
                        'h'  => $headline,
                        's1' => $sub1,
                        's3' => $sub3,
                        'n1' => $nSub1,
                        'n2' => $nSub2,
                        'n3' => $nSub3,
                        'bl' => $btnLabel,
                        'bu' => $btnUrl,
                    ]
                );
            }
            // Kaydetme sonrası tekrar DB'den çekip ekranda hemen göster (en güncel satır).
            $bannerRow = $db->getSingleObject('SELECT * FROM twomosi_fk_banner ORDER BY dUpdated DESC, kID DESC LIMIT 1');
            if ($bannerRow !== null) {
                $banner = $bannerRow;
                $message = 'Banner içeriği kaydedildi. (kID=' . (int)($bannerRow->kID ?? 0) . ')';
            } else {
                $message = 'Banner içeriği kaydedildi ancak tekrar okunamadı.';
            }
        }
    } catch (\Throwable $e) {
        $message = 'İşlem başarısız: ' . $e->getMessage();
    }
}

$tab = isset($_GET['tab']) ? (string)$_GET['tab'] : 'logs';
if (!\in_array($tab, ['logs', 'summary', 'settings', 'banner'], true)) {
    $tab = 'logs';
}

$cacheCount = 0;
$logCount   = 0;
$selCount   = 0;
$optHerCnt  = 0;
$optBasCnt  = 0;
$optModCnt  = 0;
$optLast    = '';
try {
    $cacheCountRow = $db->getSingleObject('SELECT COUNT(*) AS cnt FROM twomosi_step4_cache');
    $cacheCount = isset($cacheCountRow->cnt) ? (int)$cacheCountRow->cnt : 0;

    $logCountRow = $db->getSingleObject('SELECT COUNT(*) AS cnt FROM twomosi_fk_search_log');
    $logCount = isset($logCountRow->cnt) ? (int)$logCountRow->cnt : 0;

    $selCountRow = $db->getSingleObject('SELECT COUNT(*) AS cnt FROM twomosi_fk_selection');
    $selCount = isset($selCountRow->cnt) ? (int)$selCountRow->cnt : 0;

    $optHerCntRow = $db->getSingleObject('SELECT COUNT(*) AS cnt FROM twomosi_fk_opt_hersteller');
    $optHerCnt = isset($optHerCntRow->cnt) ? (int)$optHerCntRow->cnt : 0;
    $optBasCntRow = $db->getSingleObject('SELECT COUNT(*) AS cnt FROM twomosi_fk_opt_basis');
    $optBasCnt = isset($optBasCntRow->cnt) ? (int)$optBasCntRow->cnt : 0;
    $optModCntRow = $db->getSingleObject('SELECT COUNT(*) AS cnt FROM twomosi_fk_opt_modell');
    $optModCnt = isset($optModCntRow->cnt) ? (int)$optModCntRow->cnt : 0;
    $optLastRow = $db->getSingleObject('SELECT dRefreshed FROM twomosi_fk_opt_meta ORDER BY dRefreshed DESC, kID DESC LIMIT 1');
    $optLast = isset($optLastRow->dRefreshed) ? (string)$optLastRow->dRefreshed : '';
} catch (\Throwable $e) {
    $cacheCount = 0;
    $logCount   = 0;
    $selCount   = 0;
    $optHerCnt  = 0;
    $optBasCnt  = 0;
    $optModCnt  = 0;
    $optLast    = '';
}

try {
    $bannerRow = $db->getSingleObject('SELECT * FROM twomosi_fk_banner ORDER BY dUpdated DESC, kID DESC LIMIT 1');
    if ($bannerRow !== null) {
        $banner = $bannerRow;
    }
} catch (\Throwable $e) {
    // keep default values if table does not exist yet
}

$page  = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page  = $page > 0 ? $page : 1;
$limit = 50;
$offset = ($page - 1) * $limit;

$rows    = [];
$selRows = [];

if ($tab === 'summary') {
    try {
        $selRows = $db->getObjects(
                "SELECT dCreated, cIP, cHersteller, cBasis, cModell, cBaujahr, cSitz, cSerie
               FROM twomosi_fk_selection
              ORDER BY dCreated DESC
              LIMIT " . (int)$limit . " OFFSET " . (int)$offset
        );
    } catch (\Throwable $e) {
        $selRows = [];
    }
} else {
    try {
        $rows = $db->getObjects(
            "SELECT cIP, dCreated, cMode, cField, cParams, nDurationMs, cUserAgent
               FROM twomosi_fk_search_log
              ORDER BY dCreated DESC
              LIMIT " . (int)$limit . " OFFSET " . (int)$offset
        );
    } catch (\Throwable $e) {
        $rows = [];
    }
}
?>

<div style="padding: 10px 0;">
    <h2 style="margin: 0 0 12px;"><?= htmlspecialchars((string)($message ? $message : 'Filter Konfigurator Dashboard')) ?></h2>

    <div style="margin-bottom: 14px; display: flex; gap: 10px; align-items: center;">
        <a href="?tab=logs" style="text-decoration: none; padding: 8px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 8px; <?= $tab === 'logs' ? 'background: rgba(204,255,0,.15);' : '' ?>">Log</a>
        <a href="?tab=summary" style="text-decoration: none; padding: 8px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 8px; <?= $tab === 'summary' ? 'background: rgba(204,255,0,.15);' : '' ?>">Step4 Seçim Özeti</a>
        <a href="?tab=banner" style="text-decoration: none; padding: 8px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 8px; <?= $tab === 'banner' ? 'background: rgba(204,255,0,.15);' : '' ?>">Banner</a>
        <a href="?tab=settings" style="text-decoration: none; padding: 8px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 8px; <?= $tab === 'settings' ? 'background: rgba(204,255,0,.15);' : '' ?>">Ayarlar</a>
    </div>

    <div style="margin-bottom: 16px;">
        <div><b>Step 4 cache kaydı:</b> <?= (int)$cacheCount ?></div>
        <div><b>Query log kayıtları:</b> <?= (int)$logCount ?></div>
        <div><b>Step4 seçim kayıtları:</b> <?= (int)$selCount ?></div>
        <div><b>Options snapshot:</b> hersteller=<?= (int)$optHerCnt ?>, basis=<?= (int)$optBasCnt ?>, modell=<?= (int)$optModCnt ?> <?= $optLast ? '(son: ' . htmlspecialchars($optLast) . ')' : '' ?></div>
    </div>

    <?php if ($tab === 'settings'): ?>
        <div style="margin-bottom: 18px; padding: 12px; border: 1px solid rgba(0,0,0,.08); border-radius: 8px;">
            <h3 style="margin-top: 0;">Ayarlar</h3>

            <form method="post" style="display: flex; gap: 10px; flex-wrap: wrap;">
                <?= Form::getTokenInput(); ?>
                <button type="submit" name="fkRefreshOptionsSnapshot" value="1" style="padding: 8px 12px;">Options snapshot yenile</button>
                <button type="submit" name="fkClearStep4Cache" value="1" style="padding: 8px 12px;">Step 4 cache temizle</button>
                <button type="submit" name="fkClearQueryLog" value="1" style="padding: 8px 12px;">Query log temizle</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if ($tab === 'banner'): ?>
        <div style="padding: 12px; border: 1px solid rgba(0,0,0,.08); border-radius: 8px; max-width: 760px;">
            <h3 style="margin-top: 0;">Banner Düzenleme</h3>

            <form method="post" style="display: grid; gap: 10px;">
                <?= Form::getTokenInput(); ?>

                <div>
                    <label for="fkBannerHeadline"><strong>Headline</strong></label><br>
                    <input type="text" id="fkBannerHeadline" name="fkBannerHeadline"
                           value="<?= htmlspecialchars((string)($banner->cHeadline ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                           style="width:100%; padding:8px;">
                </div>

                <div style="border:1px solid rgba(0,0,0,.08); border-radius:8px; padding:10px; margin-bottom:8px;">
                    <label style="display:flex; align-items:center; gap:8px; font-weight:700;">
                        <input type="checkbox" name="fkSub1Active" value="1" <?= (int)($banner->nSub1Active ?? 0) === 1 ? 'checked' : '' ?>>
                        Sub 1 yayında (aktif)
                    </label>
                    <label for="fkBannerSub1" style="display:block; margin-top:8px;">Metin</label>
                    <input type="text" id="fkBannerSub1" name="fkBannerSub1"
                           value="<?= htmlspecialchars((string)($banner->cSub1 ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                           style="width:100%; padding:8px;">
                </div>

                <div style="border:1px solid rgba(0,0,0,.08); border-radius:8px; padding:10px; margin-bottom:8px;">
                    <label style="display:flex; align-items:center; gap:8px; font-weight:700;">
                        <input type="checkbox" name="fkSub2Active" value="1" <?= (int)($banner->nSub2Active ?? 0) === 1 ? 'checked' : '' ?>>
                        Sub 2 — buton göster (aktif)
                    </label>
                    <p style="margin:8px 0 0; font-size:12px; color:rgba(0,0,0,.55);">Eski düz metin yerine tek bir buton (başlık + yönlendirme).</p>
                    <div style="margin-top:10px; display:grid; gap:8px;">
                        <div>
                            <label for="fkSub2ButtonLabel">Buton adı</label><br>
                            <input type="text" id="fkSub2ButtonLabel" name="fkSub2ButtonLabel"
                                   value="<?= htmlspecialchars((string)($banner->cSub2ButtonLabel ?? 'Aktif et'), ENT_QUOTES, 'UTF-8') ?>"
                                   placeholder="Aktif et"
                                   style="width:100%; padding:8px;">
                        </div>
                        <div>
                            <label for="fkSub2ButtonUrl">Yönlendirme linki</label><br>
                            <input type="text" id="fkSub2ButtonUrl" name="fkSub2ButtonUrl"
                                   value="<?= htmlspecialchars((string)($banner->cSub2ButtonUrl ?? '#'), ENT_QUOTES, 'UTF-8') ?>"
                                   placeholder="https://..."
                                   style="width:100%; padding:8px;">
                        </div>
                    </div>
                </div>

                <div style="border:1px solid rgba(0,0,0,.08); border-radius:8px; padding:10px; margin-bottom:8px;">
                    <label style="display:flex; align-items:center; gap:8px; font-weight:700;">
                        <input type="checkbox" name="fkSub3Active" value="1" <?= (int)($banner->nSub3Active ?? 0) === 1 ? 'checked' : '' ?>>
                        Sub 3 yayında (aktif)
                    </label>
                    <label for="fkBannerSub3" style="display:block; margin-top:8px;">Metin</label>
                    <input type="text" id="fkBannerSub3" name="fkBannerSub3"
                           value="<?= htmlspecialchars((string)($banner->cSub3 ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                           style="width:100%; padding:8px;">
                </div>

                <div>
                    <button type="submit" name="fkSaveBanner" value="1" style="padding: 8px 14px;">
                        Kaydet
                    </button>
                </div>
            </form>
        </div>
    <?php elseif ($tab === 'summary'): ?>
        <div style="padding: 12px; border: 1px solid rgba(0,0,0,.08); border-radius: 8px;">
            <h3 style="margin-top: 0;">Step 4 - Serie seçimi sonrası</h3>

            <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                <thead>
                    <tr>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px; white-space: nowrap;">Tarih</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px; white-space: nowrap;">IP</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Fahrzeug-Marke</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Wohnmobil-Fahrgestell</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Fahrzeug-Modell</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px; white-space: nowrap;">Baujahr</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px; white-space: nowrap;">Sitz</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Serie</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($selRows as $r): ?>
                    <tr>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px; white-space: nowrap;"><?= htmlspecialchars((string)($r->dCreated ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px; white-space: nowrap;"><?= htmlspecialchars((string)($r->cIP ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px;"><?= htmlspecialchars((string)($r->cHersteller ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px;"><?= htmlspecialchars((string)($r->cBasis ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px;"><?= htmlspecialchars((string)($r->cModell ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px; white-space: nowrap;"><?= htmlspecialchars((string)($r->cBaujahr ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px; white-space: nowrap;"><?= htmlspecialchars((string)($r->cSitz ?? '')) ?></td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 10px;"><?= htmlspecialchars((string)($r->cSerie ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!\count($selRows)): ?>
                    <tr><td colspan="8" style="padding: 12px; color: rgba(0,0,0,.6);">Henüz seçim özeti yok.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <div style="margin-top: 12px; display: flex; gap: 10px; align-items: center;">
                <div>Sayfa: <?= (int)$page ?></div>
                <a href="?tab=summary&page=<?= (int)max(1, $page - 1) ?>" style="text-decoration: none; padding: 6px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 6px;">
                    &laquo; Önceki
                </a>
                <a href="?tab=summary&page=<?= (int)($page + 1) ?>" style="text-decoration: none; padding: 6px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 6px;">
                    Sonraki &raquo;
                </a>
            </div>
        </div>
    <?php else: ?>
        <div style="padding: 12px; border: 1px solid rgba(0,0,0,.08); border-radius: 8px;">
            <h3 style="margin-top: 0;">Son sorgular</h3>

            <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                <thead>
                    <tr>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Tarih</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">IP</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Mode</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Field</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Süre (ms)</th>
                        <th style="text-align: left; border-bottom: 1px solid #ddd; padding: 6px;">Params</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <?php
                        $paramsArr = json_decode((string)($r->cParams ?? ''), true);
                        if (!is_array($paramsArr)) {
                            $paramsArr = [];
                        }
                    ?>
                    <tr>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 6px; white-space: nowrap;">
                            <?= htmlspecialchars((string)($r->dCreated ?? '')) ?>
                        </td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 6px; white-space: nowrap;">
                            <?= htmlspecialchars((string)($r->cIP ?? '')) ?>
                        </td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 6px; white-space: nowrap;">
                            <?= htmlspecialchars((string)($r->cMode ?? '')) ?>
                        </td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 6px; white-space: nowrap;">
                            <?= htmlspecialchars((string)($r->cField ?? '')) ?>
                        </td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 6px; white-space: nowrap;">
                            <?= htmlspecialchars((string)($r->nDurationMs ?? 0)) ?>
                        </td>
                        <td style="border-bottom: 1px solid #f0f0f0; padding: 6px;">
                            <pre style="margin: 0; white-space: pre-wrap; word-break: break-word;"><?= htmlspecialchars(\json_encode($paramsArr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?></pre>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!\count($rows)): ?>
                    <tr><td colspan="6" style="padding: 12px; color: rgba(0,0,0,.6);">Henüz log yok.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <div style="margin-top: 12px; display: flex; gap: 10px; align-items: center;">
                <div>Sayfa: <?= (int)$page ?></div>
                <a href="?tab=logs&page=<?= (int)max(1, $page - 1) ?>" style="text-decoration: none; padding: 6px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 6px;">
                    &laquo; Önceki
                </a>
                <a href="?tab=logs&page=<?= (int)($page + 1) ?>" style="text-decoration: none; padding: 6px 10px; border: 1px solid rgba(0,0,0,.15); border-radius: 6px;">
                    Sonraki &raquo;
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

