<?php

namespace Plugin\CardProduct;

require_once __DIR__ . '/src/CardProductDatabase.php';

use JTL\Events\Dispatcher;
use JTL\phpQuery\phpQuery;
use JTL\Plugin\Bootstrapper;
use JTL\Shop;
use JTL\Smarty\JTLSmarty;

class Bootstrap extends Bootstrapper
{
    private static bool $adminMenuEnsured = false;

    public function boot(Dispatcher $dispatcher): void
    {
        parent::boot($dispatcher);

        $this->ensureAdminMenuEntry();

        $dispatcher->hookInto(\HOOK_LETZTERINCLUDE_CSS_JS, function (array &$args): void {
            if (!$this->isHomepageRequest()) {
                return;
            }
            if (!isset($args['cPluginCss_arr']) || !\is_array($args['cPluginCss_arr'])) {
                $args['cPluginCss_arr'] = [];
            }
            $cssPath = 'plugins/CardProduct/templates/css/cardproduct.css';
            if (!\in_array($cssPath, $args['cPluginCss_arr'], true)) {
                $args['cPluginCss_arr'][] = $cssPath;
            }
        });

        // CardProduct bloğunu anasayfa HTML'ine enjekte et (FilterKonfigurator mantığı ile)
        $dispatcher->hookInto(\HOOK_SMARTY_OUTPUTFILTER, function (array &$args): void {
            if (!$this->isHomepageRequest()) {
                return;
            }
            CardProductDatabase::ensureAll();
            if (!isset($args['smarty'], $args['document'])) {
                return;
            }
            /** @var JTLSmarty $smarty */
            $smarty = $args['smarty'];
            $doc    = $args['document'];

            // Load cards from monthly cache (fallback: live read)
            $langID = (int)Shop::getLanguageID();
            $this->maybeRefreshCardsCache($langID);
            $cards = $this->loadCardsFromCache($langID) ?? $this->fetchCards();

            // Lightweight cookie: only stores cache timestamp to avoid re-setting
            try {
                $ts = $this->getCardsCacheUpdatedAt($langID);
                if ($ts !== '') {
                    $ck = (string)($_COOKIE['womosi_cp_cache_v'] ?? '');
                    if ($ck !== $ts) {
                        @\setcookie('womosi_cp_cache_v', $ts, [
                            'expires'  => \time() + 86400 * 45,
                            'path'     => '/',
                            'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                            'httponly' => false,
                            'samesite' => 'Lax',
                        ]);
                    }
                }
            } catch (\Throwable $e) {
                // ignore
            }
            $smarty->assign('cardProductCards', $cards);
            $settings = $this->fetchSettings();
            $smarty->assign(
                'cardProductAllModelsUrl',
                rtrim((string)Shop::getURL(), '/') . '/Fahrer-Beifahrer-Set-11'
            );
            $tplPath = $this->getPlugin()->getPaths()->getBasePath() . 'templates/cardproduct_grid.tpl';
            if (!\is_file($tplPath)) {
                return;
            }
            try {
                $html = $smarty->fetch('file:' . $tplPath);
            } catch (\Throwable $e) {
                return;
            }

            if ($html === '' || \strpos($html, 'cardproduct-grid') === false) {
                return;
            }

            // Enjeksiyon hedefi admin ayarından seçilebilir
            $mode = (string)($settings['injectMode'] ?? 'after_configurator');
            $pos = (string)($settings['injectPos'] ?? 'after');
            $selector = trim((string)($settings['injectSelector'] ?? ''));
            $pos = \in_array($pos, ['before', 'after'], true) ? $pos : 'after';

            $injected = false;
            if ($mode === 'after_selector' && $selector !== '') {
                $target = $doc->find($selector)->eq(0);
                if ($target->length > 0) {
                    if ($pos === 'before') {
                        $target->before($html);
                    } else {
                        $target->after($html);
                    }
                    $injected = true;
                }
            }
            if (!$injected && $mode === 'after_content') {
                $content = $doc->find('div#content')->eq(0);
                if ($content->length > 0) {
                    $content->prepend($html);
                    $injected = true;
                }
            }
            if (!$injected) {
                // default: konfigurator sonrası
                $afterConfigurator = $doc->find('div.index-filter-konfigurator')->eq(0);
                if ($afterConfigurator->length > 0) {
                    if ($pos === 'before') {
                        $afterConfigurator->before($html);
                    } else {
                        $afterConfigurator->after($html);
                    }
                    $injected = true;
                }
            }
        });
    }

    /**
     * Startseite: PAGE_STARTSEITE + Pfad-Fallback (Subfolder-Installs).
     */
    private function isHomepageRequest(): bool
    {
        if (Shop::getPageType() === \PAGE_STARTSEITE) {
            return true;
        }
        $uri  = (string)($_SERVER['REQUEST_URI'] ?? '');
        $path = (string)(\parse_url($uri, \PHP_URL_PATH) ?? '');
        $path = \rtrim($path, '/');
        $shopUrl = \rtrim((string)Shop::getURL(), '/');
        $shopBasePath = (string)(\parse_url($shopUrl, \PHP_URL_PATH) ?? '');
        $shopBasePath = \rtrim($shopBasePath, '/');

        return $path === $shopBasePath
            || $path === ($shopBasePath . '/index.php')
            || \str_starts_with($path, $shopBasePath . '/index.php');
    }

    /**
     * @return array<string, string>
     */
    private function fetchSettings(): array
    {
        try {
            $db = Shop::Container()->getDB();
            $s = $db->getSingleObject("SELECT * FROM twomosi_cardproduct_settings ORDER BY kID ASC LIMIT 1");
            if ($s === null) {
                return ['injectMode' => 'after_configurator', 'injectPos' => 'after', 'injectSelector' => '', 'refreshDom' => '1', 'refreshHour' => '3'];
            }
            return [
                'injectMode' => (string)($s->cInjectMode ?? 'after_configurator'),
                'injectPos' => (string)($s->cInjectPos ?? 'after'),
                'injectSelector' => (string)($s->cInjectSelector ?? ''),
                'refreshDom' => (string)($s->nRefreshDom ?? 1),
                'refreshHour' => (string)($s->nRefreshHour ?? 3),
            ];
        } catch (\Throwable $e) {
            return ['injectMode' => 'after_configurator', 'injectPos' => 'after', 'injectSelector' => '', 'refreshDom' => '1', 'refreshHour' => '3'];
        }
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function loadCardsFromCache(int $langID): ?array
    {
        try {
            $db = Shop::Container()->getDB();
            $row = $db->getSingleObject(
                "SELECT cCardsJson FROM twomosi_cardproduct_cache WHERE kSprache = :lid LIMIT 1",
                ['lid' => $langID]
            );
            if ($row === null || !isset($row->cCardsJson)) {
                return null;
            }
            $decoded = \json_decode((string)$row->cCardsJson, true);
            return \is_array($decoded) ? $decoded : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function getCardsCacheUpdatedAt(int $langID): string
    {
        $this->ensureCacheTables();
        try {
            $db = Shop::Container()->getDB();
            $row = $db->getSingleObject(
                "SELECT dUpdated FROM twomosi_cardproduct_cache WHERE kSprache = :lid LIMIT 1",
                ['lid' => $langID]
            );
            return $row !== null ? (string)($row->dUpdated ?? '') : '';
        } catch (\Throwable $e) {
            return '';
        }
    }

    private function maybeRefreshCardsCache(int $langID): void
    {
        try {
            $db = Shop::Container()->getDB();
            $settings = $this->fetchSettings();
            $domTarget = (int)($settings['refreshDom'] ?? 1);
            $hourTarget = (int)($settings['refreshHour'] ?? 3);
            if ($domTarget < 1 || $domTarget > 28) { $domTarget = 1; }
            if ($hourTarget < 0 || $hourTarget > 23) { $hourTarget = 3; }

            $cntRow = $db->getSingleObject(
                "SELECT COUNT(*) AS cnt FROM twomosi_cardproduct_cache WHERE kSprache = :lid",
                ['lid' => $langID]
            );
            $cnt = $cntRow !== null ? (int)($cntRow->cnt ?? 0) : 0;
            $isEmpty = $cnt <= 0;

            $now = new \DateTimeImmutable('now');
            $domNow = (int)$now->format('j');
            $hourNow = (int)$now->format('G');
            $scheduledNow = ($domNow === $domTarget && $hourNow === $hourTarget);

            $key = 'cards_last_refresh_lang_' . $langID;
            $row = $db->getSingleObject("SELECT cValue FROM twomosi_cardproduct_meta WHERE cKey = :k LIMIT 1", ['k' => $key]);
            $last = null;
            if ($row !== null && isset($row->cValue)) {
                try { $last = new \DateTimeImmutable((string)$row->cValue); } catch (\Throwable $e) { $last = null; }
            }
            $olderThanMonth = true;
            if ($last instanceof \DateTimeImmutable) {
                $olderThanMonth = ($last < $now->sub(new \DateInterval('P25D')));
            }

            if ($isEmpty || ($scheduledNow && $olderThanMonth)) {
                $this->rebuildCardsCache($langID);
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    private function rebuildCardsCache(int $langID): void
    {
        try {
            $db = Shop::Container()->getDB();
            $rows = $db->getObjects(
                "SELECT kID, kArtikel, cTitle, cImage, cImages, cUrl, nSort
                   FROM twomosi_cardproduct
                  WHERE nActive = 1
                  ORDER BY nSort ASC, kID ASC"
            );
            if (!\is_array($rows)) {
                $rows = [];
            }

            $needTitle = [];
            foreach ($rows as $r) {
                $t = \trim((string)($r->cTitle ?? ''));
                $kA = (int)($r->kArtikel ?? 0);
                if ($t === '' && $kA > 0) {
                    $needTitle[$kA] = true;
                }
            }

            $titles = [];
            if ($needTitle !== []) {
                $ids = \implode(',', \array_map('intval', \array_keys($needTitle)));
                $tRows = $db->getObjects(
                    "SELECT ts.kArtikel, ts.cName
                       FROM tartikelsprache ts
                      WHERE ts.kSprache = :lid
                        AND ts.kArtikel IN (" . $ids . ")",
                    ['lid' => $langID]
                );
                if (\is_array($tRows)) {
                    foreach ($tRows as $tr) {
                        $kA = (int)($tr->kArtikel ?? 0);
                        $nm = \trim((string)($tr->cName ?? ''));
                        if ($kA > 0 && $nm !== '') {
                            $titles[$kA] = $nm;
                        }
                    }
                }
            }

            $cards = [];
            foreach ($rows as $r) {
                $title = \trim((string)($r->cTitle ?? ''));
                $kArtikel = (int)($r->kArtikel ?? 0);
                if ($title === '' && $kArtikel > 0 && isset($titles[$kArtikel])) {
                    $title = (string)$titles[$kArtikel];
                }

                $imgRaw = (string)($r->cImage ?? '');
                $imgJson = \trim((string)($r->cImages ?? ''));
                $url   = \trim((string)($r->cUrl ?? ''));

                $imgList = [];
                if ($imgJson !== '') {
                    $decoded = \json_decode($imgJson, true);
                    if (\is_array($decoded)) {
                        foreach ($decoded as $entry) {
                            $u = \trim((string)$entry);
                            if ($u !== '') {
                                $imgList[] = $u;
                            }
                        }
                    }
                }
                if (\count($imgList) === 0) {
                    $imgRaw = str_replace("\r\n", "\n", $imgRaw);
                    $imgRaw = str_replace("\r", "\n", $imgRaw);
                    $parts = preg_split('/[\n,;]+/', $imgRaw) ?: [];
                    foreach ($parts as $part) {
                        $u = \trim((string)$part);
                        if ($u !== '') {
                            $imgList[] = $u;
                        }
                    }
                }
                $imgList = array_values(array_unique($imgList));
                $img = $imgList[0] ?? '';

                if ($title === '') { $title = 'Produkt'; }
                if ($url === '') { $url = '#'; }

                $cards[] = [
                    'id'    => (int)($r->kID ?? 0),
                    'title' => $title,
                    'img'   => $img,
                    'imgs'  => $imgList,
                    'url'   => $url,
                ];
            }

            $json = \json_encode($cards, \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES);
            if (!\is_string($json)) {
                return;
            }
            $db->executeQueryPrepared(
                "INSERT INTO twomosi_cardproduct_cache (kSprache, cCardsJson, dUpdated)
                 VALUES (:lid, :j, NOW())
                 ON DUPLICATE KEY UPDATE cCardsJson = VALUES(cCardsJson), dUpdated = NOW()",
                ['lid' => $langID, 'j' => $json]
            );
            $key = 'cards_last_refresh_lang_' . $langID;
            $db->executeQueryPrepared(
                "INSERT INTO twomosi_cardproduct_meta (cKey, cValue)
                 VALUES (:k, :v)
                 ON DUPLICATE KEY UPDATE cValue = VALUES(cValue)",
                ['k' => $key, 'v' => (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s')]
            );
        } catch (\Throwable $e) {
            // ignore
        }
    }

    private function ensureAdminMenuEntry(): void
    {
        if (self::$adminMenuEnsured) {
            return;
        }
        try {
            $db = Shop::Container()->getDB();
            $pluginID = (int)$this->getPlugin()->getID();
            if ($pluginID <= 0) {
                return;
            }

            $file = 'dashboard.php';
            $exists = $db->getSingleObject(
                "SELECT kPluginAdminMenu
                   FROM tpluginadminmenu
                  WHERE kPlugin = :kPlugin
                    AND cDateiname = :cDateiname
                  LIMIT 1",
                ['kPlugin' => $pluginID, 'cDateiname' => $file]
            );

            if ($exists === null) {
                $menuItem = new \stdClass();
                $menuItem->kPlugin    = $pluginID;
                $menuItem->cName      = 'CardProduct Dashboard';
                $menuItem->cDateiname = $file;
                $menuItem->nSort      = 20;
                $menuItem->nConf      = 0;
                $db->insert('tpluginadminmenu', $menuItem);
            }
            self::$adminMenuEnsured = true;
        } catch (\Throwable $e) {
            // no hard fail
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchCards(): array
    {
        try {
            $db = Shop::Container()->getDB();
            $rows = $db->getObjects(
                "SELECT kID, kArtikel, cTitle, cImage, cImages, cUrl, nSort
                   FROM twomosi_cardproduct
                  WHERE nActive = 1
                  ORDER BY nSort ASC, kID ASC"
            );
            if (!\is_array($rows)) {
                return [];
            }
            $cards = [];
            foreach ($rows as $r) {
                $title = \trim((string)($r->cTitle ?? ''));
                $imgRaw = (string)($r->cImage ?? '');
                $imgJson = \trim((string)($r->cImages ?? ''));
                $url   = \trim((string)($r->cUrl ?? ''));
                $kArtikel = (int)($r->kArtikel ?? 0);
                $imgList = [];
                if ($imgJson !== '') {
                    $decoded = \json_decode($imgJson, true);
                    if (\is_array($decoded)) {
                        foreach ($decoded as $entry) {
                            $u = \trim((string)$entry);
                            if ($u !== '') {
                                $imgList[] = $u;
                            }
                        }
                    }
                }
                if (\count($imgList) === 0) {
                    $imgRaw = str_replace("\r\n", "\n", $imgRaw);
                    $imgRaw = str_replace("\r", "\n", $imgRaw);
                    $parts = preg_split('/[\n,;]+/', $imgRaw) ?: [];
                    foreach ($parts as $part) {
                        $u = \trim((string)$part);
                        if ($u !== '') {
                            $imgList[] = $u;
                        }
                    }
                }
                $imgList = array_values(array_unique($imgList));
                $img = $imgList[0] ?? '';

                // If no title provided but product ID exists, try to derive a name.
                if ($title === '' && $kArtikel > 0) {
                    $langID = (int)Shop::getLanguageID();
                    $prod = $db->getSingleObject(
                        "SELECT ts.cName
                           FROM tartikelsprache ts
                          WHERE ts.kArtikel = :kArtikel
                            AND ts.kSprache = :kSprache
                          LIMIT 1",
                        ['kArtikel' => $kArtikel, 'kSprache' => $langID]
                    );
                    if ($prod !== null && !empty($prod->cName)) {
                        $title = (string)$prod->cName;
                    }
                }

                if ($title === '') {
                    $title = 'Produkt';
                }
                if ($url === '') {
                    $url = '#';
                }
                $cards[] = [
                    'id'    => (int)($r->kID ?? 0),
                    'title' => $title,
                    'img'   => $img,
                    'imgs'  => $imgList,
                    'url'   => $url,
                ];
            }
            return $cards;
        } catch (\Throwable $e) {
            return [];
        }
    }
}
