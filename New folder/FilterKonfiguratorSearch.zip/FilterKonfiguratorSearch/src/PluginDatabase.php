<?php

declare(strict_types=1);

namespace Plugin\FilterKonfiguratorSearch;

use JTL\Shop;

/**
 * Plugin tablolarını yalnızca API / selection / admin yollarında oluşturur;
 * her shop isteğinde bootstrap üzerinde DDL çalıştırmaz.
 */
final class PluginDatabase
{
    private static bool $coreEnsured = false;

    public static function ensureCoreTables(): void
    {
        if (self::$coreEnsured) {
            return;
        }

        try {
            $db = Shop::Container()->getDB();

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_step4_cache (
                        cKey CHAR(32) NOT NULL,
                        dUpdated DATETIME NOT NULL,
                        cPayload MEDIUMTEXT NOT NULL,
                        PRIMARY KEY (cKey),
                        KEY idx_dUpdated (dUpdated)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_fk_search_log (
                        kLogID INT AUTO_INCREMENT PRIMARY KEY,
                        cIP VARCHAR(45) NOT NULL,
                        dCreated DATETIME NOT NULL,
                        cMode VARCHAR(32) NOT NULL DEFAULT '',
                        cField VARCHAR(64) NOT NULL DEFAULT '',
                        cParams MEDIUMTEXT NOT NULL,
                        nDurationMs INT NOT NULL DEFAULT 0,
                        cUserAgent VARCHAR(255) NOT NULL DEFAULT ''
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_fk_selection (
                        kID INT AUTO_INCREMENT PRIMARY KEY,
                        cIP VARCHAR(45) NOT NULL,
                        dCreated DATETIME NOT NULL,
                        cTyp VARCHAR(255) NOT NULL DEFAULT '',
                        cHersteller VARCHAR(255) NOT NULL DEFAULT '',
                        cBasis VARCHAR(255) NOT NULL DEFAULT '',
                        cModell VARCHAR(500) NOT NULL DEFAULT '',
                        cBaujahr VARCHAR(16) NOT NULL DEFAULT '',
                        cSitz VARCHAR(255) NOT NULL DEFAULT '',
                        cSerie VARCHAR(255) NOT NULL DEFAULT '',
                        cUserAgent VARCHAR(255) NOT NULL DEFAULT ''
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_hersteller (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    kSprache INT NOT NULL,
                    cTyp VARCHAR(255) NOT NULL DEFAULT '',
                    cHersteller VARCHAR(255) NOT NULL DEFAULT '',
                    UNIQUE KEY uq_opt_her (kSprache, cTyp, cHersteller),
                    KEY idx_opt_her (kSprache, cTyp),
                    KEY idx_opt_her2 (kSprache, cHersteller)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_basis (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    kSprache INT NOT NULL,
                    cTyp VARCHAR(255) NOT NULL DEFAULT '',
                    cHersteller VARCHAR(255) NOT NULL DEFAULT '',
                    cBasis VARCHAR(255) NOT NULL DEFAULT '',
                    UNIQUE KEY uq_opt_basis (kSprache, cTyp, cHersteller, cBasis),
                    KEY idx_opt_basis (kSprache, cTyp, cHersteller),
                    KEY idx_opt_basis2 (kSprache, cBasis)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_modell (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    kSprache INT NOT NULL,
                    cTyp VARCHAR(255) NOT NULL DEFAULT '',
                    cHersteller VARCHAR(255) NOT NULL DEFAULT '',
                    cBasis VARCHAR(255) NOT NULL DEFAULT '',
                    cModell VARCHAR(255) NOT NULL DEFAULT '',
                    UNIQUE KEY uq_opt_modell (kSprache, cTyp, cHersteller, cBasis, cModell),
                    KEY idx_opt_modell (kSprache, cTyp, cHersteller, cBasis),
                    KEY idx_opt_modell2 (kSprache, cModell)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_fk_opt_meta (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    dRefreshed DATETIME NOT NULL,
                    kSprache INT NOT NULL DEFAULT 0,
                    cNote VARCHAR(255) NOT NULL DEFAULT ''
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            self::$coreEnsured = true;
        } catch (\Throwable $e) {
            // DB yoksa veya yetki yoksa sessiz; endpoint kendi hatasını döner.
        }
    }
}
