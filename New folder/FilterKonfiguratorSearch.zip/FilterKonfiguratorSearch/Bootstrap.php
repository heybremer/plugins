<?php

namespace Plugin\FilterKonfiguratorSearch;

require_once __DIR__ . '/src/PluginDatabase.php';
require_once __DIR__ . '/src/Controller/FilterKonfiguratorController.php';

use JTL\Events\Dispatcher;
use JTL\phpQuery\phpQuery;
use JTL\Plugin\Bootstrapper;
use JTL\Router\Router;
use JTL\Smarty\JTLSmarty;
use JTL\Shop;
use JTL\Helpers\Request;
use Plugin\FilterKonfiguratorSearch\Controller\FilterKonfiguratorController;
use Psr\Http\Message\ServerRequestInterface;

class Bootstrap extends Bootstrapper
{
    /**
     * Ensures an admin menu entry exists only once per PHP process.
     */
    private static bool $adminMenuEnsured = false;

    /**
     * Ensures banner settings table exists only once per PHP process.
     */
    private static bool $bannerTableEnsured = false;

    /**
     * APCu / cross-request cache: schema init complete for twomosi_fk_banner (avoids DB on every request).
     */
    private const BANNER_SCHEMA_APCU_KEY = 'womosi_fk_banner_schema_v1';

    /**
     * Register /fk-search route.
     *
     * @param Dispatcher $dispatcher
     */
    public function boot(Dispatcher $dispatcher): void
    {
        parent::boot($dispatcher);

        // Tablo DDL: PluginDatabase::ensureCoreTables() — yalnızca /fk-search ve /fk-selection
        // (ve admin) yollarında; her shop isteğinde bootstrap yükünü artırmaz.
        $this->ensureAdminMenuEntry();

        // CSS/JS: sadece gereken sayfalarda yükle (global yükleme LCP/TTI/TBT'yi ciddi düşürür).
        // - Ana konfigurator CSS + womosi-konfigurator.js → yalnızca Startseite (HTML de orada).
        // - fk-liste-title + fk-manual-model-cart → liste/ürün/warenkorb/checkout + Startseite.
        $dispatcher->hookInto(\HOOK_LETZTERINCLUDE_CSS_JS, function (array &$args): void {
            $pt = Shop::getPageType();
            $isHome = ($pt === \PAGE_STARTSEITE);
            // Liste: sadece PAGE_ARTIKELLISTE değil; filtreli arama / Hersteller / Live-Suche sayfaları da ürün grid'i gösterebilir.
            $needsAuxJs = $isHome
                || $pt === \PAGE_ARTIKEL
                || $pt === \PAGE_ARTIKELLISTE
                || $pt === \PAGE_LIVESUCHE
                || $pt === \PAGE_HERSTELLER
                || $pt === \PAGE_WARENKORB
                || $pt === \PAGE_BESTELLVORGANG;

            if (!$isHome && !$needsAuxJs) {
                return;
            }

            if ($isHome) {
                if (!isset($args['cPluginCss_arr']) || !\is_array($args['cPluginCss_arr'])) {
                    $args['cPluginCss_arr'] = [];
                }
                $cssPath = 'plugins/FilterKonfiguratorSearch/templates/css/womosi-konfigurator.css';
                if (!\in_array($cssPath, $args['cPluginCss_arr'], true)) {
                    $args['cPluginCss_arr'][] = $cssPath;
                }
            }

            if (!isset($args['cPluginJsHead_arr']) || !\is_array($args['cPluginJsHead_arr'])) {
                $args['cPluginJsHead_arr'] = [];
            }

            if ($isHome) {
                $jsPathMain = 'plugins/FilterKonfiguratorSearch/templates/js/womosi-konfigurator.js';
                if (!\in_array($jsPathMain, $args['cPluginJsHead_arr'], true)) {
                    $args['cPluginJsHead_arr'][] = $jsPathMain;
                }
            }

            if ($needsAuxJs) {
                $jsPathListe = 'plugins/FilterKonfiguratorSearch/templates/js/fk-liste-title.js';
                if (!\in_array($jsPathListe, $args['cPluginJsHead_arr'], true)) {
                    $args['cPluginJsHead_arr'][] = $jsPathListe;
                }
                $jsPathManual = 'plugins/FilterKonfiguratorSearch/templates/js/fk-manual-model-cart.js';
                if (!\in_array($jsPathManual, $args['cPluginJsHead_arr'], true)) {
                    $args['cPluginJsHead_arr'][] = $jsPathManual;
                }
            }
        });

        // „Modell nicht in der Liste“ + manueller Text: Warenkorb-Position cName = dynamischer Titel (Wawi/Bestellung)
        $dispatcher->hookInto(\HOOK_WARENKORB_CLASS_FUEGEEIN, function (array &$args): void {
            $this->applyWomosiManualModelCartPositionName($args);
        });

        // Konfigurator bloğunu anasayfa HTML'ine enjekte et (sadece Startseite)
        $dispatcher->hookInto(\HOOK_SMARTY_OUTPUTFILTER, function (array &$args): void {
            if (Shop::getPageType() !== \PAGE_STARTSEITE) {
                return;
            }
            if (!isset($args['smarty'], $args['document'])) {
                return;
            }
            /** @var JTLSmarty $smarty */
            $smarty = $args['smarty'];
            $doc    = $args['document'];

            // Lazy schema: banner table only needed on homepage konfigurator path (not every shop request).
            $this->ensureBannerTable();

            // Banner içeriğini DB'den al ve template'e ver
            try {
                $db = Shop::Container()->getDB();
                // En güncel banner satırı (kID her zaman son güncelleme olmayabilir)
                $banner = $db->getSingleObject('SELECT * FROM twomosi_fk_banner ORDER BY dUpdated DESC, kID DESC LIMIT 1');
                if ($banner !== null) {
                    $banner->nSub1Active = (int)($banner->nSub1Active ?? 1);
                    $banner->nSub2Active = (int)($banner->nSub2Active ?? 1);
                    $banner->nSub3Active = (int)($banner->nSub3Active ?? 1);
                    if (!isset($banner->cSub2ButtonLabel) || trim((string)$banner->cSub2ButtonLabel) === '') {
                        $banner->cSub2ButtonLabel = 'Aktivieren';
                    }
                    if (!isset($banner->cSub2ButtonUrl) || trim((string)$banner->cSub2ButtonUrl) === '') {
                        $banner->cSub2ButtonUrl = '#';
                    }
                    $smarty->assign('fkBanner', $banner);
                } else {
                    $smarty->assign('fkBanner', (object)[
                        'cHeadline' => 'Besuchen Sie uns auf der HanseMesse Rostock',
                        'cSub1'     => 'Boot & Angeln Camping',
                        'cSub2'     => '',
                        'cSub3'     => '20. bis 22. März 2026 | HanseMesse Rostock',
                        'nSub1Active' => 1,
                        'nSub2Active' => 1,
                        'nSub3Active' => 1,
                        'cSub2ButtonLabel' => 'Aktivieren',
                        'cSub2ButtonUrl' => '#',
                    ]);
                }
            } catch (\Throwable $e) {
                $smarty->assign('fkBanner', (object)[
                    'cHeadline' => 'Besuchen Sie uns auf der HanseMesse Rostock',
                    'cSub1'     => 'Boot & Angeln Camping',
                    'cSub2'     => '',
                    'cSub3'     => '20. bis 22. März 2026 | HanseMesse Rostock',
                    'nSub1Active' => 1,
                    'nSub2Active' => 1,
                    'nSub3Active' => 1,
                    'cSub2ButtonLabel' => 'Aktivieren',
                    'cSub2ButtonUrl' => '#',
                ]);
            }

            $tplPath = $this->getPlugin()->getPaths()->getBasePath() . 'templates/filterkonfigurator_index.tpl';
            if (!\is_file($tplPath)) {
                return;
            }
            try {
                $html = $smarty->fetch('file:' . $tplPath);
            } catch (\Throwable $e) {
                return;
            }

            if ($html === '' || \strpos($html, 'index-filter-konfigurator') === false) {
                return;
            }

            $injected = false;

            // 1) phpQuery ile main#main-wrapper
            $main = $doc->find('main#main-wrapper')->eq(0);
            if ($main->length > 0) {
                $main->prepend($html);
                $injected = true;
            }
            // 1.1) Fallback: sadece #main-wrapper id'si varsa ona enjekte et
            if (!$injected) {
                $mainById = $doc->find('#main-wrapper')->eq(0);
                if ($mainById->length > 0) {
                    $mainById->prepend($html);
                    $injected = true;
                }
            }
            if (!$injected) {
                $genericMain = $doc->find('main')->eq(0);
                if ($genericMain->length > 0) {
                    $genericMain->prepend($html);
                    $injected = true;
                }
            }

            // 2) Fallback: phpQuery ile enjekte edilemediyse string ile main açılış etiketinden sonra ekle
            if (!$injected) {
                $full = $doc->htmlOuter();
                $tag  = '<main id="main-wrapper"';
                $pos  = \stripos($full, $tag);
                if ($pos === false) {
                    $pos = \stripos($full, '<main ');
                }
                if ($pos !== false) {
                    $end   = \strpos($full, '>', $pos) + 1;
                    $new   = \substr($full, 0, $end) . $html . \substr($full, $end);
                    $newDoc = phpQuery::newDocumentHTML($new, \JTL_CHARSET);
                    $doc->find('body')->html($newDoc->find('body')->html());
                }
            }
        });

        // Liste + Artikel + Warenkorb + Checkout: Konfigurator-Auswahl (GET/SEO-Pfad); Warenkorb/Checkout meist per fk-liste-title.js (localStorage)
        $dispatcher->hookInto(\HOOK_SMARTY_OUTPUTFILTER, function (array &$args): void {
            $pt = Shop::getPageType();
            if ($pt !== \PAGE_ARTIKEL && $pt !== \PAGE_ARTIKELLISTE && $pt !== \PAGE_WARENKORB && $pt !== \PAGE_BESTELLVORGANG) {
                return;
            }
            if (!isset($args['document'])) {
                return;
            }
            $doc = $args['document'];
            if ($doc->find('.fk-selection-summary')->length > 0) {
                return;
            }

            $items = $this->fkBuildSelectionItemsFromRequest();
            if ($items === []) {
                return;
            }

            $esc = static function (string $s): string {
                return \htmlspecialchars($s, \ENT_QUOTES, 'UTF-8');
            };
            $values = [];
            foreach ($items as $it) {
                $val = trim((string)($it['value'] ?? ''));
                if ($val !== '') {
                    $values[] = $esc($val);
                }
            }
            if ($values === []) {
                return;
            }

            $compactTitle = $this->fkBuildCompactTitleLine($items);
            $isArtikel           = $pt === \PAGE_ARTIKEL;
            $noGreenMessageBlock = $isArtikel || $pt === \PAGE_WARENKORB || $pt === \PAGE_BESTELLVORGANG;

            $countText = '';
            if ($pt === \PAGE_ARTIKELLISTE) {
                try {
                    $outer = (string)$doc->htmlOuter();
                    if (preg_match('/von\s+(\d+)/i', $outer, $m)) {
                        $n = (int)($m[1] ?? 0);
                        if ($n > 0) {
                            $countText = ' (' . $n . ')';
                        }
                    }
                } catch (\Throwable $e) {
                    // ignore
                }
            }

            $messageBlock = '<span class="fk-selection-message"><span class="fk-selection-icon" aria-hidden="true">✔</span> Für Ihr Fahrzeug wurden passende Ergebnisse gefunden' . $countText . '</span>';

            if ($noGreenMessageBlock) {
                // Produkt-, Warenkorb-, Checkout: kein grüner Hinweis; nur H1-Kompaktzeile oder Werte ohne Meldung
                if ($compactTitle !== '') {
                    $subtitle = '';
                } else {
                    $subtitle = '<div class="fk-selection-subtitle text-muted mt-2 mb-1">'
                        . '<div class="fk-selection-values">' . \implode(' ', $values) . '</div>'
                        . '</div>';
                }
            } elseif ($compactTitle !== '') {
                $subtitle = '<div class="fk-selection-subtitle text-muted mt-2 mb-1">'
                    . $messageBlock
                    . '</div>';
            } else {
                $subtitle = '<div class="fk-selection-subtitle text-muted mt-2 mb-1">'
                    . $messageBlock
                    . '<div class="fk-selection-values">' . \implode(' ', $values) . '</div>'
                    . '</div>';
            }

            $html = $subtitle !== ''
                ? '<div class="fk-selection-summary">' . $subtitle . '</div>'
                : '';

            $applyTitle = static function ($node) use ($compactTitle, $html): void {
                if ($compactTitle !== '' && $node->length > 0) {
                    $node->text($compactTitle);
                    $prev = (string)$node->attr('class');
                    $node->attr('class', \trim($prev . ' fk-selection-h1'));
                }
                if ($html !== '') {
                    $node->after($html);
                }
            };

            $title = $doc->find('h1.product-title.h2')->eq(0);
            if ($title->length > 0) {
                $applyTitle($title);
                return;
            }
            $title2 = $doc->find('div.title h1.h2')->eq(0);
            if ($title2->length > 0) {
                $applyTitle($title2);
                return;
            }
            $title3 = $doc->find('div.title h1')->eq(0);
            if ($title3->length > 0) {
                $applyTitle($title3);
                return;
            }
            $title4 = $doc->find('h1.basket-heading')->eq(0);
            if ($title4->length > 0) {
                $applyTitle($title4);
                return;
            }
            $title5 = $doc->find('#checkout h1')->eq(0);
            if ($title5->length > 0) {
                $applyTitle($title5);
            }
        });

        if (\class_exists(FilterKonfiguratorController::class, false)) {
            $dispatcher->hookInto(\HOOK_ROUTER_PRE_DISPATCH, function (array $args): void {
                /** @var Router $router */
                $router = $args['router'];
                $router->addRoute(
                    '/fk-search',
                    function (ServerRequestInterface $request, array $routeArgs, JTLSmarty $smarty) {
                        $controller = new FilterKonfiguratorController();
                        return $controller->search($request, $routeArgs);
                    },
                    'fk-search',
                    ['GET']
                );

                // Step 4 - Seri seçimi sonrası kullanıcı seçimini logla (dashboard tabı için)
                $router->addRoute(
                    '/fk-selection',
                    function (ServerRequestInterface $request, array $routeArgs, JTLSmarty $smarty) {
                        $db = Shop::Container()->getDB();

                        $parsed = $request->getParsedBody();
                        $body   = \is_array($parsed) ? $parsed : [];
                        $query  = $request->getQueryParams();

                        $data = \array_merge($query, $body);

                        $typLabel   = (string)($data['typ'] ?? '');
                        $hersteller = (string)($data['hersteller'] ?? '');
                        $basis       = (string)($data['basis'] ?? '');
                        $modell      = (string)($data['modell'] ?? '');
                        $baujahr     = (string)($data['baujahr'] ?? '');
                        $sitz        = (string)($data['sitz'] ?? '');
                        $serie       = (string)($data['serie'] ?? '');
                        $ua          = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
                        $ip          = Request::getRealIP();

                        try {
                            PluginDatabase::ensureCoreTables();
                            $db->executeQueryPrepared(
                                "INSERT INTO twomosi_fk_selection
                                    (cIP, dCreated, cTyp, cHersteller, cBasis, cModell, cBaujahr, cSitz, cSerie, cUserAgent)
                                 VALUES
                                    (:ip, NOW(), :typ, :herst, :basis, :modell, :baujahr, :sitz, :serie, :ua)",
                                [
                                    'ip'      => $ip,
                                    'typ'     => $typLabel,
                                    'herst'   => $hersteller,
                                    'basis'   => $basis,
                                    'modell'  => $modell,
                                    'baujahr' => $baujahr,
                                    'sitz'    => $sitz,
                                    'serie'   => $serie,
                                    'ua'      => $ua,
                                ]
                            );
                        } catch (\Throwable $e) {
                            // Log başarısızsa endpoint fail etmesin.
                        }

                        return new \Laminas\Diactoros\Response\JsonResponse(['ok' => true], 200);
                    },
                    'fk-selection',
                    ['GET', 'POST']
                );
            });
        }
    }

    /**
     * Creates/migrates twomosi_fk_banner only when needed.
     *
     * - Not called from global boot(): avoids work on every request (admin, API, cron, etc.).
     * - Fast path: APCu flag after successful init (no DB).
     * - Else: one cheap information_schema.tables check; CREATE only if missing; ALTER only for missing columns.
     * - Concurrent requests: CREATE IF NOT EXISTS + conditional ALTER are idempotent; seed uses NOT EXISTS guard.
     */
    private function ensureBannerTable(): void
    {
        if (self::$bannerTableEnsured) {
            return;
        }

        if (\function_exists('apcu_fetch')) {
            try {
                if (@\apcu_fetch(self::BANNER_SCHEMA_APCU_KEY) === true) {
                    self::$bannerTableEnsured = true;

                    return;
                }
            } catch (\Throwable $e) {
                // ignore APCu errors
            }
        }

        try {
            $db = Shop::Container()->getDB();

            $existsRow = $db->getSingleObject(
                "SELECT COUNT(*) AS c
                   FROM information_schema.tables
                  WHERE table_schema = DATABASE()
                    AND table_name = 'twomosi_fk_banner'"
            );
            $tableExists = $existsRow !== null && (int)($existsRow->c ?? 0) > 0;

            if (!$tableExists) {
                $sql = "CREATE TABLE IF NOT EXISTS twomosi_fk_banner (
                            kID INT AUTO_INCREMENT PRIMARY KEY,
                            cHeadline VARCHAR(255) NOT NULL DEFAULT '',
                            cSub1 VARCHAR(255) NOT NULL DEFAULT '',
                            cSub2 VARCHAR(255) NOT NULL DEFAULT '',
                            cSub3 VARCHAR(255) NOT NULL DEFAULT '',
                            nSub1Active TINYINT(1) NOT NULL DEFAULT 1,
                            nSub2Active TINYINT(1) NOT NULL DEFAULT 1,
                            nSub3Active TINYINT(1) NOT NULL DEFAULT 1,
                            cSub2ButtonLabel VARCHAR(255) NOT NULL DEFAULT 'Aktif et',
                            cSub2ButtonUrl VARCHAR(500) NOT NULL DEFAULT '#',
                            dUpdated DATETIME NOT NULL
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
                $db->executeQuery($sql);
            } else {
                // Migrate older installs: add columns only if missing (single round-trip per column check batch).
                $cols = $db->getObjects(
                    "SELECT COLUMN_NAME AS n
                       FROM information_schema.columns
                      WHERE table_schema = DATABASE()
                        AND table_name = 'twomosi_fk_banner'"
                );
                $have = [];
                if (\is_array($cols)) {
                    foreach ($cols as $c) {
                        $have[(string)($c->n ?? '')] = true;
                    }
                }
                if (!isset($have['nSub1Active'])) {
                    $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN nSub1Active TINYINT(1) NOT NULL DEFAULT 1 AFTER cSub3");
                }
                if (!isset($have['nSub2Active'])) {
                    $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN nSub2Active TINYINT(1) NOT NULL DEFAULT 1 AFTER nSub1Active");
                }
                if (!isset($have['nSub3Active'])) {
                    $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN nSub3Active TINYINT(1) NOT NULL DEFAULT 1 AFTER nSub2Active");
                }
                if (!isset($have['cSub2ButtonLabel'])) {
                    $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN cSub2ButtonLabel VARCHAR(255) NOT NULL DEFAULT 'Aktif et' AFTER nSub3Active");
                }
                if (!isset($have['cSub2ButtonUrl'])) {
                    $db->executeQuery("ALTER TABLE twomosi_fk_banner ADD COLUMN cSub2ButtonUrl VARCHAR(500) NOT NULL DEFAULT '#' AFTER cSub2ButtonLabel");
                }
            }

            // Seed defaults once (race-safe enough: duplicate rows are harmless; prefer single row)
            $cnt = $db->getSingleObject('SELECT COUNT(*) AS c FROM twomosi_fk_banner');
            if ($cnt !== null && (int)($cnt->c ?? 0) === 0) {
                $db->executeQueryPrepared(
                    "INSERT INTO twomosi_fk_banner (cHeadline, cSub1, cSub2, cSub3, nSub1Active, nSub2Active, nSub3Active, cSub2ButtonLabel, cSub2ButtonUrl, dUpdated)
                     VALUES (:h, :s1, :s2, :s3, 1, 1, 1, :btn, :url, NOW())",
                    [
                        'h'  => 'Besuchen Sie uns auf der HanseMesse Rostock',
                        's1' => 'Boot & Angeln Camping',
                        's2' => 'Bremer-Sitzbezüge GmbH | Stand Nr: C19',
                        's3' => '20. bis 22. März 2026 | HanseMesse Rostock',
                        'btn' => 'Aktivieren',
                        'url' => '#',
                    ]
                );
            }

            self::$bannerTableEnsured = true;

            if (\function_exists('apcu_store')) {
                try {
                    @\apcu_store(self::BANNER_SCHEMA_APCU_KEY, true, 604800);
                } catch (\Throwable $e) {
                    // ignore
                }
            }
        } catch (\Throwable $e) {
            // Avoid breaking plugin if DB is not available yet.
        }
    }

    /**
     * Nur „Modell nicht in der Liste“ + manueller Text: Warenkorb-Position cName setzen (Anzeige + JTL-Bestellung/Wawi).
     *
     * @param array{kArtikel?:int,oPosition_arr?:mixed} $args
     */
    private function applyWomosiManualModelCartPositionName(array &$args): void
    {
        try {
            $manual = Request::postVar('fk_womosi_manual', '');
            if ($manual !== '1' && \strtolower((string)$manual) !== 'true') {
                return;
            }
            $raw = (string)Request::postVar('fk_womosi_dyn_title', '');
            $dyn = \trim($raw);
            if ($dyn === '') {
                return;
            }
            $dyn = \trim(\preg_replace('/\s+/u', ' ', \strip_tags($dyn)) ?? '');
            if ($dyn === '') {
                return;
            }
            if (\mb_strlen($dyn) > 255) {
                $dyn = \mb_substr($dyn, 0, 252) . '…';
            }
            if (!isset($args['oPosition_arr']) || !\is_array($args['oPosition_arr'])) {
                return;
            }
            $positions = &$args['oPosition_arr'];
            $kArtikel  = (int)($args['kArtikel'] ?? 0);
            if ($kArtikel <= 0) {
                return;
            }
            $target = null;
            for ($i = \count($positions) - 1; $i >= 0; $i--) {
                $p = $positions[$i];
                if (!\is_object($p)) {
                    continue;
                }
                if ((int)$p->nPosTyp !== \C_WARENKORBPOS_TYP_ARTIKEL) {
                    continue;
                }
                if ((int)$p->kArtikel !== $kArtikel) {
                    continue;
                }
                $target = $p;
                break;
            }
            if ($target === null) {
                return;
            }
            if (\is_array($target->cName)) {
                foreach (\array_keys($target->cName) as $code) {
                    $target->cName[$code] = $dyn;
                }
            } else {
                $target->cName = $dyn;
            }
        } catch (\Throwable $e) {
            // absichtlich still
        }
    }

    /**
     * Eine Zeile für H1: Fahrzeugtyp, Marke, Fahrgestell, Modell, optional „Model {Baujahr}“ (ohne Serie/Sitze).
     *
     * @param array<int, array{label:string,value:string}> $items
     */
    private function fkBuildCompactTitleLine(array $items): string
    {
        $byLabel = [];
        foreach ($items as $it) {
            $l = (string)($it['label'] ?? '');
            $byLabel[$l] = \trim((string)($it['value'] ?? ''));
        }
        $order = ['Fahrzeugtyp', 'Fahrzeug-Marke', 'Wohnmobil-Fahrgestell', 'Fahrzeug-Modell', 'Baujahr'];
        $parts = [];
        foreach ($order as $label) {
            $val = $byLabel[$label] ?? '';
            if ($val === '') {
                continue;
            }
            if ($label === 'Baujahr') {
                $parts[] = 'Model ' . $val;
            } else {
                $parts[] = $val;
            }
        }

        return \trim(\implode(' ', $parts));
    }

    /**
     * Auswahl aus ?typ=&hersteller=… oder aus SEO-Pfad /Serie__…__… (FilterKonfiguratorController::findSeriesForValues).
     *
     * @return array<int, array{label:string,value:string}>
     */
    private function fkBuildSelectionItemsFromRequest(): array
    {
        $get = static function (string $key): string {
            try {
                $v = Request::getVar($key, '');
                return \is_string($v) ? trim($v) : trim((string)$v);
            } catch (\Throwable $e) {
                $v = $_GET[$key] ?? '';
                return \is_string($v) ? trim($v) : trim((string)$v);
            }
        };

        $map = [
            'typ'        => 'Fahrzeugtyp',
            'hersteller' => 'Fahrzeug-Marke',
            'basis'      => 'Wohnmobil-Fahrgestell',
            'modell'     => 'Fahrzeug-Modell',
            'baujahr'    => 'Baujahr',
            'sitz'       => 'kompatible Sitze',
            'serie'      => 'Serie',
        ];

        $items = [];
        foreach ($map as $key => $label) {
            $val = $get($key);
            if ($val !== '') {
                $items[] = ['label' => $label, 'value' => $val];
            }
        }
        if ($items !== []) {
            return $items;
        }

        return $this->fkBuildSelectionItemsFromSeoPath();
    }

    /**
     * Pfad z. B. /DPL__Kastenwagen__Adria__Twin-Axess-…__Fiat-Ducato-250__5_6
     * Reihenfolge wie im Plugin: Serie, typ, Marke, Modell, Fahrgestell, Sitze, optional Baujahr.
     *
     * @return array<int, array{label:string,value:string}>
     */
    private function fkBuildSelectionItemsFromSeoPath(): array
    {
        $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
        $path = (string)(\parse_url($uri, \PHP_URL_PATH) ?? '');
        $path = \trim($path, '/');
        if ($path === '' || \strpos($path, '__') === false) {
            return [];
        }
        $parts = \explode('__', $path);
        $parts = \array_values(\array_filter($parts, static fn($p) => \trim((string)$p) !== ''));
        if (\count($parts) < 2) {
            return [];
        }

        $labels = [
            'Serie',
            'Fahrzeugtyp',
            'Fahrzeug-Marke',
            'Fahrzeug-Modell',
            'Wohnmobil-Fahrgestell',
            'kompatible Sitze',
            'Baujahr',
        ];

        $items = [];
        foreach ($parts as $i => $raw) {
            if (!isset($labels[$i])) {
                break;
            }
            $human = $this->fkHumanizeSeoSegment((string)$raw, $i);
            if ($human !== '') {
                $items[] = ['label' => $labels[$i], 'value' => $human];
            }
        }

        return $items;
    }

    private function fkHumanizeSeoSegment(string $segment, int $index): string
    {
        $segment = \trim($segment);
        if ($segment === '') {
            return '';
        }
        // Sitze: z. B. 5_6 → 5 / 6
        if ($index === 5) {
            $s = \str_replace('-', ' ', $segment);

            return \trim(\str_replace('_', ' / ', $s));
        }

        return \trim(\preg_replace('/\s+/', ' ', \str_replace('-', ' ', $segment)) ?? '');
    }

    private function ensureAdminMenuEntry(): void
    {
        if (self::$adminMenuEnsured) {
            return;
        }

        try {
            $db = Shop::Container()->getDB();
            $pluginID = (int)$this->getPlugin()->getID();
            if ($pluginID <= 0) {
                return;
            }

            $file = 'dashboard.php';

            $exists = $db->getSingleObject(
                "SELECT kPluginAdminMenu
                   FROM tpluginadminmenu
                  WHERE kPlugin = :kPlugin
                    AND cDateiname = :cDateiname
                  LIMIT 1",
                [
                    'kPlugin'    => $pluginID,
                    'cDateiname' => $file,
                ]
            );

            if ($exists !== null) {
                self::$adminMenuEnsured = true;
                return;
            }

            $menuItem = new \stdClass();
            $menuItem->kPlugin    = $pluginID;
            $menuItem->cName      = 'FilterKonfigurator Dashboard';
            $menuItem->cDateiname = $file;
            $menuItem->nSort      = 20;
            $menuItem->nConf      = 0;

            $db->insert('tpluginadminmenu', $menuItem);
            self::$adminMenuEnsured = true;
        } catch (\Throwable $e) {
            // No hard failure for menu insertion.
        }
    }
}

