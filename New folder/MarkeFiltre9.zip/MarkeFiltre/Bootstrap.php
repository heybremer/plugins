<?php

namespace Plugin\MarkeFiltre;

use JTL\Events\Dispatcher;
use JTL\phpQuery\phpQuery;
use JTL\Plugin\Bootstrapper;
use JTL\Router\Router;
use JTL\Smarty\JTLSmarty;
use JTL\Shop;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ServerRequestInterface;
use Plugin\MarkeFiltre\Controller\MarkeFiltreController;

class Bootstrap extends Bootstrapper
{
    private static bool $adminMenuEnsured = false;
    private static bool $settingsEnsured = false;
    private static bool $brandsCacheEnsured = false;

    public function boot(Dispatcher $dispatcher): void
    {
        parent::boot($dispatcher);

        $this->ensureAdminMenuEntry();
        $this->ensureSettingsTable();
        $this->ensureBrandsCacheTables();

        // CSS/JS (global). The widget only renders on homepage.
        $dispatcher->hookInto(\HOOK_LETZTERINCLUDE_CSS_JS, function (array &$args): void {
            if (!isset($args['cPluginCss_arr']) || !\is_array($args['cPluginCss_arr'])) {
                $args['cPluginCss_arr'] = [];
            }
            if (!isset($args['cPluginJsHead_arr']) || !\is_array($args['cPluginJsHead_arr'])) {
                $args['cPluginJsHead_arr'] = [];
            }

            $cssPath = 'plugins/MarkeFiltre/templates/css/markefiltre.css';
            if (!\in_array($cssPath, $args['cPluginCss_arr'], true)) {
                $args['cPluginCss_arr'][] = $cssPath;
            }
            $jsPath = 'plugins/MarkeFiltre/templates/js/markefiltre.js';
            if (!\in_array($jsPath, $args['cPluginJsHead_arr'], true)) {
                $args['cPluginJsHead_arr'][] = $jsPath;
            }
        });

        // JSON endpoint: /mf-brands
        $dispatcher->hookInto(\HOOK_ROUTER_PRE_DISPATCH, function (array $args): void {
            /** @var Router $router */
            $router = $args['router'];
            $handler = function (ServerRequestInterface $request, array $routeArgs, JTLSmarty $smarty) {
                $ctl = new MarkeFiltreController();
                return $ctl->brands($request);
            };

            // Root install
            $router->addRoute('/mf-brands', $handler, 'mf-brands', ['GET']);
            // Subdir install (/WomosiWeb)
            $router->addRoute('/WomosiWeb/mf-brands', $handler, 'mf-brands-subdir', ['GET']);
        });

        // Anasayfa: MarkeFiltre bileşenini dashboard ayarına göre enjekte et.
        $dispatcher->hookInto(\HOOK_SMARTY_OUTPUTFILTER, function (array &$args): void {
            // Bazı kurulumlarda Shop::getPageType() Startseite için farklı dönebilir (subdir /WomosiWeb/ vb.).
            // Bu yüzden URL path ile de kontrol ediyoruz.
            $uri  = (string)($_SERVER['REQUEST_URI'] ?? '');
            $path = (string)(\parse_url($uri, \PHP_URL_PATH) ?? '');
            $path = \rtrim($path, '/');
            $isHomePath = ($path === ''
                || $path === '/WomosiWeb'
                || $path === '/WomosiWeb/index.php'
                || \str_starts_with($path, '/WomosiWeb/index.php')
            );
            if (Shop::getPageType() !== \PAGE_STARTSEITE && !$isHomePath) {
                return;
            }
            if (!isset($args['smarty'], $args['document'])) {
                return;
            }

            $doc = $args['document'];
            if ($doc->find('#br-caravan-root')->length > 0 || $doc->find('#markefiltre-mount')->length > 0) {
                return; // already injected
            }

            $cfg = $this->getInjectionConfig();
            $selector = \trim((string)($cfg['selector'] ?? ''));
            $mode     = \trim((string)($cfg['mode'] ?? ''));
            $showPKW = (bool)($cfg['showPKW'] ?? true);
            $showWohnmobil = (bool)($cfg['showWohnmobil'] ?? true);
            if ($selector === '') {
                // Dashboard ayarı okunamadıysa bile bileşen görünür olsun diye güvenli fallback.
                $selector = 'main';
            }
            if ($mode === '') {
                $mode = 'after';
            }
            if (!$showPKW && !$showWohnmobil) {
                return;
            }

            /** @var JTLSmarty $smarty */
            $smarty = $args['smarty'];
            $tplPath = $this->getPlugin()->getPaths()->getBasePath() . 'templates/markefiltre.tpl';
            if (!\is_file($tplPath)) {
                return;
            }

            try {
                $smarty->assign('mfBrandsJson', $this->buildBrandsJsonForTpl());
                $html = $smarty->fetch('file:' . $tplPath);
            } catch (\Throwable $e) {
                return;
            }
            if (\trim((string)$html) === '') {
                return;
            }

            // Wrap + client-side relocation:
            // Some targets (e.g. #index-filter-konfigurator) may be injected later by other outputfilters.
            $esc = static function (string $s): string {
                return \htmlspecialchars($s, \ENT_QUOTES, 'UTF-8');
            };
            $wrap = '<div id="markefiltre-mount" data-selector="' . $esc($selector) . '" data-mode="' . $esc($mode) . '">'
                . $html
                . '</div>'
                . "<script>(function(){try{var m=document.getElementById('markefiltre-mount');if(!m)return;var sel=m.getAttribute('data-selector')||'';var mode=m.getAttribute('data-mode')||'';function findTarget(){if(!sel)return null;var nodes=document.querySelectorAll(sel);if(!nodes||!nodes.length)return null;for(var i=0;i<nodes.length;i++){var n=nodes[i];if(n&&n.nodeType===1&&!m.contains(n)&&n!==m)return n;}return nodes[0]||null;}function doPlace(t){if(!t)return false;try{if(mode==='prepend'){t.insertBefore(m,t.firstChild);}else if(mode==='append'){t.appendChild(m);}else if(mode==='before'){t.parentNode&&t.parentNode.insertBefore(m,t);}else{t.parentNode&&t.parentNode.insertBefore(m,t.nextSibling);}return true;}catch(e){return false;}}function place(){return doPlace(findTarget());}if(place())return;var stopAt=Date.now()+60000;var iv=setInterval(function(){if(place()||Date.now()>stopAt){clearInterval(iv);}},250);var mo=null;try{mo=new MutationObserver(function(){if(place()){try{mo.disconnect();}catch(e){} clearInterval(iv);}});mo.observe(document.documentElement||document.body,{childList:true,subtree:true});}catch(e){}}catch(e){}})();</script>";

            // Try server-side first if target already exists
            $target = $doc->find($selector)->eq(0);
            if ($target->length > 0) {
                if ($mode === 'prepend') {
                    $target->prepend($wrap);
                } elseif ($mode === 'append') {
                    $target->append($wrap);
                } elseif ($mode === 'before') {
                    $target->before($wrap);
                } else { // after
                    $target->after($wrap);
                }
                return;
            }

            // Fallback: append to main/body, JS will move it when target appears
            $main = $doc->find('main#main-wrapper')->eq(0);
            if ($main->length > 0) {
                $main->append($wrap);
                return;
            }
            $genericMain = $doc->find('main')->eq(0);
            if ($genericMain->length > 0) {
                $genericMain->append($wrap);
                return;
            }
            $body = $doc->find('body')->eq(0);
            if ($body->length > 0) {
                $body->append($wrap);
            }
        });
    }

    private function buildBrandsJsonForTpl(): string
    {
        try {
            $db = Shop::Container()->getDB();
            $langID = (int)Shop::getLanguageID();
            $cfg = $this->getInjectionConfig();
            $showPKW = (bool)($cfg['showPKW'] ?? true);
            $showWohnmobil = (bool)($cfg['showWohnmobil'] ?? true);
            $tryLangs = [$langID];
            if ($langID !== 1) {
                $tryLangs[] = 1;
            }
            foreach ($tryLangs as $lid) {
                $this->maybeRefreshBrandsCache($lid);
                $payload = $this->loadBrandsPayloadFromCache($lid);
                if ($payload !== null) {
                    if (!$showPKW) {
                        $payload['PKW'] = [];
                    }
                    if (!$showWohnmobil) {
                        $payload['Wohnmobil'] = [];
                    }
                    $json = \json_encode($payload, \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES);
                    if (\is_string($json)) {
                        return $json;
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return '{}';
    }

    private function ensureBrandsCacheTables(): void
    {
        if (self::$brandsCacheEnsured) {
            return;
        }
        try {
            $db = Shop::Container()->getDB();
            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_markefiltre_brands (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    kSprache INT NOT NULL,
                    cType VARCHAR(16) NOT NULL,
                    cName VARCHAR(191) NOT NULL,
                    cUrl VARCHAR(512) NOT NULL DEFAULT '',
                    dUpdated DATETIME NOT NULL,
                    UNIQUE KEY uq_mf_brand (kSprache, cType, cName),
                    KEY ix_mf_brand_lang_type (kSprache, cType),
                    KEY ix_mf_brand_updated (dUpdated)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_markefiltre_meta (
                    cKey VARCHAR(64) NOT NULL PRIMARY KEY,
                    cValue VARCHAR(255) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            self::$brandsCacheEnsured = true;
        } catch (\Throwable $e) {
            // ignore
        }
    }

    /**
     * Returns payload from cache or null if empty.
     * @return array{PKW:array<int,array{name:string,url:string}>,Wohnmobil:array<int,array{name:string,url:string}>}|null
     */
    private function loadBrandsPayloadFromCache(int $langID): ?array
    {
        try {
            $db = Shop::Container()->getDB();
            $rows = $db->getObjects(
                "SELECT cType, cName, cUrl
                   FROM twomosi_markefiltre_brands
                  WHERE kSprache = :lid
               ORDER BY cType ASC, cName ASC",
                ['lid' => $langID]
            );
            $pkw = [];
            $wohn = [];
            if (\is_array($rows)) {
                foreach ($rows as $r) {
                    $type = \trim((string)($r->cType ?? ''));
                    $name = \trim((string)($r->cName ?? ''));
                    $url  = (string)($r->cUrl ?? '');
                    if ($name === '') {
                        continue;
                    }
                    $item = ['name' => $name, 'url' => $url];
                    if ($type === 'Wohnmobil') {
                        $wohn[] = $item;
                    } else {
                        $pkw[] = $item;
                    }
                }
            }
            if ($pkw === [] && $wohn === []) {
                return null;
            }
            return ['PKW' => $pkw, 'Wohnmobil' => $wohn];
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function maybeRefreshBrandsCache(int $langID): void
    {
        // Refresh conditions:
        // - cache is empty OR
        // - scheduled weekday/hour match AND last refresh is older than ~6 days (weekly)
        try {
            $db = Shop::Container()->getDB();
            $cnt = (int)$db->getSingleObject(
                "SELECT COUNT(*) AS cnt FROM twomosi_markefiltre_brands WHERE kSprache = :lid",
                ['lid' => $langID]
            )->cnt;
            $isEmpty = ($cnt <= 0);

            $sched = $this->getRefreshSchedule();
            $dowTarget = (int)($sched['dow'] ?? 0);
            $hourTarget = (int)($sched['hour'] ?? 3);

            $now = new \DateTimeImmutable('now');
            $dowNow = (int)$now->format('w'); // 0=Sun..6=Sat
            $hourNow = (int)$now->format('G'); // 0..23

            $key = 'brands_last_refresh_lang_' . $langID;
            $row = $db->getSingleObject("SELECT cValue FROM twomosi_markefiltre_meta WHERE cKey = :k LIMIT 1", ['k' => $key]);
            $last = null;
            if ($row !== null && isset($row->cValue)) {
                try { $last = new \DateTimeImmutable((string)$row->cValue); } catch (\Throwable $e) { $last = null; }
            }

            $scheduledNow = ($dowNow === $dowTarget && $hourNow === $hourTarget);
            $olderThanWeek = true;
            if ($last instanceof \DateTimeImmutable) {
                $olderThanWeek = ($last < $now->sub(new \DateInterval('P6D')));
            }

            if ($isEmpty || ($scheduledNow && $olderThanWeek)) {
                $this->rebuildBrandsCache($langID);
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

    /**
     * @return array{dow:int,hour:int}
     */
    private function getRefreshSchedule(): array
    {
        // Stored in settings table (latest row). Fallback: Sunday 03:00.
        try {
            $db = Shop::Container()->getDB();
            $row = $db->getSingleObject(
                "SELECT nRefreshDow, nRefreshHour
                   FROM twomosi_markefiltre_settings
               ORDER BY dUpdated DESC, kID DESC
                  LIMIT 1"
            );
            if ($row !== null) {
                $dow = (int)($row->nRefreshDow ?? 0);
                $hr  = (int)($row->nRefreshHour ?? 3);
                if ($dow < 0 || $dow > 6) { $dow = 0; }
                if ($hr < 0 || $hr > 23) { $hr = 3; }
                return ['dow' => $dow, 'hour' => $hr];
            }
        } catch (\Throwable $e) {}
        return ['dow' => 0, 'hour' => 3];
    }

    private function rebuildBrandsCache(int $langID): void
    {
        $this->ensureBrandsCacheTables();
        try {
            $db = Shop::Container()->getDB();
            $shopURL = \rtrim((string)Shop::getURL(), '/');

            // Wohnmobil brands
            $wohnRows = $db->getObjects(
                "SELECT DISTINCT tmws_her.cWert AS name
                   FROM tartikel a
             INNER JOIN tartikelmerkmal am_typ ON am_typ.kArtikel = a.kArtikel
             INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
             INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
             INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                              AND ms_typ.kSprache = :lid
                                              AND (ms_typ.cName = 'Wohnmobil-Aufbauart' OR ms_typ.cName = 'Wohnmobil Aufbauart' OR (ms_typ.cName LIKE '%Aufbauart%'))
             INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
             INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
             INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
             INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                              AND ms_her.kSprache = :lid
                                              AND (ms_her.cName = 'Fahrzeug-Marke' OR ms_her.cName = 'Fahrzeug Marke' OR (ms_her.cName LIKE '%Marke%'))
             INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                    AND tmws_her.kSprache     = :lid
                  WHERE a.nIstVater = 0
                    AND TRIM(tmws_her.cWert) <> ''
                    AND tmws_her.cWert NOT REGEXP '^[0-9]+$'
               ORDER BY tmws_her.cWert ASC
                  LIMIT 2000",
                ['lid' => $langID]
            ) ?: [];

            // PKW brands = brands on products without Aufbauart
            $pkwRows = $db->getObjects(
                "SELECT DISTINCT tmws_her.cWert AS name
                   FROM tartikel a
             INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
             INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
             INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
             INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                              AND ms_her.kSprache = :lid
                                              AND (ms_her.cName = 'Fahrzeug-Marke' OR ms_her.cName = 'Fahrzeug Marke' OR (ms_her.cName LIKE '%Marke%'))
             INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                    AND tmws_her.kSprache     = :lid
                  WHERE a.nIstVater = 0
                    AND TRIM(tmws_her.cWert) <> ''
                    AND tmws_her.cWert NOT REGEXP '^[0-9]+$'
                    AND NOT EXISTS (
                        SELECT 1
                          FROM tartikelmerkmal am_typ
                    INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                    INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
                    INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                                     AND ms_typ.kSprache = :lid
                                                     AND (ms_typ.cName = 'Wohnmobil-Aufbauart' OR ms_typ.cName = 'Wohnmobil Aufbauart' OR (ms_typ.cName LIKE '%Aufbauart%'))
                         WHERE am_typ.kArtikel = a.kArtikel
                    )
               ORDER BY tmws_her.cWert ASC
                  LIMIT 2000",
                ['lid' => $langID]
            ) ?: [];

            // Replace cache for language
            $db->executeQueryPrepared("DELETE FROM twomosi_markefiltre_brands WHERE kSprache = :lid", ['lid' => $langID]);

            $insert = function (string $type, array $rows) use ($db, $langID, $shopURL): void {
                foreach ($rows as $r) {
                    $name = \trim((string)($r->name ?? ''));
                    if ($name === '') {
                        continue;
                    }
                    $db->executeQueryPrepared(
                        "INSERT INTO twomosi_markefiltre_brands (kSprache, cType, cName, cUrl, dUpdated)
                         VALUES (:lid, :t, :n, :u, NOW())
                         ON DUPLICATE KEY UPDATE cUrl = VALUES(cUrl), dUpdated = NOW()",
                        [
                            'lid' => $langID,
                            't'   => $type,
                            'n'   => $name,
                            'u'   => $shopURL . '/?qs=' . \rawurlencode($name),
                        ]
                    );
                }
            };
            $insert('Wohnmobil', \is_array($wohnRows) ? $wohnRows : []);
            $insert('PKW', \is_array($pkwRows) ? $pkwRows : []);

            $key = 'brands_last_refresh_lang_' . $langID;
            $db->executeQueryPrepared(
                "INSERT INTO twomosi_markefiltre_meta (cKey, cValue)
                 VALUES (:k, :v)
                 ON DUPLICATE KEY UPDATE cValue = VALUES(cValue)",
                ['k' => $key, 'v' => (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s')]
            );
        } catch (\Throwable $e) {
            // ignore
        }
    }

    private function ensureSettingsTable(): void
    {
        if (self::$settingsEnsured) {
            return;
        }
        try {
            $db = Shop::Container()->getDB();
            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_markefiltre_settings (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    dUpdated DATETIME NOT NULL,
                    cSelector VARCHAR(255) NOT NULL DEFAULT '',
                    cMode VARCHAR(16) NOT NULL DEFAULT '',
                    nRefreshDow INT NOT NULL DEFAULT 0,
                    nRefreshHour INT NOT NULL DEFAULT 3,
                    bShowPKW TINYINT(1) NOT NULL DEFAULT 1,
                    bShowWohnmobil TINYINT(1) NOT NULL DEFAULT 1
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            // Backward compatible alters (ignore errors if columns exist)
            try { $db->executeQuery("ALTER TABLE twomosi_markefiltre_settings ADD COLUMN nRefreshDow INT NOT NULL DEFAULT 0"); } catch (\Throwable $e) {}
            try { $db->executeQuery("ALTER TABLE twomosi_markefiltre_settings ADD COLUMN nRefreshHour INT NOT NULL DEFAULT 3"); } catch (\Throwable $e) {}
            try { $db->executeQuery("ALTER TABLE twomosi_markefiltre_settings ADD COLUMN bShowPKW TINYINT(1) NOT NULL DEFAULT 1"); } catch (\Throwable $e) {}
            try { $db->executeQuery("ALTER TABLE twomosi_markefiltre_settings ADD COLUMN bShowWohnmobil TINYINT(1) NOT NULL DEFAULT 1"); } catch (\Throwable $e) {}
            $row = $db->getSingleObject("SELECT kID FROM twomosi_markefiltre_settings ORDER BY dUpdated DESC, kID DESC LIMIT 1");
            if ($row === null) {
                $db->executeQueryPrepared(
                    "INSERT INTO twomosi_markefiltre_settings (dUpdated, cSelector, cMode, nRefreshDow, nRefreshHour, bShowPKW, bShowWohnmobil)
                     VALUES (NOW(), :sel, :mode, 0, 3, 1, 1)",
                    ['sel' => 'main', 'mode' => 'after']
                );
            }
            self::$settingsEnsured = true;
        } catch (\Throwable $e) {
            // ignore
        }
    }

    /**
     * @return array{selector:string,mode:string,showPKW:bool,showWohnmobil:bool}
     */
    private function getInjectionConfig(): array
    {
        try {
            $db = Shop::Container()->getDB();
            $row = $db->getSingleObject(
                "SELECT cSelector, cMode, bShowPKW, bShowWohnmobil
                   FROM twomosi_markefiltre_settings
               ORDER BY dUpdated DESC, kID DESC
                  LIMIT 1"
            );
            if ($row !== null) {
                return [
                    'selector' => (string)($row->cSelector ?? ''),
                    'mode'     => (string)($row->cMode ?? ''),
                    'showPKW' => (int)($row->bShowPKW ?? 1) === 1,
                    'showWohnmobil' => (int)($row->bShowWohnmobil ?? 1) === 1,
                ];
            }
        } catch (\Throwable $e) {
            // ignore
        }
        return ['selector' => '', 'mode' => '', 'showPKW' => true, 'showWohnmobil' => true];
    }

    private function ensureAdminMenuEntry(): void
    {
        if (self::$adminMenuEnsured) {
            return;
        }

        try {
            $db = Shop::Container()->getDB();
            $pluginID = (int)$this->getPlugin()->getID();
            if ($pluginID <= 0) {
                return;
            }

            $file = 'dashboard.php';
            $exists = $db->getSingleObject(
                "SELECT kPluginAdminMenu
                   FROM tpluginadminmenu
                  WHERE kPlugin = :kPlugin
                    AND cDateiname = :cDateiname
                  LIMIT 1",
                [
                    'kPlugin'    => $pluginID,
                    'cDateiname' => $file,
                ]
            );

            if ($exists !== null) {
                self::$adminMenuEnsured = true;
                return;
            }

            $menuItem = new \stdClass();
            $menuItem->kPlugin    = $pluginID;
            $menuItem->cName      = 'MarkeFiltre Dashboard';
            $menuItem->cDateiname = $file;
            $menuItem->nSort      = 30;
            $menuItem->nConf      = 0;

            $db->insert('tpluginadminmenu', $menuItem);
            self::$adminMenuEnsured = true;
        } catch (\Throwable $e) {
            // no hard failure
        }
    }
}

