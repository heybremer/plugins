<?php
declare(strict_types=1);

use JTL\Shop;
use JTL\Helpers\Form;

$db = Shop::Container()->getDB();
$pluginName = 'MarkeFiltre';
$pluginID = 0;
try {
    // Plugin-ID direkt bul (bazı admin context'lerde $oPlugin global olmayabilir)
    $row = $db->getSingleObject("SELECT kPlugin FROM tplugin WHERE cPluginID = :pid LIMIT 1", ['pid' => $pluginName]);
    $pluginID = isset($row->kPlugin) ? (int)$row->kPlugin : 0;
} catch (\Throwable $e) {
    $pluginID = 0;
}

$message = '';

// Ensure settings table exists
try {
    $db->executeQuery(
        "CREATE TABLE IF NOT EXISTS twomosi_markefiltre_settings (
            kID INT AUTO_INCREMENT PRIMARY KEY,
            dUpdated DATETIME NOT NULL,
            cSelector VARCHAR(255) NOT NULL DEFAULT '',
            cMode VARCHAR(16) NOT NULL DEFAULT ''
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    $row = $db->getSingleObject('SELECT kID FROM twomosi_markefiltre_settings ORDER BY dUpdated DESC, kID DESC LIMIT 1');
    if ($row === null) {
        $db->executeQueryPrepared(
            'INSERT INTO twomosi_markefiltre_settings (dUpdated, cSelector, cMode) VALUES (NOW(), :sel, :mode)',
            ['sel' => 'main', 'mode' => 'after']
        );
    }
} catch (\Throwable $e) {
    // ignore
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !Form::validateToken()) {
    $message = 'Token hatası: Form oturumu geçersiz. Sayfayı yenileyip tekrar kaydedin.';
}

if (Form::validateToken()) {
    try {
        if (!empty($_POST['mfSavePlacement'])) {
            $selector = trim((string)($_POST['mfSelector'] ?? ''));
            $mode     = trim((string)($_POST['mfMode'] ?? ''));

            // allow disabling via empty selector
            if (!\in_array($mode, ['prepend', 'append', 'before', 'after'], true)) {
                $mode = '';
            }

            $db->executeQueryPrepared(
                "INSERT INTO twomosi_markefiltre_settings (dUpdated, cSelector, cMode)
                 VALUES (NOW(), :sel, :mode)",
                ['sel' => $selector, 'mode' => $mode]
            );
            $message = 'Kaydedildi.';
        }
    } catch (\Throwable $e) {
        $message = 'İşlem başarısız: ' . $e->getMessage();
    }
}

$cfgSelector = '';
$cfgMode = '';
$cfgUpdated = '';
try {
    $row = $db->getSingleObject('SELECT cSelector, cMode, dUpdated FROM twomosi_markefiltre_settings ORDER BY dUpdated DESC, kID DESC LIMIT 1');
    if ($row !== null) {
        $cfgSelector = (string)($row->cSelector ?? '');
        $cfgMode     = (string)($row->cMode ?? '');
        $cfgUpdated  = (string)($row->dUpdated ?? '');
    }
} catch (\Throwable $e) {}

?>
<div style="padding:10px 0;">
    <h2 style="margin:0 0 12px;">MarkeFiltre Dashboard</h2>
    <?php if ($message !== ''): ?>
        <div style="margin:0 0 12px;padding:10px 12px;border:1px solid rgba(0,0,0,.12);border-radius:10px;background:rgba(204,255,0,.12);max-width:900px;">
            <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>
    <div style="padding:12px;border:1px solid rgba(0,0,0,.08);border-radius:10px;max-width:900px;">
        <div style="margin-bottom:8px;"><b>PluginID:</b> <?= (int)$pluginID ?></div>
        <div style="margin-bottom:8px;"><b>Görünen yer:</b> Sadece <code>Startseite</code> (anasayfa). Konumu aşağıdaki ayardan sen belirlersin.</div>
        <div style="margin-bottom:8px;"><b>Template:</b> <code>plugins/MarkeFiltre/templates/markefiltre.tpl</code></div>
        <div style="margin-bottom:8px;"><b>DOM kontrol:</b> Sayfada <code>#br-caravan-root</code> varsa tekrar eklemez.</div>
        <div style="margin-bottom:8px;"><b>Aktif konum:</b>
            <code><?= htmlspecialchars($cfgSelector ?: '(kapalı)', ENT_QUOTES, 'UTF-8') ?></code>
            <span style="opacity:.85;"> / </span>
            <code><?= htmlspecialchars($cfgMode ?: '-', ENT_QUOTES, 'UTF-8') ?></code>
            <?php if ($cfgUpdated): ?><span style="opacity:.75;"> (<?= htmlspecialchars($cfgUpdated, ENT_QUOTES, 'UTF-8') ?>)</span><?php endif; ?>
        </div>
        <div style="margin-bottom:0;opacity:.85;">
            Not: Şu an linkler <code>bremer-sitzbezuege.de</code> domainine gidiyor. İstersen bunları <code>womosi.de</code> URL’lerine map edebiliriz.
        </div>
    </div>

    <div style="margin-top:14px;padding:12px;border:1px solid rgba(0,0,0,.08);border-radius:10px;max-width:900px;">
        <h3 style="margin:0 0 10px;">Anasayfa konum ayarı</h3>
        <form method="post" style="display:grid;gap:10px;">
            <?= Form::getTokenInput(); ?>

            <div>
                <label for="mfSelector"><b>Hedef CSS selector</b></label><br>
                <input id="mfSelector" name="mfSelector" type="text"
                       value="<?= htmlspecialchars($cfgSelector, ENT_QUOTES, 'UTF-8') ?>"
                       placeholder="Örn: main#main-wrapper, .hero, #some-block"
                       style="width:100%;padding:8px;">
                <div style="opacity:.75;margin-top:6px;">
                    Boş bırakırsan bileşen kapalı olur (hiç enjekte edilmez).
                </div>
            </div>

            <div>
                <label for="mfMode"><b>Konum</b></label><br>
                <select id="mfMode" name="mfMode" style="padding:8px;min-width:220px;">
                    <option value="" <?= $cfgMode === '' ? 'selected' : '' ?>>Seçiniz</option>
                    <option value="prepend" <?= $cfgMode === 'prepend' ? 'selected' : '' ?>>İçine başa (prepend)</option>
                    <option value="append" <?= $cfgMode === 'append' ? 'selected' : '' ?>>İçine sona (append)</option>
                    <option value="before" <?= $cfgMode === 'before' ? 'selected' : '' ?>>Öncesine (before)</option>
                    <option value="after" <?= $cfgMode === 'after' ? 'selected' : '' ?>>Sonrasına (after)</option>
                </select>
            </div>

            <div>
                <button type="submit" name="mfSavePlacement" value="1" style="padding:10px 14px;">Kaydet</button>
            </div>
        </form>
    </div>
</div>

