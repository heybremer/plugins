<?php

namespace Plugin\MarkeFiltre;

use JTL\Events\Dispatcher;
use JTL\phpQuery\phpQuery;
use JTL\Plugin\Bootstrapper;
use JTL\Router\Router;
use JTL\Smarty\JTLSmarty;
use JTL\Shop;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ServerRequestInterface;
use Plugin\MarkeFiltre\Controller\MarkeFiltreController;

class Bootstrap extends Bootstrapper
{
    private static bool $adminMenuEnsured = false;
    private static bool $settingsEnsured = false;

    public function boot(Dispatcher $dispatcher): void
    {
        parent::boot($dispatcher);

        $this->ensureAdminMenuEntry();
        $this->ensureSettingsTable();

        // CSS/JS (global). The widget only renders on homepage.
        $dispatcher->hookInto(\HOOK_LETZTERINCLUDE_CSS_JS, function (array &$args): void {
            if (!isset($args['cPluginCss_arr']) || !\is_array($args['cPluginCss_arr'])) {
                $args['cPluginCss_arr'] = [];
            }
            if (!isset($args['cPluginJsHead_arr']) || !\is_array($args['cPluginJsHead_arr'])) {
                $args['cPluginJsHead_arr'] = [];
            }

            $cssPath = 'plugins/MarkeFiltre/templates/css/markefiltre.css';
            if (!\in_array($cssPath, $args['cPluginCss_arr'], true)) {
                $args['cPluginCss_arr'][] = $cssPath;
            }
            $jsPath = 'plugins/MarkeFiltre/templates/js/markefiltre.js';
            if (!\in_array($jsPath, $args['cPluginJsHead_arr'], true)) {
                $args['cPluginJsHead_arr'][] = $jsPath;
            }
        });

        // JSON endpoint: /mf-brands
        $dispatcher->hookInto(\HOOK_ROUTER_PRE_DISPATCH, function (array $args): void {
            /** @var Router $router */
            $router = $args['router'];
            $handler = function (ServerRequestInterface $request, array $routeArgs, JTLSmarty $smarty) {
                $ctl = new MarkeFiltreController();
                return $ctl->brands($request);
            };

            // Root install
            $router->addRoute('/mf-brands', $handler, 'mf-brands', ['GET']);
            // Subdir install (/WomosiWeb)
            $router->addRoute('/WomosiWeb/mf-brands', $handler, 'mf-brands-subdir', ['GET']);
        });

        // Anasayfa: MarkeFiltre bileşenini dashboard ayarına göre enjekte et.
        $dispatcher->hookInto(\HOOK_SMARTY_OUTPUTFILTER, function (array &$args): void {
            // Bazı kurulumlarda Shop::getPageType() Startseite için farklı dönebilir (subdir /WomosiWeb/ vb.).
            // Bu yüzden URL path ile de kontrol ediyoruz.
            $uri  = (string)($_SERVER['REQUEST_URI'] ?? '');
            $path = (string)(\parse_url($uri, \PHP_URL_PATH) ?? '');
            $path = \rtrim($path, '/');
            $isHomePath = ($path === ''
                || $path === '/WomosiWeb'
                || $path === '/WomosiWeb/index.php'
                || \str_starts_with($path, '/WomosiWeb/index.php')
            );
            if (Shop::getPageType() !== \PAGE_STARTSEITE && !$isHomePath) {
                return;
            }
            if (!isset($args['smarty'], $args['document'])) {
                return;
            }

            $doc = $args['document'];
            if ($doc->find('#br-caravan-root')->length > 0 || $doc->find('#markefiltre-mount')->length > 0) {
                return; // already injected
            }

            $cfg = $this->getInjectionConfig();
            $selector = \trim((string)($cfg['selector'] ?? ''));
            $mode     = \trim((string)($cfg['mode'] ?? ''));
            if ($selector === '') {
                // Dashboard ayarı okunamadıysa bile bileşen görünür olsun diye güvenli fallback.
                $selector = 'main';
            }
            if ($mode === '') {
                $mode = 'after';
            }

            /** @var JTLSmarty $smarty */
            $smarty = $args['smarty'];
            $tplPath = $this->getPlugin()->getPaths()->getBasePath() . 'templates/markefiltre.tpl';
            if (!\is_file($tplPath)) {
                return;
            }

            try {
                $smarty->assign('mfBrandsJson', $this->buildBrandsJsonForTpl());
                $html = $smarty->fetch('file:' . $tplPath);
            } catch (\Throwable $e) {
                return;
            }
            if (\trim((string)$html) === '') {
                return;
            }

            // Wrap + client-side relocation:
            // Some targets (e.g. #index-filter-konfigurator) may be injected later by other outputfilters.
            $esc = static function (string $s): string {
                return \htmlspecialchars($s, \ENT_QUOTES, 'UTF-8');
            };
            $wrap = '<div id="markefiltre-mount" data-selector="' . $esc($selector) . '" data-mode="' . $esc($mode) . '">'
                . $html
                . '</div>'
                . "<script>(function(){try{var m=document.getElementById('markefiltre-mount');if(!m)return;var sel=m.getAttribute('data-selector')||'';var mode=m.getAttribute('data-mode')||'';function place(){var t=sel?document.querySelector(sel):null;if(!t)return false;try{if(mode==='prepend'){t.insertBefore(m,t.firstChild);}else if(mode==='append'){t.appendChild(m);}else if(mode==='before'){t.parentNode&&t.parentNode.insertBefore(m,t);}else{t.parentNode&&t.parentNode.insertBefore(m,t.nextSibling);}return true;}catch(e){return false;}}if(place())return;var n=0;var iv=setInterval(function(){n++;if(place()||n>50){clearInterval(iv);}},200);}catch(e){}})();</script>";

            // Try server-side first if target already exists
            $target = $doc->find($selector)->eq(0);
            if ($target->length > 0) {
                if ($mode === 'prepend') {
                    $target->prepend($wrap);
                } elseif ($mode === 'append') {
                    $target->append($wrap);
                } elseif ($mode === 'before') {
                    $target->before($wrap);
                } else { // after
                    $target->after($wrap);
                }
                return;
            }

            // Fallback: append to main/body, JS will move it when target appears
            $main = $doc->find('main#main-wrapper')->eq(0);
            if ($main->length > 0) {
                $main->append($wrap);
                return;
            }
            $genericMain = $doc->find('main')->eq(0);
            if ($genericMain->length > 0) {
                $genericMain->append($wrap);
                return;
            }
            $body = $doc->find('body')->eq(0);
            if ($body->length > 0) {
                $body->append($wrap);
            }
        });
    }

    private function buildBrandsJsonForTpl(): string
    {
        try {
            $db = Shop::Container()->getDB();
            $langID = (int)Shop::getLanguageID();
            $shopURL = \rtrim((string)Shop::getURL(), '/');
            $tryLangs = [$langID];
            if ($langID !== 1) {
                $tryLangs[] = 1;
            }
            foreach ($tryLangs as $lid) {
                $wohnmobilItems = [];
                $pkwItems = [];

                // Wohnmobil: strict requires both Aufbauart + Fahrzeug-Marke on the same product
                try {
                    $rows = $db->getObjects(
                        "SELECT DISTINCT tmws_her.cWert AS name
                           FROM tartikel a
                     INNER JOIN tartikelmerkmal am_typ ON am_typ.kArtikel = a.kArtikel
                     INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                     INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
                     INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                                      AND ms_typ.kSprache = :lid
                                                      AND (ms_typ.cName = 'Wohnmobil-Aufbauart' OR ms_typ.cName = 'Wohnmobil Aufbauart' OR (ms_typ.cName LIKE '%Aufbauart%'))
                     INNER JOIN tmerkmalwertsprache tmws_typ ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                                                            AND tmws_typ.kSprache     = :lid
                     INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
                     INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                     INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
                     INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                                      AND ms_her.kSprache = :lid
                                                      AND (ms_her.cName = 'Fahrzeug-Marke' OR ms_her.cName = 'Fahrzeug Marke' OR (ms_her.cName LIKE '%Marke%'))
                     INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                            AND tmws_her.kSprache     = :lid
                          WHERE a.nIstVater = 0
                            AND TRIM(tmws_her.cWert) <> ''
                            AND tmws_her.cWert NOT REGEXP '^[0-9]+$'
                       ORDER BY tmws_her.cWert ASC
                          LIMIT 500",
                        ['lid' => $lid]
                    );
                    if (\is_array($rows)) {
                        foreach ($rows as $r) {
                            $name = \trim((string)($r->name ?? ''));
                            if ($name !== '') {
                                $wohnmobilItems[] = ['name' => $name, 'url' => $shopURL . '/?qs=' . \rawurlencode($name)];
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    $wohnmobilItems = [];
                }

                // Wohnmobil relaxed fallback: if no Wohnmobil-Aufbauart match, treat as empty (not global)
                // (keeps the Wohnmobil tab "true" to Wohnmobil items only)

                // PKW: brands used on products that DO NOT have Aufbauart characteristic
                // (best-effort separation if a dedicated PKW type merkmal doesn't exist)
                try {
                    $rows = $db->getObjects(
                        "SELECT DISTINCT tmws_her.cWert AS name
                           FROM tartikel a
                     INNER JOIN tartikelmerkmal am_her ON am_her.kArtikel = a.kArtikel
                     INNER JOIN tmerkmalwert mw_her    ON mw_her.kMerkmalWert = am_her.kMerkmalWert
                     INNER JOIN tmerkmal m_her         ON m_her.kMerkmal = mw_her.kMerkmal
                     INNER JOIN tmerkmalsprache ms_her ON ms_her.kMerkmal = m_her.kMerkmal
                                                      AND ms_her.kSprache = :lid
                                                      AND (ms_her.cName = 'Fahrzeug-Marke' OR ms_her.cName = 'Fahrzeug Marke' OR (ms_her.cName LIKE '%Marke%'))
                     INNER JOIN tmerkmalwertsprache tmws_her ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                                                            AND tmws_her.kSprache     = :lid
                          WHERE a.nIstVater = 0
                            AND TRIM(tmws_her.cWert) <> ''
                            AND tmws_her.cWert NOT REGEXP '^[0-9]+$'
                        AND NOT EXISTS (
                            SELECT 1
                              FROM tartikelmerkmal am_typ
                        INNER JOIN tmerkmalwert mw_typ    ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
                        INNER JOIN tmerkmal m_typ         ON m_typ.kMerkmal = mw_typ.kMerkmal
                        INNER JOIN tmerkmalsprache ms_typ ON ms_typ.kMerkmal = m_typ.kMerkmal
                                                         AND ms_typ.kSprache = :lid
                                                         AND (ms_typ.cName = 'Wohnmobil-Aufbauart' OR ms_typ.cName = 'Wohnmobil Aufbauart' OR (ms_typ.cName LIKE '%Aufbauart%'))
                             WHERE am_typ.kArtikel = a.kArtikel
                        )
                       ORDER BY tmws_her.cWert ASC
                          LIMIT 500",
                        ['lid' => $lid]
                    );
                    if (\is_array($rows)) {
                        foreach ($rows as $r) {
                            $name = \trim((string)($r->name ?? ''));
                            if ($name !== '') {
                                $pkwItems[] = ['name' => $name, 'url' => $shopURL . '/?qs=' . \rawurlencode($name)];
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    $pkwItems = [];
                }

                if ($wohnmobilItems !== [] || $pkwItems !== []) {
                    $payload = [
                        'PKW' => $pkwItems,
                        'Wohnmobil' => $wohnmobilItems,
                    ];
                    $json = \json_encode($payload, \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES);
                    if (\is_string($json)) {
                        return $json;
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return '{}';
    }

    private function ensureSettingsTable(): void
    {
        if (self::$settingsEnsured) {
            return;
        }
        try {
            $db = Shop::Container()->getDB();
            $db->executeQuery(
                "CREATE TABLE IF NOT EXISTS twomosi_markefiltre_settings (
                    kID INT AUTO_INCREMENT PRIMARY KEY,
                    dUpdated DATETIME NOT NULL,
                    cSelector VARCHAR(255) NOT NULL DEFAULT '',
                    cMode VARCHAR(16) NOT NULL DEFAULT ''
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            $row = $db->getSingleObject("SELECT kID FROM twomosi_markefiltre_settings ORDER BY dUpdated DESC, kID DESC LIMIT 1");
            if ($row === null) {
                $db->executeQueryPrepared(
                    "INSERT INTO twomosi_markefiltre_settings (dUpdated, cSelector, cMode) VALUES (NOW(), :sel, :mode)",
                    ['sel' => 'main', 'mode' => 'after']
                );
            }
            self::$settingsEnsured = true;
        } catch (\Throwable $e) {
            // ignore
        }
    }

    /**
     * @return array{selector:string,mode:string}
     */
    private function getInjectionConfig(): array
    {
        try {
            $db = Shop::Container()->getDB();
            $row = $db->getSingleObject("SELECT cSelector, cMode FROM twomosi_markefiltre_settings ORDER BY dUpdated DESC, kID DESC LIMIT 1");
            if ($row !== null) {
                return [
                    'selector' => (string)($row->cSelector ?? ''),
                    'mode'     => (string)($row->cMode ?? ''),
                ];
            }
        } catch (\Throwable $e) {
            // ignore
        }
        return ['selector' => '', 'mode' => ''];
    }

    private function ensureAdminMenuEntry(): void
    {
        if (self::$adminMenuEnsured) {
            return;
        }

        try {
            $db = Shop::Container()->getDB();
            $pluginID = (int)$this->getPlugin()->getID();
            if ($pluginID <= 0) {
                return;
            }

            $file = 'dashboard.php';
            $exists = $db->getSingleObject(
                "SELECT kPluginAdminMenu
                   FROM tpluginadminmenu
                  WHERE kPlugin = :kPlugin
                    AND cDateiname = :cDateiname
                  LIMIT 1",
                [
                    'kPlugin'    => $pluginID,
                    'cDateiname' => $file,
                ]
            );

            if ($exists !== null) {
                self::$adminMenuEnsured = true;
                return;
            }

            $menuItem = new \stdClass();
            $menuItem->kPlugin    = $pluginID;
            $menuItem->cName      = 'MarkeFiltre Dashboard';
            $menuItem->cDateiname = $file;
            $menuItem->nSort      = 30;
            $menuItem->nConf      = 0;

            $db->insert('tpluginadminmenu', $menuItem);
            self::$adminMenuEnsured = true;
        } catch (\Throwable $e) {
            // no hard failure
        }
    }
}

