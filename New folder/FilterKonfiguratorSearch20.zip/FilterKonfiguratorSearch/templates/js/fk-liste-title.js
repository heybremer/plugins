/**
 * Listen-, Produkt-, Warenkorb-, Checkout: H1 aus localStorage (womosi_fk_state_v1), wenn keine Server-Auswahl.
 * Konfiguratorauswahl bleibt vom Produkt bis zur Bestellung sichtbar (solange localStorage gesetzt ist).
 */
(function () {
  'use strict';

  var FK_STATE_KEY = 'womosi_fk_state_v1';
  var FK_MODELL_CUSTOM = '__FK_MODELL_CUSTOM__';

  function compactFromStorage() {
    try {
      var raw = window.localStorage.getItem(FK_STATE_KEY);
      if (!raw) return '';
      var c = JSON.parse(raw);
      if (!c || typeof c !== 'object') return '';
      var parts = [];
      if (c.typLabel) parts.push(String(c.typLabel).trim());
      if (c.hersteller) parts.push(String(c.hersteller).trim());
      if (c.basis) parts.push(String(c.basis).trim());
      var m = c.modell != null ? String(c.modell).trim() : '';
      if (m === FK_MODELL_CUSTOM) {
        m = c.modellCustom ? String(c.modellCustom).trim() : '';
      } else if (!m && c.modellCustom) {
        m = String(c.modellCustom).trim();
      }
      if (m) parts.push(m);
      if (c.year) parts.push('Model ' + String(c.year).trim());
      return parts.filter(Boolean).join(' ');
    } catch (e) {
      return '';
    }
  }

  function findTargetH1() {
    return (
      document.querySelector('h1.product-title.h2') ||
      document.querySelector('div.title h1.h2') ||
      document.querySelector('div.title h1') ||
      document.querySelector('h1.basket-heading') ||
      document.querySelector('#checkout h1')
    );
  }

  function skipGreenMessage(h1) {
    if (!h1) return true;
    if (h1.classList && h1.classList.contains('product-title')) return true;
    if (h1.classList && h1.classList.contains('basket-heading')) return true;
    if (h1.closest && h1.closest('#checkout')) return true;
    return false;
  }

  function applyTitle() {
    if (document.querySelector('.fk-selection-summary')) return;
    var line = compactFromStorage();
    if (!line) return;
    var h1 = findTargetH1();
    if (!h1) return;

    // Liste (Serie/Kategorie) → nur dynamisch, wenn URL echte Konfigurator-Parameter hat.
    var isProductTitle = h1.classList && h1.classList.contains('product-title');
    var isBasket      = h1.classList && h1.classList.contains('basket-heading');
    var isCheckout    = h1.closest && !!h1.closest('#checkout');
    if (!isProductTitle && !isBasket && !isCheckout) {
      var qs = window.location.search || '';
      if (!/[?&](typ|hersteller|basis|modell|baujahr|sitz|fkCustomModell|fkNichtInListe)=/i.test(qs)) {
        return;
      }
    }

    h1.textContent = line;
    var cls = h1.getAttribute('class') || '';
    if (cls.indexOf('fk-selection-h1') === -1) {
      h1.setAttribute('class', (cls + ' fk-selection-h1').trim());
    }
    if (skipGreenMessage(h1)) return;
    var wrap = document.createElement('div');
    wrap.className = 'fk-selection-summary';
    wrap.innerHTML =
      '<div class="fk-selection-subtitle text-muted mt-2 mb-1">' +
      '<span class="fk-selection-message"><span class="fk-selection-icon" aria-hidden="true">✔</span> Für Ihr Fahrzeug wurden passende Ergebnisse gefunden</span>' +
      '</div>';
    if (h1.parentNode) {
      h1.parentNode.insertBefore(wrap, h1.nextSibling);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTitle);
  } else {
    applyTitle();
  }
})();
