(function () {
  'use strict';

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function init() {
    var root = document.getElementById('br-caravan-root');
    if (!root || root.dataset.initialized === '1') return;
    root.dataset.initialized = '1';

    var tabs = qsa('[data-mf-tab]', root);
    var letterbar = qs('[data-mf-letterbar]', root);
    var search = qs('[data-mf-search]', root);
    var grid = qs('[data-mf-grid]', root);
    var moreBtn = qs('[data-mf-more]', root);

    var sets = { PKW: [], Wohnmobil: [] };
    var loaded = false;

    function shopBase() {
      // JTL shop may run in subdir (e.g. /WomosiWeb)
      try {
        var p = String(window.location && window.location.pathname ? window.location.pathname : '');
        if (p.indexOf('/WomosiWeb/') === 0 || p === '/WomosiWeb') return '/WomosiWeb';
      } catch (_) {}
      return '';
    }

    function fetchBrands() {
      try {
        if (window.MarkeFiltreBrands && (Array.isArray(window.MarkeFiltreBrands.PKW) || Array.isArray(window.MarkeFiltreBrands.Wohnmobil))) {
          if (Array.isArray(window.MarkeFiltreBrands.PKW)) sets.PKW = window.MarkeFiltreBrands.PKW;
          if (Array.isArray(window.MarkeFiltreBrands.Wohnmobil)) sets.Wohnmobil = window.MarkeFiltreBrands.Wohnmobil;
          loaded = true;
          return Promise.resolve();
        }
      } catch (_) {}

      // Fallback: endpoint (if route works)
      return fetch(shopBase() + '/mf-brands', { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && Array.isArray(data.PKW)) sets.PKW = data.PKW;
          if (data && Array.isArray(data.Wohnmobil)) sets.Wohnmobil = data.Wohnmobil;
          loaded = true;
        })
        .catch(function () {
          loaded = false;
        });
    }

    var state = {
      activeSet: 'PKW',
      letter: 'all',
      query: '',
      expanded: false
    };

    function currentMap() {
      var list = sets[state.activeSet] || [];
      return (Array.isArray(list) ? list : []).map(function (it) {
        var name = it && it.name ? String(it.name) : '';
        var url  = it && it.url  ? String(it.url)  : '';
        return { name: name, url: url };
      }).filter(function (x) { return !!x.name; });
    }

    function slugifyBrandName(name) {
      try {
        return String(name || '')
          .trim()
          .toLowerCase()
          .replace(/\s+/g, '-')
          .replace(/[\/\\]+/g, '-')
          .replace(/&/g, 'and')
          .replace(/[^a-z0-9\-]/g, '')
          .replace(/\-+/g, '-')
          .replace(/^\-+|\-+$/g, '');
      } catch (_) {
        return '';
      }
    }

    function brandLogoBaseUrl(name) {
      var slug = slugifyBrandName(name);
      if (!slug) return '';
      return shopBase() + '/plugins/MarkeFiltre/templates/img/brands/' + slug;
    }

    function brandInitial(name) {
      try {
        var s = String(name || '').trim();
        return s ? s.charAt(0).toUpperCase() : '?';
      } catch (_) {
        return '?';
      }
    }

    function buildLetters(names) {
      if (!letterbar) return;
      letterbar.innerHTML = '';
      var all = document.createElement('button');
      all.type = 'button';
      all.className = 'mf-chip mf-is-active';
      all.dataset.letter = 'all';
      all.textContent = 'All';
      letterbar.appendChild(all);

      var letters = {};
      names.forEach(function (n) {
        var ch = (n || '').trim().charAt(0).toUpperCase();
        if (ch) letters[ch] = true;
      });
      Object.keys(letters).sort().forEach(function (ch) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'mf-chip';
        b.dataset.letter = ch;
        b.textContent = ch;
        letterbar.appendChild(b);
      });
    }

    function applyActiveChips() {
      qsa('.mf-chip', letterbar).forEach(function (c) {
        c.classList.toggle('mf-is-active', (c.dataset.letter || '') === state.letter);
      });
    }

    function filterList(list) {
      var out = list.slice();
      if (state.letter !== 'all') {
        out = out.filter(function (it) { return it.name.toUpperCase().startsWith(state.letter); });
      }
      if (state.query) {
        var q = state.query.toLowerCase();
        out = out.filter(function (it) { return it.name.toLowerCase().indexOf(q) !== -1; });
      }
      return out;
    }

    function render() {
      if (!grid) return;
      var all = currentMap();
      var filtered = filterList(all);
      var limit = state.expanded ? filtered.length : Math.min(filtered.length, 18);

      grid.innerHTML = '';
      filtered.slice(0, limit).forEach(function (it) {
        var a = document.createElement('a');
        a.className = 'mf-brand';
        a.href = it.url || '#';
        var left = document.createElement('span');
        left.className = 'mf-brand-left';

        var logoWrap = document.createElement('span');
        logoWrap.className = 'mf-logo-wrap';

        var fallback = document.createElement('span');
        fallback.className = 'mf-logo-fallback';
        fallback.textContent = brandInitial(it.name);
        logoWrap.appendChild(fallback);

        var logoBase = brandLogoBaseUrl(it.name);
        if (logoBase) {
          var img = document.createElement('img');
          img.className = 'mf-logo';
          img.alt = it.name + ' Logo';
          img.loading = 'lazy';
          img.decoding = 'async';
          img.src = logoBase + '.svg';
          img.addEventListener('error', function () {
            // Try png fallback, otherwise hide
            if (img.dataset.pngTried === '1') {
              img.style.display = 'none';
              logoWrap.classList.add('mf-has-fallback');
              return;
            }
            img.dataset.pngTried = '1';
            img.src = logoBase + '.png';
          });
          img.addEventListener('load', function () {
            logoWrap.classList.remove('mf-has-fallback');
          });
          logoWrap.insertBefore(img, fallback);
        }

        // default: show fallback until image loads (or forever if no image)
        logoWrap.classList.add('mf-has-fallback');
        left.appendChild(logoWrap);

        var label = document.createElement('span');
        label.className = 'mf-brand-name';
        label.textContent = it.name;
        left.appendChild(label);
        a.appendChild(left);
        grid.appendChild(a);
      });

      if (moreBtn) {
        moreBtn.style.display = filtered.length > 18 ? 'inline-flex' : 'none';
        moreBtn.textContent = state.expanded ? 'Einklappen' : 'Weitere Marken';
      }
    }

    function setActiveSet(name) {
      state.activeSet = name;
      state.letter = 'all';
      state.query = '';
      state.expanded = false;
      if (search) search.value = '';

      tabs.forEach(function (t) {
        t.classList.toggle('mf-is-active', (t.dataset.mfTab || '') === name);
      });

      var names = currentMap().map(function (x) { return x.name; });
      buildLetters(names);
      applyActiveChips();
      render();
    }

    if (letterbar) {
      letterbar.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('button[data-letter]') : null;
        if (!btn) return;
        state.letter = btn.dataset.letter || 'all';
        state.expanded = false;
        applyActiveChips();
        render();
      });
    }

    if (search) {
      search.addEventListener('input', function () {
        state.query = (search.value || '').trim();
        state.expanded = false;
        render();
      });
    }

    tabs.forEach(function (t) {
      t.addEventListener('click', function () {
        setActiveSet(t.dataset.mfTab || 'PKW');
      });
    });

    if (moreBtn) {
      moreBtn.addEventListener('click', function () {
        state.expanded = !state.expanded;
        render();
      });
    }

    fetchBrands().finally(function () {
      setActiveSet('PKW');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

