<?php

namespace Plugin\MarkeFiltre\Controller;

use JTL\DB\DbInterface;
use JTL\Shop;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class MarkeFiltreController
{
    public function brands(ServerRequestInterface $request): ResponseInterface
    {
        /** @var DbInterface $db */
        $db = Shop::Container()->getDB();
        $langID = (int)Shop::getLanguageID();
        $shopURL = Shop::getURL();

        // Wohnmobil markaları: sadece gerçekten ürünlerde kullanılan "Fahrzeug-Marke" değerleri.
        // (FilterKonfiguratorSearch dashboard snapshot sorgusuyla uyumlu JOIN mantığı)
        $items = [];
        $tryLangs = [$langID];
        if ($langID !== 1) {
            $tryLangs[] = 1;
        }
        foreach ($tryLangs as $lid) {
            $rows = $db->getObjects(
                "SELECT DISTINCT tmws_her.cWert AS name
                   FROM tartikel a
             INNER JOIN tartikelmerkmal am_typ
                     ON am_typ.kArtikel = a.kArtikel
             INNER JOIN tmerkmalwert mw_typ
                     ON mw_typ.kMerkmalWert = am_typ.kMerkmalWert
             INNER JOIN tmerkmal m_typ
                     ON m_typ.kMerkmal = mw_typ.kMerkmal
             INNER JOIN tmerkmalsprache ms_typ
                     ON ms_typ.kMerkmal = m_typ.kMerkmal
                    AND ms_typ.kSprache = :lid
                    AND ms_typ.cName    = 'Wohnmobil-Aufbauart'
             INNER JOIN tmerkmalwertsprache tmws_typ
                     ON tmws_typ.kMerkmalWert = mw_typ.kMerkmalWert
                    AND tmws_typ.kSprache     = :lid
             INNER JOIN tartikelmerkmal am_her
                     ON am_her.kArtikel = a.kArtikel
             INNER JOIN tmerkmalwert mw_her
                     ON mw_her.kMerkmalWert = am_her.kMerkmalWert
             INNER JOIN tmerkmal m_her
                     ON m_her.kMerkmal = mw_her.kMerkmal
             INNER JOIN tmerkmalsprache ms_her
                     ON ms_her.kMerkmal = m_her.kMerkmal
                    AND ms_her.kSprache = :lid
                    AND ms_her.cName    = 'Fahrzeug-Marke'
             INNER JOIN tmerkmalwertsprache tmws_her
                     ON tmws_her.kMerkmalWert = mw_her.kMerkmalWert
                    AND tmws_her.kSprache     = :lid
                  WHERE a.nIstVater = 0
                    AND TRIM(tmws_her.cWert) <> ''
                    AND tmws_her.cWert NOT REGEXP '^[0-9]+$'
               ORDER BY tmws_her.cWert ASC
                  LIMIT 500",
                ['lid' => $lid]
            );
            if (\is_array($rows)) {
                foreach ($rows as $r) {
                    $name = \trim((string)($r->name ?? ''));
                    if ($name === '') {
                        continue;
                    }
                    $items[] = ['name' => $name, 'url' => ''];
                }
            }
            if ($items !== []) {
                break;
            }
        }

        // Optional: Eğer thersteller doluysa ve URL istiyorsan, buraya mapping ekleyebiliriz.
        // Şimdilik url boş bırakıldı (frontend link # olur, bunu sonra yönlendirme mantığıyla bağlarız).

        // Şimdilik iki tab da aynı kaynaktan (DB) beslenir.
        // İstersen PKW/Wohnmobil ayrımını kategori/merkmal üzerinden ayrıca filtreleyebiliriz.
        return new JsonResponse(
            [
                'PKW'      => $items,
                'Wohnmobil'=> $items,
            ],
            200,
            [],
            \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES
        );
    }
}

