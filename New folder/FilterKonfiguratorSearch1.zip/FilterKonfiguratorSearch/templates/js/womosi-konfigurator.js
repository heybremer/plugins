(function () {
  'use strict';

  window.addEventListener('DOMContentLoaded', function () {
    var FK_STATE_CACHE_KEY = 'womosi_fk_state_v1';

    function deleteCookieByName(name) {
      try {
        // Try common path variants.
        document.cookie = name + '=; Max-Age=0; path=/; SameSite=Lax';
        document.cookie = name + '=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax';
        document.cookie = name + '=; Max-Age=0; path=/WomosiWeb; SameSite=Lax';
        document.cookie = name + '=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/WomosiWeb; SameSite=Lax';
      } catch (_) {}
    }

    function clearGlobalFkState() {
      try { window.localStorage.removeItem(FK_STATE_CACHE_KEY); } catch (_) {}
      deleteCookieByName(FK_STATE_CACHE_KEY);
    }

    // Global: logo click her sayfada state'i temizlesin (container olmasa da).
    // Delegated listener kullaniyoruz ki header/logo sonradan render edilse bile yakalansin.
    try {
      document.addEventListener('click', function (e) {
        var t = e && e.target ? e.target : null;
        if (!t || !t.closest) return;
        var logoAnchor = t.closest('a.navbar-brand');
        if (!logoAnchor) return;
        var hasShopLogoImg = !!logoAnchor.querySelector('#shop-logo');
        if (!hasShopLogoImg) return;
        clearGlobalFkState();
      }, true);
    } catch (_) {}

    var container = document.querySelector('.womosi-konfigurator');
    if (!container) {
      console.warn('Womosi Konfigurator: Container nicht gefunden');
      return;
    }

    // Konfigüratör her zaman görünsün.
    // "Sayfa konfigüratöre gitmesin" isteği için scroll davranışını aşağıda engelliyoruz.
    container.style.display = '';

    // ==== Yardımcılar ====

    function fkBase() {
      if (typeof window !== 'undefined' && window.WomosiFkBase) {
        return String(window.WomosiFkBase).replace(/\/+$/, '');
      }
      return '';
    }

    var fkLoadingEl = container.querySelector('#fkLoading');
    var pendingFetches = 0;

    function setLoading(isLoading) {
      if (!fkLoadingEl) return;
      fkLoadingEl.classList.toggle('hidden', !isLoading);
      fkLoadingEl.setAttribute('aria-hidden', isLoading ? 'false' : 'true');
    }

    function fetchJson(url, paramsObj) {
      var params = new URLSearchParams(paramsObj || {});
      var full = fkBase() + url + (params.toString() ? ('?' + params.toString()) : '');
      pendingFetches++;
      setLoading(true);
      return fetch(full, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function (res) {
        return res.json();
      }).finally(function () {
        pendingFetches = Math.max(0, pendingFetches - 1);
        if (pendingFetches === 0) {
          setLoading(false);
        }
      });
    }

    function uniqSorted(arr) {
      return Array.from(new Set(arr)).filter(Boolean).sort(function (a, b) {
        return a.localeCompare(b, 'de');
      });
    }

    function fillSelect(sel, values) {
      if (!sel) return;
      sel.innerHTML = '';
      var emptyOpt = document.createElement('option');
      emptyOpt.value = '';
      emptyOpt.textContent = 'Bitte wählen';
      sel.appendChild(emptyOpt);
      (values || []).forEach(function (v) {
        var o = document.createElement('option');
        o.value = v;
        o.textContent = v;
        sel.appendChild(o);
      });
    }

    function setClearBtnVisible(targetEl, isVisible) {
      if (!targetEl) return;
      var field = targetEl.closest ? targetEl.closest('.field') : null;
      if (!field) return;
      var btn = field.querySelector('.fk-clear-btn[data-clear-target]') ||
                field.querySelector('.fk-clear-btn1[data-clear-target]');
      if (!btn) return;
      btn.style.display = isVisible ? 'flex' : 'none';
    }

    // Modern status modal (success/error)
    var fkSuccessOverlay = document.getElementById('fkSuccessOverlay');
    var fkSuccessIcon    = document.getElementById('fkSuccessIcon');
    var fkSuccessTitle   = document.getElementById('fkSuccessTitle');
    var fkSuccessMessage = document.getElementById('fkSuccessMessage');
    var fkSuccessClose   = document.getElementById('fkSuccessClose');
    var statusModalTimer = null;

    function showStatusModal(type, title, message) {
      if (!fkSuccessOverlay || !fkSuccessTitle || !fkSuccessMessage || !fkSuccessIcon) {
        alert((title ? (title + '\n\n') : '') + (message || ''));
        return;
      }
      if (statusModalTimer) {
        clearTimeout(statusModalTimer);
        statusModalTimer = null;
      }
      fkSuccessTitle.textContent = title || (type === 'error' ? 'Fehler' : 'Erfolg');
      fkSuccessMessage.textContent = message || '';
      fkSuccessIcon.textContent = type === 'error' ? '!' : '✓';
      fkSuccessOverlay.classList.remove('hidden');
      fkSuccessOverlay.setAttribute('aria-hidden', 'false');
      statusModalTimer = setTimeout(function () {
        hideStatusModal();
      }, 4000);
    }

    function hideStatusModal() {
      if (!fkSuccessOverlay) return;
      fkSuccessOverlay.classList.add('hidden');
      fkSuccessOverlay.setAttribute('aria-hidden', 'true');
      if (statusModalTimer) {
        clearTimeout(statusModalTimer);
        statusModalTimer = null;
      }
    }

    // ==== DOM referansları ====

    var step1 = container.querySelector('#step1');
    var step2 = container.querySelector('#step2');
    var step3 = container.querySelector('#step3');
    var step4 = container.querySelector('#step4');

    var lbl1 = container.querySelector('#lbl1');
    var lbl2 = container.querySelector('#lbl2');
    var lbl3 = container.querySelector('#lbl3');
    var lbl4 = container.querySelector('#lbl4');
    var dot1 = container.querySelector('#dot1');
    var dot2 = container.querySelector('#dot2');
    var dot3 = container.querySelector('#dot3');
    var dot4 = container.querySelector('#dot4');
    var bar  = container.querySelector('#bar');
    var stepText = container.querySelector('#stepText');

    var vehicleGrid = container.querySelector('#vehicleGrid');
    var toStep2Btn  = container.querySelector('#toStep2');
    var backTo1Btn  = container.querySelector('#backTo1');
    var toStep3Btn  = container.querySelector('#toStep3');
    var backTo2Btn  = container.querySelector('#backTo2');
    var toStep4Btn  = container.querySelector('#toStep4');
    var backTo3Btn  = container.querySelector('#backTo3');
    var finishBtn   = container.querySelector('#finish');
    var resetBtn    = container.querySelector('#resetAll');

    // Select ve inputlar (HTML’deki id’lere göre)
    var selHer   = container.querySelector('#hersteller');
    var selBasis = container.querySelector('#basisfahrzeug');
    var selMod   = container.querySelector('#modell');
    var inpModCustom = container.querySelector('#modell_custom');
    var inpYear  = container.querySelector('#baujahr');
    var seatGrid = container.querySelector('#seatGrid');
    var seatHint = container.querySelector('#seatHint');
    var selSerie = container.querySelector('#serie');
    var serieGrid = container.querySelector('#serieGrid');
    var serieHint = container.querySelector('#serieHint');
    var serieEmptyFallback = container.querySelector('#serieEmptyFallback');
    var serieFallbackForm  = container.querySelector('#serieFallbackForm');
    var fallbackImagesInput  = container.querySelector('#fallback_images');
    var fallbackImagesTrigger = container.querySelector('#fallback_images_trigger');
    var fallbackImagesInfo    = container.querySelector('#fallback_images_info');

    // Özet alanları
    var sumTyp    = container.querySelector('#sumTyp');
    var sumHer    = container.querySelector('#sumHer');
    var sumModell = container.querySelector('#sumModell');
    var sumYear   = container.querySelector('#sumYear');
    var sumSitz   = container.querySelector('#sumSitz');
    var sumSerie  = container.querySelector('#sumSerie');
    var cardEl = container.querySelector('.card');

    // ==== State ====

    var state = {
      step: 1,
      typKey: '',
      typLabel: '',
      hersteller: '',
      basis: '',
      modell: '',
      modellCustom: '',
      year: '',
      seatId: '',
      seatLabel: '',
      serie: '',
      isLoadingSerie: false
    };

    var seatOptions = [];
    var seatOptionsKey = '';
    var serieCache = [];
    var serieCacheKey = '';
    var lastSelectionLogKey = '';
    // When we restore from localStorage, some fetch/render functions reset selections.
    // These targets allow us to preserve the user's last seat/serie during restore.
    var restoreTargetSeatId = '';
    var restoreTargetSerieCode = '';
    // Initial page açılışında otomatik scroll olmasın istiyoruz.
    var isInitialPageLoad = true;
    // Sıfırlama gibi durumlarda scroll'ı bastırmak için.
    var suppressStepScroll = false;

    function scrollStepIntoView(stepEl) {
      if (isInitialPageLoad) return;
      try {
        if (!stepEl || !stepEl.scrollIntoView) return;
        window.requestAnimationFrame(function () {
          stepEl.scrollIntoView({ behavior: 'auto', block: 'start', inline: 'nearest' });
        });
      } catch (_) {}
    }

    function saveStateCache() {
      try {
        var payload = {
          step: state.step || 1,
          typKey: state.typKey || '',
          typLabel: state.typLabel || '',
          hersteller: state.hersteller || '',
          basis: state.basis || '',
          modell: state.modell || '',
          modellCustom: state.modellCustom || '',
          year: state.year || '',
          seatId: state.seatId || '',
          seatLabel: state.seatLabel || '',
          serie: state.serie || ''
        };
        window.localStorage.setItem(FK_STATE_CACHE_KEY, JSON.stringify(payload));
      } catch (_) {}
    }

    function clearStateCache() {
      try {
        window.localStorage.removeItem(FK_STATE_CACHE_KEY);
      } catch (_) {}
    }

    function ensureSelectValue(sel, value) {
      if (!sel || !value) return;
      var wanted = String(value);
      var exists = false;
      Array.prototype.slice.call(sel.options || []).forEach(function (opt) {
        if (String(opt.value) === wanted) exists = true;
      });
      if (!exists) {
        var o = document.createElement('option');
        o.value = wanted;
        o.textContent = wanted;
        sel.appendChild(o);
      }
      sel.value = wanted;
    }

    function restoreStateCache() {
      try {
        var raw = window.localStorage.getItem(FK_STATE_CACHE_KEY);
        if (!raw) return false;
        var cached = JSON.parse(raw);
        if (!cached || typeof cached !== 'object') return false;

        state.typKey = String(cached.typKey || '');
        state.typLabel = String(cached.typLabel || '');
        state.hersteller = String(cached.hersteller || '');
        state.basis = String(cached.basis || '');
        state.modell = String(cached.modell || '');
        state.modellCustom = String(cached.modellCustom || '');
        state.year = String(cached.year || '');
        state.seatId = String(cached.seatId || '');
        state.seatLabel = String(cached.seatLabel || '');
        state.serie = String(cached.serie || '');
        
        // Preserve targets for restore mode (Step 3 Sitz + Step 4 Serie).
        restoreTargetSeatId = state.seatId || '';
        restoreTargetSerieCode = state.serie || '';

        var desiredStep = parseInt(cached.step, 10);
        if (!desiredStep || desiredStep < 1 || desiredStep > 4) desiredStep = 1;

        // Restore visible controls quickly (without waiting API chains)
        if (vehicleGrid && state.typKey) {
          vehicleGrid.querySelectorAll('.tile-link.is-active').forEach(function (a) {
            a.classList.remove('is-active');
          });
          var activeLink = vehicleGrid.querySelector('a.tile-link[data-key="' + state.typKey.replace(/"/g, '\\"') + '"]');
          if (activeLink) activeLink.classList.add('is-active');
        }
        ensureSelectValue(selHer, state.hersteller);
        ensureSelectValue(selBasis, state.basis);
        ensureSelectValue(selMod, state.modell);
        ensureSelectValue(selSerie, state.serie);
        if (inpModCustom) inpModCustom.value = state.modellCustom || '';
        if (inpYear) inpYear.value = state.year || '';

        updateSummary();
        setStep(desiredStep);
        // İlk sayfa yüklemesi sırasında isInitialPageLoad true olduğu için scroll engelli.

        // If returning directly to step 4, refresh series list and reseat selection.
        if (desiredStep === 4) {
          loadSerie();
        }
        return true;
      } catch (_) {
        return false;
      }
    }

    function selectionLogKey(serieCode) {
      var modellParam = state.modell || state.modellCustom || '';
      return [
        state.typLabel || '',
        state.hersteller || '',
        state.basis || '',
        modellParam,
        String(state.year || ''),
        String(state.seatLabel || state.seatId || ''),
        String(serieCode || '')
      ].join('||');
    }

    function logStep4Selection(serieCode) {
      if (!serieCode) return;
      // Avoid duplicates (tile click + select change can both fire)
      var key = selectionLogKey(serieCode);
      if (key === lastSelectionLogKey) return;
      lastSelectionLogKey = key;

      var selectionEndpoint = fkBase() + '/fk-selection';

      var payload = new URLSearchParams({
        typ: state.typLabel || '',
        hersteller: state.hersteller || '',
        basis: state.basis || '',
        modell: state.modell || state.modellCustom || '',
        baujahr: state.year || '',
        sitz: (state.seatLabel || state.seatId || ''),
        serie: serieCode || ''
      });

      try {
        // keepalive helps with short navigation, but still best-effort.
        fetch(selectionEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
          body: payload,
          keepalive: true,
          credentials: 'same-origin'
        }).catch(function () {});
      } catch (_) {}
    }

    var SEAT_META = {
      '1':  { code: '1',  name: 'Sitz 1',  tooltip: 'Milan 12',              img: 'https://womosi.de/mediafiles/sitz/1.jpg' },
      '2':  { code: '2',  name: 'Sitz 2',  tooltip: 'Liner 12',              img: 'https://womosi.de/mediafiles/sitz/2.jpg' },
      '3':  { code: '3',  name: 'Sitz 3',  tooltip: 'Captain Chair',              img: 'https://womosi.de/mediafiles/sitz/3.jpg' },
      '4':  { code: '4',  name: 'Sitz 4',  tooltip: 'Itineo',     img: 'https://womosi.de/mediafiles/sitz/4.jpg' },
      '5':  { code: '5',  name: 'Sitz 5',  tooltip: 'Standart Ducato Sitz',               img: 'https://womosi.de/mediafiles/sitz/5.jpg' },
      '6':  { code: '6',  name: 'Sitz 6',  tooltip: 'Milan',      img: 'https://womosi.de/mediafiles/sitz/6.jpg' },
      '7':  { code: '7',  name: 'Sitz 7',  tooltip: 'Gis Liner',    img: 'https://womosi.de/mediafiles/sitz/7.jpg' },
      '8':  { code: '8',  name: 'Sitz 8',  tooltip: 'Gis Liner 3',               img: 'https://womosi.de/mediafiles/sitz/8.jpg' },
      '9':  { code: '9',  name: 'Sitz 9',  tooltip: 'Ford Transit',            img: 'https://womosi.de/mediafiles/sitz/9.jpg' },
      '10': { code: '10', name: 'Sitz 10', tooltip: 'Ford Pilot',  img: 'https://womosi.de/mediafiles/sitz/10.jpg' },
      '11': { code: '11', name: 'Sitz 11', tooltip: 'Mian 3',  img: 'https://womosi.de/mediafiles/sitz/11.jpg' },
      '12': { code: '12', name: 'Sitz 12', tooltip: 'SKA 1800-M23 Komfort',  img: 'https://womosi.de/mediafiles/sitz/12.jpg' },
      '13': { code: '13', name: 'Sitz 13', tooltip: 'SKA 1800-1000 M23 Classic',  img: 'https://womosi.de/mediafiles/sitz/13.jpg' },
      '14': { code: '14', name: 'Sitz 14', tooltip: 'Mercedes Sprinter',  img: 'https://womosi.de/mediafiles/sitz/14.jpg' }
    };

    function seatCodeFromValue(v) {
      var s = String(v || '').trim();
      if (!s) return '';
      // Accept "1", "01", "Sitz 1", "Sitz 10", etc.
      var m = s.match(/(\d{1,2})/);
      if (!m) return '';
      var code = String(parseInt(m[1], 14));
      return SEAT_META[code] ? code : '';
    }

    var SERIES_META = {
      C:   { label: 'Serie C',   color: '#e3f2fd', img: 'https://womosi.de/mediafiles/seat/c-serie.avif' },
      DPL: { label: 'Serie DPL', color: '#f3e5f5', img: 'https://womosi.de/mediafiles/seat/dpl-serie.avif' },
      H:   { label: 'Serie H',   color: '#e8f5e9', img: 'https://womosi.de/mediafiles/seat/h-serie.avif' },
      PLKT:{ label: 'Serie PLKT',color: '#fff8e1', img: 'https://womosi.de/mediafiles/seat/plkt-serie.avif' },
      WPL: { label: 'Serie WPL', color: '#e1f5fe', img: 'https://womosi.de/mediafiles/seat/wpl-serie.avif' },
      WMS: { label: 'Serie WMS', color: '#ede7f6', img: 'https://womosi.de/mediafiles/seat/wms-serie.avif' },
      T:   { label: 'Serie T',   color: '#f1f8e9', img: 'https://womosi.de/mediafiles/seat/t-serie.avif' },
      HW:  { label: 'Serie HW',  color: '#ffe0e0', img: 'https://womosi.de/mediafiles/seat/hw-serie.avif' },
      BC:  { label: 'Serie BC',  color: '#e0f7fa', img: 'https://womosi.de/mediafiles/seat/bc-serie.avif' },
      DS:  { label: 'Serie DS',  color: '#fff3e0', img: 'https://womosi.de/mediafiles/seat/ds-serie.avif' },
      LT:  { label: 'Serie LT',  color: '#e0ffe8', img: 'https://womosi.de/mediafiles/seat/lt-serie.avif' },
      800: { label: 'Serie 800er', color: '#f0f4ff', img: 'https://womosi.de/mediafiles/seat/800er-serie.avif' },
      WMA: { label: 'Aguti Sitze', color: '#fce4ec', img: 'https://womosi.de/mediafiles/seat/aguti-sitze-serie.avif' }
    };

    // ==== Step kontrol ====

    function setStep(n) {
      // Step değişirken bazı tarayıcılar odaklanan element'i görünür kılmak için scroll yapabilir.
      // Bunu engellemek için önce aktif element'i blur'layalım.
      try {
        var ae = document.activeElement;
        if (ae && ae.blur) ae.blur();
      } catch (_) {}

      state.step = n;

      if (step1) step1.classList.toggle('hidden', n !== 1);
      if (step2) step2.classList.toggle('hidden', n !== 2);
      if (step3) step3.classList.toggle('hidden', n !== 3);
      if (step4) step4.classList.toggle('hidden', n !== 4);

      var labels = [lbl1, lbl2, lbl3, lbl4];
      var dots   = [dot1, dot2, dot3, dot4];
      labels.forEach(function (l, i) {
        if (!l || !dots[i]) return;
        if (i + 1 === n) {
          l.classList.add('active');
          dots[i].classList.add('active');
        } else {
          l.classList.remove('active');
          dots[i].classList.remove('active');
        }
      });

      if (bar) {
        bar.style.width = (25 * n) + '%';
      }
      if (stepText) {
        stepText.textContent = 'Step ' + n + '/4';
      }

      updateButtons();
      // Sadece Step 1-2-3 geçişlerinde scroll:
      // kullanıcı isteği -> her seferinde .card alanına kaydır.
      if ((n === 1 || n === 2 || n === 3) && !suppressStepScroll) scrollStepIntoView(cardEl);

      if (n === 3) {
        loadSitzOptions();
      }
    }

    function validateStep2() {
      if (!state.typKey) return { ok: false, msg: 'Bitte zuerst Fahrzeugtyp wählen.' };
      if (!state.hersteller) return { ok: false, msg: 'Bitte Hersteller wählen.' };
      if (!state.basis) return { ok: false, msg: 'Bitte Wohnmobil-Fahrgestell wählen.' };

      var m = (state.modell || state.modellCustom || '').trim();
      if (!m) return { ok: false, msg: 'Bitte Modell wählen oder eintragen.' };

      var y = (state.year || '').trim();
      var yn = y ? Number(y) : NaN;
      if (!y || !Number.isInteger(yn) || yn < 1900 || yn > 2100) {
        return { ok: false, msg: 'Bitte gültiges Baujahr (1900–2100) eingeben.' };
      }
      return { ok: true, msg: '' };
    }

    function updateButtons() {
      var v2 = validateStep2().ok;

      if (toStep2Btn) toStep2Btn.disabled = !state.typKey;
      if (toStep3Btn) toStep3Btn.disabled = !v2;
      if (toStep4Btn) toStep4Btn.disabled = !state.seatId;
      if (finishBtn) finishBtn.disabled   = !state.serie;
    }

    // ==== Özet ====

    function updateSummary() {
      if (sumTyp)    sumTyp.textContent    = state.typLabel   || '–';
      if (sumHer)    sumHer.textContent    = state.hersteller || '–';
      var modellText = state.modell || state.modellCustom || '–';
      if (sumModell) sumModell.textContent = modellText;
      if (sumYear)   sumYear.textContent   = state.year       || '–';
      if (sumSitz)   sumSitz.textContent   = state.seatLabel  || '–';
      if (sumSerie)  sumSerie.textContent  = state.serie      || '–';

      updateButtons();
      saveStateCache();
    }

    function hardReset() {
      // State sıfırla
      state.step       = 1;
      state.typKey     = '';
      state.typLabel   = '';
      state.hersteller = '';
      state.basis      = '';
      state.modell     = '';
      state.year       = '';
      state.seatId     = '';
      state.seatLabel  = '';
      state.serie      = '';

      seatOptions    = [];
      seatOptionsKey = '';

      // Step 1: Fahrzeugtyp seçimlerini kaldır
      if (vehicleGrid) {
        vehicleGrid.querySelectorAll('.tile-link.is-active').forEach(function (a) {
          a.classList.remove('is-active');
        });
      }

      // Step 2: dropdown ve Baujahr input'unu temizle
      if (selHer) {
        fillSelect(selHer, []);
        selHer.value = '';
        setClearBtnVisible(selHer, false);
      }
      if (selBasis) {
        fillSelect(selBasis, []);
        selBasis.value = '';
        setClearBtnVisible(selBasis, false);
      }
      if (selMod) {
        fillSelect(selMod, []);
        selMod.value = '';
        setClearBtnVisible(selMod, false);
      }
      if (inpModCustom) {
        inpModCustom.value = '';
        setClearBtnVisible(inpModCustom, false);
      }
      if (inpYear) {
        inpYear.value = '';
        setClearBtnVisible(inpYear, false);
      }

      // Step 3: Sitz gridini temizle
      if (seatGrid) {
        seatGrid.innerHTML = '';
      }
      if (seatHint) {
        seatHint.textContent = '';
      }

      // Step 4: Serie select ve gridini temizle
      if (selSerie) {
        fillSelect(selSerie, []);
        selSerie.value = '';
      }
      if (serieGrid) {
        serieGrid.innerHTML = '';
      }
      if (serieEmptyFallback) {
        serieEmptyFallback.classList.add('hidden');
      }
      if (serieHint) {
        serieHint.classList.remove('hidden');
      }

      // Step ve özet'i başa sar
      setStep(1);
      updateSummary();
      clearStateCache();
    }

    // ==== Dropdown yükleme ====

    function loadHersteller() {
      fetchJson('/fk-search', {
        mode: 'options',
        field: 'hersteller',
        typ: state.typKey || ''
      }).then(function (data) {
        var vals = uniqSorted(
          (Array.isArray(data) ? data : [])
            .map(function (row) { return row && row.value ? String(row.value) : ''; })
        );
        fillSelect(selHer, vals);
        state.hersteller = '';
        state.basis = '';
        state.modell = '';
        if (selBasis) fillSelect(selBasis, []);
        if (selMod)   fillSelect(selMod,   []);
        updateSummary();
      }).catch(function () {
        fillSelect(selHer, []);
      });
    }

    function loadBasis() {
      if (!state.typKey || !state.hersteller) {
        if (selBasis) fillSelect(selBasis, []);
        return;
      }
      fetchJson('/fk-search', {
        mode: 'options',
        field: 'basis',
        typ: state.typKey || '',
        hersteller: state.hersteller || ''
      }).then(function (data) {
        var vals = uniqSorted(
          (Array.isArray(data) ? data : [])
            .map(function (row) { return row && row.value ? String(row.value) : ''; })
        );
        if (selBasis) fillSelect(selBasis, vals);
        state.basis = '';
        state.modell = '';
        if (selMod) {
          fillSelect(selMod, []);
          selMod.value = '';
          setClearBtnVisible(selMod, false);
        }
        updateSummary();
      }).catch(function () {
        if (selBasis) fillSelect(selBasis, []);
      });
    }

    function loadModell() {
      if (!state.typKey || !state.hersteller || !state.basis) {
        fillSelect(selMod, []);
        return;
      }
      fetchJson('/fk-search', {
        mode: 'options',
        field: 'modell',
        typ: state.typKey || '',
        hersteller: state.hersteller || '',
        basis: state.basis || ''
      }).then(function (data) {
        var vals = uniqSorted(
          (Array.isArray(data) ? data : [])
            .map(function (row) { return row && row.value ? String(row.value) : ''; })
        );
        fillSelect(selMod, vals);
        state.modell = '';
        state.modellCustom = '';
        if (inpModCustom) {
          inpModCustom.value = '';
          setClearBtnVisible(inpModCustom, false);
        }
        updateSummary();
      }).catch(function () {
        fillSelect(selMod, []);
      });
    }

    function renderSeats(values) {
      if (!seatGrid) return;
      seatGrid.innerHTML = '';
      var list = Array.isArray(values) ? values : [];
      if (!list.length) {
        if (seatHint) seatHint.textContent = 'Keine kompatiblen Sitze gefunden.';
        state.seatId = '';
        state.seatLabel = '';
        updateSummary();
        return;
      }
      if (seatHint) seatHint.textContent = 'Wähle deinen Sitz.';
      list.forEach(function (label) {
        var seatValue = String(label || '').trim();
        if (!seatValue) return;
        var code = seatCodeFromValue(seatValue);
        var meta = code ? SEAT_META[code] : null;
        var a = document.createElement('a');
        a.href = '#';
        a.className = 'tile-link' + (state.seatId === seatValue ? ' is-active' : '');

        var tile = document.createElement('div');
        tile.className = 'tile';
        if (meta && meta.tooltip) {
          tile.setAttribute('data-tooltip', meta.tooltip);
        }

        if (meta && meta.img) {
          var imgWrap = document.createElement('div');
          imgWrap.className = 'imgWrap';
          var img = document.createElement('img');
          img.loading = 'lazy';
          img.decoding = 'async';
          img.src = meta.img;
          img.alt = meta.name || seatValue;
          imgWrap.appendChild(img);
          tile.appendChild(imgWrap);
        }

        var name = document.createElement('div');
        name.className = 'name';
        name.textContent = (meta && meta.name) ? meta.name : seatValue;
        tile.appendChild(name);

        a.appendChild(tile);
        a.addEventListener('click', function (e) {
          e.preventDefault();
          state.seatId = seatValue;
          state.seatLabel = (meta && meta.name) ? meta.name : seatValue;
          renderSeats(list);
          updateSummary();
          // Sitz seçildikten sonra otomatik Step 4'e geç ve Serileri yükle
          setStep(4);
          loadSerie();
        });
        seatGrid.appendChild(a);
      });
    }

    function loadSitzOptions() {
      var preserveSeat = !!restoreTargetSeatId;
      if (!state.typKey || !state.hersteller || !state.basis || !state.modell) {
        seatOptions = [];
        seatOptionsKey = '';
        renderSeats([]);
        restoreTargetSeatId = '';
        return;
      }

      var key = [state.typKey, state.hersteller, state.basis, state.modell].join('||');
      if (key === seatOptionsKey && seatOptions.length) {
        renderSeats(seatOptions);
        if (preserveSeat) restoreTargetSeatId = '';
        return;
      }

      if (seatHint) seatHint.textContent = 'Lade Sitze...';

      fetchJson('/fk-search', {
        mode: 'options',
        field: 'sitz',
        typ: state.typKey || '',
        hersteller: state.hersteller || '',
        basis: state.basis || '',
        modell: state.modell || ''
      }).then(function (data) {
        var vals = uniqSorted(
          (Array.isArray(data) ? data : [])
            .map(function (row) { return row && row.value ? String(row.value) : ''; })
        );
        seatOptions = vals;
        seatOptionsKey = key;
        if (!preserveSeat) {
          state.seatId = '';
          state.seatLabel = '';
        }
        renderSeats(seatOptions);
        updateSummary();
        if (preserveSeat) restoreTargetSeatId = '';
      }).catch(function () {
        seatOptions = [];
        seatOptionsKey = '';
        renderSeats([]);
        restoreTargetSeatId = '';
      });
    }

    function loadSerie() {
      if (!selSerie) return;

      // Özel durum: Kullanıcı dropdown'dan Modell seçmemiş, yalnızca "Ihr Modell nicht dabei?" alanını doldurmuşsa
      // (bunu hem state'ten hem de DOM'daki gerçek değerden kontrol ediyoruz),
      // doğrudan Maßanfertigung formunu göster, Serie araması yapma.
      var domModellValue = selMod && selMod.value ? String(selMod.value).trim() : '';
      var domCustomValue = inpModCustom && inpModCustom.value ? String(inpModCustom.value).trim() : '';
      var hasOnlyCustomModel = !domModellValue && !!domCustomValue;

      if (hasOnlyCustomModel) {
        if (serieEmptyFallback) serieEmptyFallback.classList.remove('hidden');
        if (serieGrid)          serieGrid.classList.add('hidden');
        if (serieHint)          serieHint.classList.add('hidden');
        if (finishBtn)          finishBtn.disabled = true;
        fillSelect(selSerie, []);
        return;
      }

      var params = {};
      if (state.typKey)     params.typ        = state.typKey;
      if (state.hersteller) params.hersteller = state.hersteller;
      if (state.basis)      params.basis      = state.basis;
      var modellParam = state.modell || state.modellCustom;
      if (modellParam)      params.modell     = modellParam;
      if (state.seatId)     params.sitz       = state.seatId;

      var cacheKey = [
        params.typ || '',
        params.hersteller || '',
        params.basis || '',
        params.modell || '',
        params.sitz || ''
      ].join('||');

      if (cacheKey === serieCacheKey && Array.isArray(serieCache) && serieCache.length) {
        // reuse cached series items for snappy Step 4
        renderSerieItems(serieCache);
        return;
      }

      state.isLoadingSerie = true;
      updateSummary();

      fetchJson('/fk-search', params).then(function (items) {
        state.isLoadingSerie = false;
        var list = Array.isArray(items) ? items : [];
        serieCacheKey = cacheKey;
        serieCache = list;

        renderSerieItems(list);
      }).catch(function () {
        state.isLoadingSerie = false;
        fillSelect(selSerie, []);
        if (finishBtn) finishBtn.disabled = true;
      });
    }

    function renderSerieItems(list) {
      var arr = Array.isArray(list) ? list : [];
      var preserveSerie = !!restoreTargetSerieCode;
      var targetSerie    = preserveSerie ? String(restoreTargetSerieCode || '') : '';
      var foundPreserve  = false;

      // Durum 1: Hiç Serie bulunamadı -> fallback formu göster
      if (!arr.length) {
        if (serieEmptyFallback) serieEmptyFallback.classList.remove('hidden');
        if (serieGrid)          serieGrid.classList.add('hidden');
        if (serieHint)          serieHint.classList.add('hidden');
        if (finishBtn)          finishBtn.disabled = true;
        state.serie = '';
        if (selSerie) selSerie.value = '';
        if (preserveSerie) restoreTargetSerieCode = '';
        updateSummary();
        fillSelect(selSerie, []);
        return;
      }

      if (serieEmptyFallback) serieEmptyFallback.classList.add('hidden');
      if (serieGrid)          serieGrid.classList.remove('hidden');
      if (serieHint)          serieHint.classList.remove('hidden');

      var serieValues = arr
        .map(function (it) { return String(it.serie || ''); })
        .filter(Boolean);

      fillSelect(selSerie, serieValues);
      if (!preserveSerie) {
        state.serie = '';
        selSerie.value = '';
      } else {
        state.serie = targetSerie;
        selSerie.value = targetSerie;
      }

      if (serieGrid) {
        serieGrid.innerHTML = '';
        arr.forEach(function (it, idx) {
          var code = String(it.serie || '').trim();
          if (!code) return;
          var url  = String(it.url   || '#');
          var meta = SERIES_META[code] || null;

          var a = document.createElement('a');
          a.href = url;
          if (preserveSerie && code === targetSerie) {
            foundPreserve = true;
          }
          a.className = 'tile-link serie-tile-link' + ((preserveSerie && code === state.serie) ? ' is-active' : '');

          var tile = document.createElement('div');
          tile.className = 'tile';

          var imgSrc = meta && meta.img ? meta.img : '';
          if (imgSrc) {
            // Warm up browser cache ASAP for perceived speed
            try {
              var pre = new Image();
              pre.decoding = 'async';
              pre.src = imgSrc;
            } catch (_) {}

            var imgWrap = document.createElement('div');
            imgWrap.className = 'serie-imgWrap';

            var img = document.createElement('img');
            // Improve LCP: prioritize first tiles, lazy for the rest
            if (idx < 2) {
              img.loading = 'eager';
              img.setAttribute('fetchpriority', 'high');
            } else {
              img.loading = 'lazy';
              img.setAttribute('fetchpriority', 'low');
            }
            img.decoding = 'async';
            img.src = imgSrc;
            img.alt = (meta && meta.label) ? meta.label : code;
            // Reserve space to reduce CLS (matches CSS aspect-ratio)
            img.width = 1600;
            img.height = 900;

            imgWrap.appendChild(img);
            tile.appendChild(imgWrap);
          }

          var desc = document.createElement('div');
          desc.className = 'serie-desc';
          desc.textContent = (meta && meta.label) ? meta.label : ('Serie ' + code);
          tile.appendChild(desc);

          a.appendChild(tile);

          a.addEventListener('click', function (e) {
            e.preventDefault();
            state.serie = code;
            selSerie.value = code;
            serieGrid.querySelectorAll('.serie-tile-link').forEach(function (x) {
              x.classList.remove('is-active');
            });
            a.classList.add('is-active');
            updateSummary();

            // Step 4 - Seçilen seri sonrası admin dashboard için log
            logStep4Selection(code);

            if (url && url !== '#') {
              // Give the logging request a moment on unload.
              window.setTimeout(function () {
                window.location.href = url;
              }, 80);
            }
          });
          serieGrid.appendChild(a);
        });
      }

      if (preserveSerie) {
        if (!foundPreserve) {
          state.serie = '';
          selSerie.value = '';
        }
        restoreTargetSerieCode = '';
      }

      updateSummary();
    }

    // ==== Event bağlama ====

    if (vehicleGrid) {
      vehicleGrid.addEventListener('click', function (e) {
        var link = e.target.closest ? e.target.closest('a.tile-link') : null;
        if (!link) return;
        e.preventDefault();
        var key   = link.getAttribute('data-key')   || '';
        var label = link.getAttribute('data-label') || link.textContent.trim();

        state.typKey   = key;
        state.typLabel = label;

        vehicleGrid.querySelectorAll('.tile-link.is-active').forEach(function (a) {
          a.classList.remove('is-active');
        });
        link.classList.add('is-active');

        loadHersteller();
        setStep(2);
        updateSummary();
      });
    }

    if (selHer) {
      selHer.addEventListener('change', function () {
        state.hersteller = selHer.value || '';
        state.basis = '';
        state.modell = '';
        state.seatId = '';
        state.seatLabel = '';
        seatOptions = [];
        seatOptionsKey = '';
        if (selBasis) {
          fillSelect(selBasis, []);
          selBasis.value = '';
          setClearBtnVisible(selBasis, false);
        }
        if (selMod) {
          fillSelect(selMod, []);
          selMod.value = '';
          setClearBtnVisible(selMod, false);
        }
        if (state.hersteller) {
          loadBasis();
        }
        updateSummary();
        setClearBtnVisible(selHer, !!state.hersteller);
      });
    }

    if (selBasis) {
      selBasis.addEventListener('change', function () {
        state.basis = selBasis.value || '';
        state.modell = '';
        state.modellCustom = '';
        if (inpModCustom) {
          inpModCustom.value = '';
          setClearBtnVisible(inpModCustom, false);
        }
        state.seatId = '';
        state.seatLabel = '';
        seatOptions = [];
        seatOptionsKey = '';
        if (selMod) {
          fillSelect(selMod, []);
          selMod.value = '';
          setClearBtnVisible(selMod, false);
        }
        if (state.basis) {
          loadModell();
        }
        updateSummary();
        setClearBtnVisible(selBasis, !!state.basis);
      });
    }

    if (selMod) {
      selMod.addEventListener('change', function () {
        state.modell = selMod.value || '';
        state.modellCustom = '';
        if (inpModCustom) {
          inpModCustom.value = '';
          setClearBtnVisible(inpModCustom, false);
        }
        state.seatId = '';
        state.seatLabel = '';
        seatOptions = [];
        seatOptionsKey = '';
        updateSummary();
        setClearBtnVisible(selMod, !!state.modell);
      });
    }

    if (inpModCustom) {
      inpModCustom.addEventListener('input', function () {
        state.modellCustom = inpModCustom.value || '';
        if (state.modellCustom) {
          // Serbest metin girildiğinde select'i sıfırla
          if (selMod) {
            selMod.value = '';
            state.modell = '';
            setClearBtnVisible(selMod, false);
          }
        }
        updateSummary();
        setClearBtnVisible(inpModCustom, !!state.modellCustom);
      });
    }

    if (inpYear) {
      inpYear.addEventListener('input', function () {
        state.year = inpYear.value || '';
        updateSummary();
        if (state.step === 2) {
          var v = validateStep2();
          if (v.ok) {
            var domModellValue = selMod && selMod.value ? String(selMod.value).trim() : '';
            var domCustomValue = inpModCustom && inpModCustom.value ? String(inpModCustom.value).trim() : '';
            var hasOnlyCustomModel = !domModellValue && !!domCustomValue;
            if (hasOnlyCustomModel) {
              setStep(4);
              loadSerie();
            } else {
              setStep(3);
            }
          }
        }
        setClearBtnVisible(inpYear, !!state.year);
      });
    }

    if (selSerie) {
      selSerie.addEventListener('change', function () {
        state.serie = selSerie.value || '';
        updateSummary();
        // Dashboard için de logla (tile yerine select kullanılabilirse)
        if (state.step === 4) {
          logStep4Selection(selSerie.value || '');
        }
      });
    }

    if (resetBtn) {
      resetBtn.addEventListener('click', function (e) {
        e.preventDefault();
        hardReset();
      });
    }

    // Status modal close handlers
    if (fkSuccessClose) {
      fkSuccessClose.addEventListener('click', function () {
        hideStatusModal();
      });
    }
    if (fkSuccessOverlay) {
      fkSuccessOverlay.addEventListener('click', function (e) {
        if (e.target === fkSuccessOverlay) {
          hideStatusModal();
        }
      });
    }
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        hideStatusModal();
      }
    });

    // Step 2 clear buttons (x)
    container.querySelectorAll('.fk-clear-btn[data-clear-target], .fk-clear-btn1[data-clear-target]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var sel = btn.getAttribute('data-clear-target') || '';
        var target = sel ? container.querySelector(sel) : null;
        if (!target) return;

        // Clear field and trigger the right event so dependent fields reset.
        if (target.tagName === 'SELECT') {
          target.value = '';
          target.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
          target.value = '';
          target.dispatchEvent(new Event('input', { bubbles: true }));
        }

        setClearBtnVisible(target, false);
      });
    });

    // Maßanfertigung – Datei-Upload Trigger
    if (fallbackImagesTrigger && fallbackImagesInput) {
      fallbackImagesTrigger.addEventListener('click', function (e) {
        e.preventDefault();
        fallbackImagesInput.click();
      });
    }

    if (fallbackImagesInput && fallbackImagesInfo) {
      fallbackImagesInput.addEventListener('change', function () {
        var files = Array.prototype.slice.call(fallbackImagesInput.files || []);
        if (!files.length) {
          fallbackImagesInfo.textContent = 'Keine Dateien ausgewählt';
          return;
        }
        if (files.length === 1) {
          fallbackImagesInfo.textContent = files[0].name;
        } else {
          fallbackImagesInfo.textContent = files.length + ' Dateien ausgewählt';
        }
      });
    }

    // Maßanfertigung – Formular via AJAX an sitzbezug-anfrage.php senden
    if (serieFallbackForm) {
      serieFallbackForm.addEventListener('submit', function (e) {
        e.preventDefault();

        var formData = new FormData(serieFallbackForm);

        // Konfigurator-Zusammenfassung als Body anhängen
        var summaryParts = [];
        if (state.typLabel)   summaryParts.push('Fahrzeugtyp: ' + state.typLabel);
        if (state.hersteller) summaryParts.push('Fahrzeug-Marke: ' + state.hersteller);
        if (state.basis)      summaryParts.push('Wohnmobil-Fahrgestell: ' + state.basis);
        var modellText = state.modell || state.modellCustom;
        if (modellText)       summaryParts.push('Fahrzeug-Modell: ' + modellText);
        if (state.year)       summaryParts.push('Baujahr: ' + state.year);
        if (state.seatLabel)  summaryParts.push('Sitz: ' + state.seatLabel);

        var existingMsg = (formData.get('message') || '').toString();
        var summaryText = summaryParts.join('\n');
        var body = summaryText;
        if (existingMsg.trim()) {
          body += '\n\n--- Nachricht / Hinweise ---\n' + existingMsg.trim();
        }
        formData.set('body', body);

        fetch('/sitzbezug-anfrage.php', {
          method: 'POST',
          body: formData
        })
          .then(function (res) { return res.json(); })
          .then(function (data) {
            if (data && data.ok) {
              showStatusModal(
                'success',
                'Vielen Dank!',
                'Ihre Anfrage ist eingegangen.\n\nWir werden uns schnellstmöglich mit Ihnen in Verbindung setzen.\n\nMit freundlichen Grüßen\nWomosi'
              );
              serieFallbackForm.reset();
              if (fallbackImagesInfo) {
                fallbackImagesInfo.textContent = 'Keine Dateien ausgewählt';
              }
            } else {
              showStatusModal(
                'error',
                'Senden nicht möglich',
                (data && data.msg) || 'Die Anfrage konnte nicht gesendet werden.'
              );
            }
          })
          .catch(function () {
            showStatusModal(
              'error',
              'Verbindungsfehler',
              'Es ist ein Fehler beim Senden der Anfrage aufgetreten.'
            );
          });
      });
    }

    if (toStep2Btn) {
      toStep2Btn.addEventListener('click', function (e) {
        e.preventDefault();
        if (!state.typKey) return;
        setStep(2);
      });
    }
    if (backTo1Btn) {
      backTo1Btn.addEventListener('click', function (e) {
        e.preventDefault();
        setStep(1);
      });
    }
    if (toStep3Btn) {
      toStep3Btn.addEventListener('click', function (e) {
        e.preventDefault();
        var v = validateStep2();
        if (!v.ok) return;
        // Eğer kullanıcı sadece "Ihr Modell nicht dabei?" alanını doldurduysa,
        // Sitz adımını atla ve doğrudan Maßanfertigung formunun olduğu Step 4'e git.
        var domModellValue = selMod && selMod.value ? String(selMod.value).trim() : '';
        var domCustomValue = inpModCustom && inpModCustom.value ? String(inpModCustom.value).trim() : '';
        var hasOnlyCustomModel = !domModellValue && !!domCustomValue;
        if (hasOnlyCustomModel) {
          setStep(4);
          loadSerie();
        } else {
          setStep(3);
        }
      });
    }
    if (backTo2Btn) {
      backTo2Btn.addEventListener('click', function (e) {
        e.preventDefault();
        setStep(2);
      });
    }
    if (toStep4Btn) {
      toStep4Btn.addEventListener('click', function (e) {
        e.preventDefault();
        if (!state.seatId) return;
        setStep(4);
        loadSerie();
      });
    }
    if (backTo3Btn) {
      backTo3Btn.addEventListener('click', function (e) {
        e.preventDefault();
        setStep(3);
      });
    }
    if (finishBtn) {
      finishBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (!state.serie) return;
        // Burada istersen seçilen Seri URL’sine gidebilirsin:
        // window.location.href = ...
      });
    }

    // ==== Başlangıç ====

    // IMPORTANT: restore first, otherwise initial empty state overwrites cache.
    if (!restoreStateCache()) {
      setStep(1);
    }
    updateSummary();

    // Initial clear button visibility
    if (selHer)   setClearBtnVisible(selHer,   !!selHer.value);
    if (selMod)   setClearBtnVisible(selMod,   !!selMod.value);
    if (selBasis) setClearBtnVisible(selBasis, !!selBasis.value);
    if (inpYear)  setClearBtnVisible(inpYear,  !!inpYear.value);

    // İlk açılış tamamlandıktan sonra scroll'a izin ver.
    window.requestAnimationFrame(function () {
      isInitialPageLoad = false;
    });
  });
})();