/**
 * Listen-/Artikelseiten: H1 aus localStorage-Konfiguratorzustand, falls keine GET-Parameter (z. B. altes Lesezeichen).
 */
(function () {
  'use strict';

  var FK_STATE_KEY = 'womosi_fk_state_v1';
  var FK_MODELL_CUSTOM = '__FK_MODELL_CUSTOM__';

  function compactFromStorage() {
    try {
      var raw = window.localStorage.getItem(FK_STATE_KEY);
      if (!raw) return '';
      var c = JSON.parse(raw);
      if (!c || typeof c !== 'object') return '';
      var parts = [];
      if (c.typLabel) parts.push(String(c.typLabel).trim());
      if (c.hersteller) parts.push(String(c.hersteller).trim());
      if (c.basis) parts.push(String(c.basis).trim());
      var m = c.modell != null ? String(c.modell).trim() : '';
      if (m === FK_MODELL_CUSTOM) {
        m = c.modellCustom ? String(c.modellCustom).trim() : '';
      } else if (!m && c.modellCustom) {
        m = String(c.modellCustom).trim();
      }
      if (m) parts.push(m);
      if (c.year) parts.push('Model ' + String(c.year).trim());
      return parts.filter(Boolean).join(' ');
    } catch (e) {
      return '';
    }
  }

  function applyTitle() {
    if (document.querySelector('.fk-selection-summary')) return;
    var line = compactFromStorage();
    if (!line) return;
    var h1 =
      document.querySelector('h1.product-title.h2') ||
      document.querySelector('div.title h1.h2') ||
      document.querySelector('div.title h1');
    if (!h1) return;
    h1.textContent = line;
    var cls = h1.getAttribute('class') || '';
    if (cls.indexOf('fk-selection-h1') === -1) {
      h1.setAttribute('class', (cls + ' fk-selection-h1').trim());
    }
    var wrap = document.createElement('div');
    wrap.className = 'fk-selection-summary';
    wrap.innerHTML =
      '<div class="fk-selection-subtitle text-muted mt-2 mb-1">' +
      '<span class="fk-selection-message"><span class="fk-selection-icon" aria-hidden="true">✔</span> Für Ihr Fahrzeug wurden passende Ergebnisse gefunden</span>' +
      '</div>';
    if (h1.parentNode) {
      h1.parentNode.insertBefore(wrap, h1.nextSibling);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTitle);
  } else {
    applyTitle();
  }
})();
