(function () {
  function escAttr(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/'/g, '&#039;');
  }
  function escHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/"/g, '&quot;');
  }

  function initLiveSearch() {
    var inputs = document.querySelectorAll('input[name="suche"], input[name="qs"]');
    if (!inputs.length) return;

    function attachLiveSearch(input) {
      if (input.classList.contains('tt-hint')) return;

      /** Resolve /livesearch relative to document base URL (subfolder shops) or site root. */
      function buildSearchUrl(q) {
        var baseEl = document.querySelector('base[href]');
        var base = baseEl ? baseEl.href : window.location.origin + '/';
        var u = new URL('livesearch', base);
        u.searchParams.set('q', q);
        return u.pathname + u.search;
      }

      var dropdown = document.createElement('div');
      dropdown.className = 'live-search-dropdown';
      dropdown.style.cssText =
        'position:absolute;z-index:9999;background:#fff;border:1px solid #ddd;' +
        'display:none;max-height:350px;overflow-y:auto;box-shadow:0 4px 12px rgba(0,0,0,.15);' +
        'border-radius:0 0 4px 4px;';

      var parent = input.closest('.twitter-typeahead') || input.parentElement || document.body;
      if (getComputedStyle(parent).position === 'static') {
        parent.style.position = 'relative';
      }
      parent.appendChild(dropdown);

      function updatePos() {
        var rect = input.getBoundingClientRect();
        var parentRect = parent.getBoundingClientRect();
        dropdown.style.top = (rect.bottom - parentRect.top) + 'px';
        dropdown.style.left = (rect.left - parentRect.left) + 'px';
        dropdown.style.width = Math.max(rect.width, 300) + 'px';
      }
      updatePos();
      window.addEventListener('resize', updatePos);
      window.addEventListener('scroll', updatePos, true);

      var timer = null;
      var currentController = null;
      var cache = {};
      var selectedValues = [];
      var skipNextInput = false;
      var inlineCompletion = null; // şu an input'ta seçili olan tamamlama

      function clearHint() {
        var hintInput = parent.querySelector('.tt-hint');
        if (hintInput) hintInput.value = '';
      }

      function setInputSafe(val) {
        skipNextInput = true;
        input.setAttribute('readonly', 'readonly');
        input.value = val;
        clearHint();
        setTimeout(function () {
          input.removeAttribute('readonly');
        }, 150);
      }

      // Input'a inline tamamlama göster: kullanıcının yazdığı + geri kalanı seçili
      function showInlineCompletion(userTyped, fullValue) {
        skipNextInput = true;
        input.setAttribute('readonly', 'readonly');
        input.value = userTyped + fullValue.substring(userTyped.length);
        clearHint();
        setTimeout(function () {
          input.removeAttribute('readonly');
          // Tamamlanan kısmı seçili yap
          try {
            input.setSelectionRange(userTyped.length, input.value.length);
          } catch (e) {}
        }, 50);
        inlineCompletion = fullValue;
      }

      // Tab / Sağ Ok ile inline tamamlamayı kabul et
      input.addEventListener('keydown', function (e) {
        if (inlineCompletion && (e.key === 'Tab' || e.key === 'ArrowRight')) {
          e.preventDefault();
          var accepted = inlineCompletion;
          inlineCompletion = null;

          selectedValues.push(accepted);
          var newVal = selectedValues.join(' ') + ' ';
          setInputSafe(newVal);
          input.focus();

          cache = {};
          dropdown.innerHTML = '';
          dropdown.style.display = 'none';

          setTimeout(function () {
            skipNextInput = false;
            input.dispatchEvent(new Event('input', { bubbles: true }));
          }, 100);
        }
      });

      function renderItems(items, userQuery) {
        inlineCompletion = null;

        if (!items || !items.length) {
          dropdown.innerHTML =
            '<div style="padding:10px 14px;color:#888;font-size:.875rem">Sonuç bulunamadı.</div>';
          dropdown.style.display = 'block';
          updatePos();
          return;
        }

        var suggestions = items.filter(function (i) { return i.type === 'suggest'; });
        var series = items.filter(function (i) { return i.type === 'serie'; });

        // İlk suggestion için inline autocomplete göster
        if (suggestions.length > 0 && userQuery) {
          var firstSuggest = suggestions[0].name;
          var prefixStr = selectedValues.join(' ');
          var pendingPart = prefixStr
            ? userQuery.substring(prefixStr.length).replace(/^\s+/, '')
            : userQuery;

          if (pendingPart.length >= 2 &&
              pendingPart.toLowerCase() !== firstSuggest.toLowerCase()) {
            // Suggestion'ın tam değerini inline olarak göster
            var fullInline = prefixStr
              ? prefixStr + ' ' + firstSuggest
              : firstSuggest;
            showInlineCompletion(userQuery, fullInline);
          }
        }

        var html = '';

        if (suggestions.length > 0) {
          html += '<div style="padding:6px 14px;font-size:.7rem;color:#999;' +
            'border-bottom:1px solid #eee;text-transform:uppercase;letter-spacing:.5px">' +
            'Vorschläge <span style="color:#bbb;font-size:.65rem">(Tab zum Übernehmen)</span></div>';
        }

        if (series.length > 0) {
          html += '<div style="padding:6px 14px;font-size:.7rem;color:#999;' +
            'border-bottom:1px solid #eee;text-transform:uppercase;letter-spacing:.5px">' +
            'Serien (' + series.length + ')</div>';
        }

        html += items
          .map(function (i) {
            if (i.type === 'suggest') {
              return (
                '<div class="live-search-suggest" data-value="' + escAttr(i.name) + '" ' +
                'style="display:flex;align-items:center;padding:8px 14px;color:#333;' +
                'cursor:pointer;border-bottom:1px solid #f5f5f5;font-size:.875rem;' +
                'transition:background .15s" ' +
                'onmouseover="this.style.background=\'#f0f7ff\'" ' +
                'onmouseout="this.style.background=\'#fff\'">' +
                '<span style="margin-right:8px;color:#4a90d9">&#9656;</span>' +
                '<span style="flex:1">' + escHtml(i.name) + '</span>' +
                '<span style="font-size:.7rem;color:#aaa;margin-left:8px">auswählen</span>' +
                '</div>'
              );
            }
            if (i.type === 'serie') {
              var filterInfo = i.filters
                ? '<span style="display:block;font-size:.75rem;color:#888;margin-top:2px">' +
                  'Filter: ' + escHtml(i.filters) + '</span>'
                : '';
              return (
                '<a href="' + escAttr(i.url) + '" class="live-search-item" ' +
                'style="display:block;padding:10px 14px;color:#333;' +
                'text-decoration:none;border-bottom:1px solid #f5f5f5;font-size:.875rem;' +
                'transition:background .15s" ' +
                'onmouseover="this.style.background=\'#f8f8f8\'" ' +
                'onmouseout="this.style.background=\'#fff\'">' +
                '<div style="display:flex;align-items:center">' +
                '<span style="margin-right:8px;color:#666">&#9656;</span>' +
                '<span style="flex:1;font-weight:500">' + escHtml(i.name) + '</span>' +
                '<span style="font-size:.75rem;color:#aaa">&#8594;</span>' +
                '</div>' +
                filterInfo +
                '</a>'
              );
            }
            return '';
          })
          .join('');

        dropdown.innerHTML = html;
        dropdown.style.display = 'block';
        updatePos();

        // Suggestion tıklanınca: seçilen değeri ekle
        var suggestEls = dropdown.querySelectorAll('.live-search-suggest');
        suggestEls.forEach(function (el) {
          el.addEventListener('mousedown', function (e) {
            e.preventDefault();
            e.stopPropagation();
            inlineCompletion = null;

            var selectedName = this.getAttribute('data-value');
            selectedValues.push(selectedName);

            var newValue = selectedValues.join(' ') + ' ';
            setInputSafe(newValue);
            input.focus();

            cache = {};
            dropdown.innerHTML = '';
            dropdown.style.display = 'none';

            setTimeout(function () {
              skipNextInput = false;
              input.dispatchEvent(new Event('input', { bubbles: true }));
            }, 200);
          });
        });
      }

      input.addEventListener('input', function () {
        if (skipNextInput) {
          skipNextInput = false;
          return;
        }

        inlineCompletion = null;
        var q = this.value.trim();

        clearTimeout(timer);
        if (currentController) {
          currentController.abort();
          currentController = null;
        }

        if (q.length < 2) {
          dropdown.innerHTML = '';
          dropdown.style.display = 'none';
          selectedValues = [];
          return;
        }

        var prefix = selectedValues.join(' ').toLowerCase();
        if (prefix && q.toLowerCase().indexOf(prefix) !== 0) {
          selectedValues = [];
        }

        if (cache[q]) {
          renderItems(cache[q], q);
          return;
        }

        dropdown.style.display = 'block';
        dropdown.innerHTML =
          '<div style="padding:10px 14px;color:#888;font-size:.875rem">Aranıyor...</div>';
        updatePos();

        timer = setTimeout(function () {
          var controller = new AbortController();
          currentController = controller;

          fetch(buildSearchUrl(q), {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            signal: controller.signal
          })
            .then(function (res) { return res.text(); })
            .then(function (text) {
              currentController = null;
              var items = [];
              try { items = JSON.parse(text); } catch (e) { items = []; }
              if (Array.isArray(items)) {
                cache[q] = items;
                renderItems(items, q);
              } else {
                renderItems([], q);
              }
            })
            .catch(function (err) {
              if (err.name === 'AbortError') return;
              currentController = null;
              dropdown.innerHTML =
                '<div style="padding:10px 14px;color:#c00;font-size:.875rem">Hata oluştu.</div>';
            });
        }, 300);
      });

      document.addEventListener('click', function (e) {
        if (!dropdown.contains(e.target) && e.target !== input) {
          dropdown.style.display = 'none';
          inlineCompletion = null;
        }
      });
    }

    inputs.forEach(function (input) {
      attachLiveSearch(input);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLiveSearch);
  } else {
    initLiveSearch();
  }
})();
