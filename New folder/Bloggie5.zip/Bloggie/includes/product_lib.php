<?php
declare(strict_types=1);

use JTL\Shop;

if (!function_exists('bloggieGetLanguageId')) {
    function bloggieGetLanguageId(): int
    {
        try {
            if (class_exists(Shop::class) && method_exists(Shop::class, 'getLanguageID')) {
                $id = Shop::getLanguageID();
                if (is_int($id) && $id > 0) {
                    return $id;
                }
            }
        } catch (Throwable $e) {
            // ignore
        }
        try {
            $db = Shop::Container()->getDB();
            $lang = $db->getSingleObject('SELECT kSprache FROM tsprache ORDER BY kSprache ASC LIMIT 1');
            if ($lang !== null) {
                return (int)($lang->kSprache ?? 1);
            }
        } catch (Throwable $e) {
            // ignore
        }
        return 1;
    }
}

if (!function_exists('bloggieFetchArticleRows')) {
    /**
     * Returns rows for article SEO/blog input. Tries several strategies for different DB/language setups.
     *
     * @return array<int, object>
     */
    function bloggieFetchArticleRows(): array
    {
        $db = Shop::Container()->getDB();
        $langId = bloggieGetLanguageId();

        $baseSelect = 'SELECT a.kArtikel, a.cName AS cArtName, ts.cName, ts.cMetaTitle, ts.cMetaDescription, ts.cBeschreibung, ts.cKurzBeschreibung';

        // 1) Language-specific sprache (standard)
        try {
            $rows = $db->getObjects(
                $baseSelect . '
                   FROM tartikel a
                   LEFT JOIN tartikelsprache ts
                     ON ts.kArtikel = a.kArtikel
                    AND ts.kSprache = :kSprache
                  ORDER BY a.kArtikel ASC
                  LIMIT 1000',
                ['kSprache' => $langId]
            );
            if (is_array($rows) && count($rows) > 0) {
                return $rows;
            }
        } catch (Throwable $e) {
            // continue
        }

        // 2) Any sprache row per article (Top10List-style), language-agnostic fallback
        try {
            $rows = $db->getObjects(
                'SELECT
                    a.kArtikel,
                    a.cName AS cArtName,
                    ts.cName,
                    ts.cMetaTitle,
                    ts.cMetaDescription,
                    ts.cBeschreibung,
                    ts.cKurzBeschreibung
                   FROM tartikel a
                   LEFT JOIN (
                        SELECT s1.kArtikel,
                               MIN(s1.cName) AS cName,
                               MAX(s1.cMetaTitle) AS cMetaTitle,
                               MAX(s1.cMetaDescription) AS cMetaDescription,
                               MAX(s1.cBeschreibung) AS cBeschreibung,
                               MAX(s1.cKurzBeschreibung) AS cKurzBeschreibung
                          FROM tartikelsprache s1
                         GROUP BY s1.kArtikel
                   ) ts ON ts.kArtikel = a.kArtikel
                  ORDER BY a.kArtikel ASC
                  LIMIT 1000'
            );
            if (is_array($rows) && count($rows) > 0) {
                return $rows;
            }
        } catch (Throwable $e) {
            // continue
        }

        // 3) tartikel only (name from main article row)
        try {
            $rows = $db->getObjects(
                'SELECT a.kArtikel, a.cName AS cArtName,
                        NULL AS cName, NULL AS cMetaTitle, NULL AS cMetaDescription,
                        NULL AS cBeschreibung, NULL AS cKurzBeschreibung
                   FROM tartikel a
                  ORDER BY a.kArtikel ASC
                  LIMIT 1000'
            );
            if (is_array($rows) && count($rows) > 0) {
                return $rows;
            }
        } catch (Throwable $e) {
            // continue
        }

        return [];
    }
}

if (!function_exists('bloggieCountArticles')) {
    function bloggieCountArticles(): int
    {
        try {
            $db = Shop::Container()->getDB();
            $row = $db->getSingleObject('SELECT COUNT(*) AS n FROM tartikel');
            return (int)($row->n ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (!function_exists('bloggieFetchOneArticleForTest')) {
    /**
     * Single row for self-test / diagnostics (latest article).
     */
    function bloggieFetchOneArticleForTest(): ?object
    {
        $rows = bloggieFetchArticleRows();
        if ($rows === []) {
            return null;
        }
        return $rows[count($rows) - 1];
    }
}
